<?php

namespace App\Services;

use App\Models\Security;
use App\Models\Lookup;
use App\Models\Faq;
use App\Models\Language;
use App\Models\Cms;
use App\Models\Page;
use App\Models\Country;

class CmsService
{
	public function security() {
		return Security::select('title', 'description', 'portrait_image','landscape_image')->get();
    }

    public function lookups($name='') {
        return Lookup::where('lookup_type',$name)
        ->where('is_active',1)
        ->get();
    }

    public function helpSupport() {
        return Faq::select('faqs.question', 'faqs.answer')->where('is_active',1)->orderBy('faq_order',"DESC")->get();
    }

    public function cms($page_name='') {

        return Cms::where('slug',$page_name)->first();
    }

    public function country() {
        
        return Country::get();
    }

    public function PageDataFirst($page_name='',$section=''){
        return Page::where('page_name',$page_name)->where('section',$section)->first();
    }
    public function PageDataGet($page_name='',$section=''){
        return Page::where('page_name',$page_name)->where('section',$section)->get();
    }
}
