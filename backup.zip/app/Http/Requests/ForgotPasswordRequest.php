<?php

namespace App\Http\Requests;

use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;

class ForgotPasswordRequest extends FormRequest
{

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'user_role_id'  => 'required',
            'email'         => 'required|email|exists:users,email|regex:/^[^\s@]+@[^\s@]+\.[^\s@]+$/',
        ];
    }

    public function failedValidation(Validator $validator) {
        throw new HttpResponseException(response()->json([
            'success'   => false,
            'message'   => 'Validation errors',
            'data'      => $validator->errors()
        ]));
    }

    public function messages()
    {
        return [
            'email'         => "The email field is required.",
            "email.email"   => "The email must be a valid email address.",
            "email.regex"   => "The email must be a valid email address.",
            "email.exists"  => "Your email is not correct.",
        ];
    }


}
