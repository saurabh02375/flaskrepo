<?php

namespace App\Http\Requests;

use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Factory as ValidationFactory;
use DB;

class OrganizationProfileRequest extends FormRequest
{
    public function __construct(ValidationFactory $validationFactory) {
        $validationFactory->extend('email_role_unique', function($attribute,$value,$parameters,$validator){
            $formData = $validator->getData();
            $getinfo  =   DB::table("users")->where("id","!=",Login()->id)->where("user_role_id",Login()->user_role_id)->where("email",$value)->first();
            if(!empty($getinfo)){
                return false;
            }else {
                return true;
            }
        });
    }

    public function authorize()
    {
        return true;
    }
    
    public function rules()
    {
        return [
            "type"                    =>   "required",
            "phone_number"            =>   "nullable|min:7|max:15",
            "first_name"              =>   "required_if:type,==,personal_details|regex:/^[a-zA-Z\s]+$/",
            "last_name"               =>   "required_if:type,==,personal_details|regex:/^[a-zA-Z\s]+$/",
            "username"                =>   "required_if:type,==,personal_details|regex:/^[a-zA-Z]+$/|unique:users,username,".Login()->id,
            "email"                   =>   "required_if:type,==,personal_details|email|regex:/^[^\s@]+@[^\s@]+\.[^\s@]+$/|email_role_unique",
            "country"                 =>   "required_if:type,==,personal_details",
            "organization_email"      =>   "required_if:type,==,organization_details",
            "organization_name"       =>   "required_if:type,==,organization_details",
            "business_address"        =>   "required_if:type,==,organization_details",
            "website"                 =>   "nullable|url",
            "age"                     =>   "required_if:type,==,personal_details",
        ];
    }

    public function failedValidation(Validator $validator) {
        throw new HttpResponseException(response()->json([
            'success'   => false,
            'message'   => 'Validation errors',
            'data'      => $validator->errors()
        ]));
    }

    public function messages()
    {
        return [
            'first_name.required_if'                 =>    "The first name field is required.",
            'last_name.required_if'                  =>    "The last name field is required.",
            'phone_number.min'                       =>    "The phone number must be at least 7 digit.",
            'phone_number.max'                       =>    "The phone number must not be greater than 15 digit.",
            'organization_email.required_if'         =>    "The email field is required.",
            'organization_name.required_if'          =>    "The organization name field is required.",
            'business_address.required_if'           =>    "The business address field is required.",
            'email.required_if'                      =>    "The email field is required.",
            'email.email'                            =>    "The email must be a valid email address.",
            'email.regex'                            =>    "The email must be a valid email address.",
            'email.email_role_unique'                =>    "The enter your email already registered.",
        ];
    }

}
