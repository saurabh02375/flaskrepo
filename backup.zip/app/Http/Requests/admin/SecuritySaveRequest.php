<?php

namespace App\Http\Requests\admin;

use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Factory as ValidationFactory;
use DB;

class SecuritySaveRequest extends FormRequest
{
    
    public function authorize()
    {
        return true;
    }
    
    public function rules()
    {
        
        return [
                'portrait_image'    => 'required|image',
                'landscape_image'   => 'required|image',
                'title'             => 'required',
                'description'       => 'required',
        ];
    }

    public function messages()
    {
        return [
            'portrait_image.required'       => trans("The portrait image field is required."),
            'landscape_image.required'      => trans("The landscape image field is required."),
            'title.required'                => trans("The title field is required."),
            'description.required'          => trans("The  description field is required."),
        ];
    }
    

}
