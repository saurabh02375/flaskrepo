<?php

namespace App\Http\Requests\admin;

use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Factory as ValidationFactory;
use DB;

class IndividualSaveRequest extends FormRequest
{
    public function __construct(ValidationFactory $validationFactory) {
        $validationFactory->extend('email_role_unique', function($attribute,$value,$parameters,$validator){
            $formData = $validator->getData();
            $getinfo  =   DB::table("users")->where("user_role_id", Config('constants.ROLE_ID.INDIVIDUAL_ROLE_ID'))->where("email",$value)->first();
            if(!empty($getinfo)){
                return false;
            }else {
                return true;
            }
        });
    }

    public function authorize()
    {
        return true;
    }
    
    public function rules()
    {
        return [
            "first_name"              =>   "required|regex:/^[a-zA-Z\s]+$/",
            "last_name"               =>   "required|regex:/^[a-zA-Z\s]+$/",
            "username"                =>   "required|regex:/^[a-zA-Z]+$/|unique:users,username",
            "email"                   =>   "required|email|regex:/^[^\s@]+@[^\s@]+\.[^\s@]+$/|email_role_unique",
            "country"                 =>   "required",
            "age"                     =>   "required",
            'password'                =>   "required|min:6|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/",
            'confirm_password'        =>   "required|same:password",
        ];
    }

    

    public function messages()
    {
        return [
            'username.unique'               =>    trans("The enter your username already exists."),
            'email.email'                   =>    trans("The email must be a valid email address."),
            'email.regex'                   =>    trans("The email must be a valid email address."),
            'email.email_role_unique'       =>    trans("The enter your email already registered."),
            'password.regex'                =>    trans("Be sure to add a minimum 6-digit password that includes at least 1 uppercase, 1 lowercase and 1 number."),
            'confirm_password.same'         =>    trans("The confirmed password does not match with the password."),
           
        ];
    }

}
