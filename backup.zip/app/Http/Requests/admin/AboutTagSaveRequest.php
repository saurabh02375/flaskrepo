<?php

namespace App\Http\Requests\admin;

use Illuminate\Foundation\Http\FormRequest;

class AboutTagSaveRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    
  
    public function rules()
    {
        $about =  PageDataFirst('about-tag', 4);


        return [
            "about_title" => "required",
            "about_description" => "required",

            'about_image'       => $about ?->image ? 'image':'required|image',

        ];
    }
    
    public function messages()
    {
        return [
            'about_image.required'                => trans("The image field is required."),
            "about_title.required" => "The title field is required.",
            "about_description.required" => "The description field is required.",
            
        ];
    }

}
