<?php

namespace App\Http\Requests\admin;

use Illuminate\Foundation\Http\FormRequest;

class KeyFeatureSaveRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    
  
    public function rules()
    {
        return [
            "title" => "required",
            "description" => "required",
            'image'        => 'required|image|mimes:jpeg,png,jpg',
        ];
    }
    public function messages()
    {
        return [
            "title.required" => "The title field is required.",
            "description.required" => "The description field is required.",
            'image.image'    => 'The file must be an image.',
        ];
    }

}
