<?php

namespace App\Http\Requests\admin;

use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Factory as ValidationFactory;
use DB;

class ChangedPasswordRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }
    
    public function rules()
    {
        return [
            'new_password'            =>   "required|min:6|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/",
            'confirm_password'        =>   "required|same:new_password",
        ];
    }

    public function messages()
    {
        return [
            'new_password.regex'                =>    trans("Be sure to add a minimum 6-digit password that includes at least 1 uppercase, 1 lowercase and 1 number."),
            'confirm_password.same'         	=>    trans("The confirmed password does not match with the password."),
           
        ];
    }

}
