<?php

namespace App\Http\Requests\admin;

use Illuminate\Foundation\Http\FormRequest;

class HomeIntroSaveRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    
  
    public function rules()
    {
        $homeintro =  PageDataFirst('home-intro', 1);


        return [
            'image'       => $homeintro ?->image ? 'image':'required|image',

        ];
    }
    
    public function messages()
    {
        return [
            'image.required'                => trans("The image field is required."),
            
        ];
    }

}
