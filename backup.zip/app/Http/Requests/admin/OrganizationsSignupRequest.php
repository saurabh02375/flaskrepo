<?php

namespace App\Http\Requests\admin;

use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Factory as ValidationFactory;
use DB;

class OrganizationsSignupRequest extends FormRequest
{
	public function __construct(ValidationFactory $validationFactory) {
		$validationFactory->extend('email_role_unique', function($attribute,$value,$parameters,$validator){
			$formData = $validator->getData();
			$getinfo  =   DB::table("users")->where("user_role_id", Config('constants.ROLE_ID.ORGANIZATION_ROLE_ID'))->where("email",$value)->first();
			if(!empty($getinfo)){
				return false;
			}else {
				return true;
			}
		});
	}

	public function authorize()
	{
		return true;
	}
	
	public function rules()
	{
		return [
			"first_name"              =>   "required|regex:/^[a-zA-Z\s]+$/",
			"last_name"               =>   "required|regex:/^[a-zA-Z\s]+$/",
			"email"                   =>   "required|email|regex:/^[^\s@]+@[^\s@]+\.[^\s@]+$/|email_role_unique",
			"country"                 =>   "required",
			'password'                =>   "required|min:6|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/",
			'confirm_password'        =>   "required|same:password",
			"business_email"          =>   "required|email|regex:/^[^\s@]+@[^\s@]+\.[^\s@]+$/|email_role_unique",
			"business_name"           =>   "required",
			"address"           	  =>   "required",
			"website"                 =>   "nullable|URL",
			"username"                =>   "required|regex:/^[a-zA-Z]+$/|unique:users,username",
		];
	}

	

	public function messages()
	{
		return [
			'email.email'                   =>    trans("The email must be a valid email address."),
			'email.regex'                   =>    trans("The email must be a valid email address."),
			'email.email_role_unique'       =>    trans("The enter your email already registered."),
			'business_email.email_role_unique'       =>    trans("The enter your business email already registered."),
			'password.regex'                =>    trans("Be sure to add a minimum 6-digit password that includes at least 1 uppercase, 1 lowercase and 1 number."),
			'confirm_password.same'         =>    trans("The confirmed password does not match with the password."),
			'website.u_r_l'  		        =>    trans("The Url must be a valid URL."),
			'username.unique'               =>    trans("The enter your username already exists."),
			
		];
	}

}


