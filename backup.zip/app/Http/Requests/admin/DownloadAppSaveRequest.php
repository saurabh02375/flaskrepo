<?php

namespace App\Http\Requests\admin;

use Illuminate\Foundation\Http\FormRequest;

class DownloadAppSaveRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

  
    public function rules()
    {
        $downloadapp =  PageDataFirst('download-app', 5);


        return [
            'download_image'       => $downloadapp ?->image ? 'image':'required|image',
            "download_title" => "required",
            "download_description" => "required",

        ];
    }
    
    public function messages()
    {
        return [
            'download_image.required'                => trans("The image field is required."),
            "download_title.required" => "The title field is required.",
            "download_description.required" => "The description field is required."
            
        ];
    }

}
