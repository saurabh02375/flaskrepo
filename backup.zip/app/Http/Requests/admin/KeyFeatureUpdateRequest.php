<?php

namespace App\Http\Requests\admin;

use Illuminate\Foundation\Http\FormRequest;
use App\Models\Page;

class KeyFeatureUpdateRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    
  
    public function rules()
    {
        $id       = base64_decode(Request()->segment(5));
        $details  = Page::find($id);
        return [
            "title" => "required",
            "description" => "required",
            'image'        => $details->image!=null ? 'nullable|image':'required|image',
        ];
    }
    public function messages()
    {
        return [
            "title.required" => "The title field is required.",
            "description.required" => "The description field is required.",
            'image.image'    => 'The file must be an image.',
        ];
    }

}
