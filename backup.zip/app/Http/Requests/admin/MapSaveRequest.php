<?php

namespace App\Http\Requests\admin;

use Illuminate\Foundation\Http\FormRequest;

class MapSaveRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    
  
    public function rules()
    {


        return [
            "map_title" => "required",
            "map_description" => "required",

        ];
    }
    
    public function messages()
    {
        return [
            "map_title.required" => "The title field is required.",
            "map_description.required" => "The description field is required."
        ];
    }

}
