<?php

namespace App\Http\Requests\admin;

use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Factory as ValidationFactory;
use DB;

class AboutUsRequest extends FormRequest
{
    
    public function authorize()
    {
        return true;
    }
    
    public function rules()
    {
        $about =  PageDataFirst('about-us', 1);
        
        return [
            'image'       => $about ?->image ? 'image':'required|image',
            'title'       => 'required',
            'description' => 'required',
        ];
    }

    public function messages()
    {
        return [
            'image.required'                => trans("The image field is required."),
            'title.required'                => trans("The title field is required."),
            'description.required'          => trans("The  description field is required."),
        ];
    }
    

}
