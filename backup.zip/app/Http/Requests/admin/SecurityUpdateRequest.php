<?php

namespace App\Http\Requests\admin;

use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use App\Models\Security;
use Illuminate\Validation\Factory as ValidationFactory;
use DB;

class SecurityUpdateRequest extends FormRequest
{
    
    public function authorize()
    {
        return true;
    }
    
    public function rules()
    {
        $sliders =  Security::find($this->slider_id);
        
        return [
            'portrait_image'     =>  $sliders?->portrait_image ?'image'  : 'required|image',
            'landscape_image'    =>  $sliders?->landscape_image ?'image' : 'required|image',
            'title'              => 'required',
            'description'        => 'required',
        ];
    }

    public function messages()
    {
        return [
            'portrait_image.required'       => trans("The portrait image field is required."),
            'landscape_image.required'      => trans("The landscape image field is required."),
            'title.required'                => trans("The title field is required."),
            'description.required'          => trans("The  description field is required."),
        ];
    }
    

}
