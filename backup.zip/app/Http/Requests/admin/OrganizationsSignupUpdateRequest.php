<?php

namespace App\Http\Requests\admin;

use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Factory as ValidationFactory;
use DB;

class OrganizationsSignupUpdateRequest extends FormRequest
{
	public function __construct(ValidationFactory $validationFactory) {
		$validationFactory->extend('email_role_unique', function($attribute,$value,$parameters,$validator){
			$formData = $validator->getData();
			$getinfo  =   DB::table("users")->where('id','!=',$formData['user_id'])->where("user_role_id", Config('constants.ROLE_ID.ORGANIZATION_ROLE_ID'))->where("email",$value)->first();
			if(!empty($getinfo)){
				return false;
			}else {
				return true;
			}
		});
		$validationFactory->extend('username_role_unique', function($attribute,$value,$parameters,$validator){
            $formData = $validator->getData();
            $getinfo  =   DB::table("users")->where('id','!=',$formData['user_id'])->where("username",$value)->first();
            if(!empty($getinfo)){
                return false;
            }else {
                return true;
            }
        });
	}

	public function authorize()
	{
		return true;
	}
	
	public function rules()
	{
		return [
			"first_name"              =>   "required|regex:/^[a-zA-Z\s]+$/",
			"last_name"               =>   "required|regex:/^[a-zA-Z\s]+$/",
			"email"                   =>   "required|email|regex:/^[^\s@]+@[^\s@]+\.[^\s@]+$/|email_role_unique",
			"country"                 =>   "required",
			"business_email"          =>   "required|email|regex:/^[^\s@]+@[^\s@]+\.[^\s@]+$/|email_role_unique",
			"website"                 =>   "nullable|URL",
		 	"username"                =>   "required|regex:/^[a-zA-Z]+$/|username_role_unique",
		];
	}

	public function messages()
	{
		return [
			'email.email'       	            =>    trans("The email must be a valid email address."),
			'email.regex'  		                =>    trans("The email must be a valid email address."),
			'email.email_role_unique' 	  	  	=>    trans("The enter your email already registered."),
			'business_email.email_role_unique' 	=>    trans("The enter your Business Email already registered."),
			'username.username_role_unique'     =>    "The enter username already taken.",
		];
	}

}


