<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Hash;
use App\Http\Requests\OrganizationSignupRequest;
use App\Http\Requests\IndividualSignupRequest;
use App\Http\Requests\ForgotPasswordRequest;
use App\Http\Requests\ResetPasswordRequest;
use App\Http\Requests\OtpVerifyRequest;
use App\Http\Requests\ResendRequest;
use App\Http\Requests\LoginRequest;
use App\Models\BusinessDetails;
use App\Traits\ImageUpload;
use App\Models\User;
use Session,Auth,Config;

class AuthConroller extends Controller
{
    use ImageUpload;

    public function login(LoginRequest $request) {
        try {
            $users          =   User::where("user_role_id",$request->user_role_id)->where('email',$request->email)->first();
            $response       =   array();
            if($users != null){
                if(!Hash::check($request->password,$users->password)){
                    $response["status"]         =   "error";
                    $response["msg"]            =   "Your enter email and password is incorrect.";
                    $response["data"]           =   (object)array();
                }else{
                    if($users->is_active == 0 || $users->is_deleted == 1){
                        $response["status"]   =   "error";
                        $response["msg"]      =   "Your account has been deactivated. Please contact the administrator for further assistance.";
                        $response["data"]     =   (object)array();
                    }else{
                        if($users->user_role_id == 2 && $users->verify_user == 0 || $users->verify_user == 2){
                            if($users->verify_user == 2){
                                $response["status"]   =   "error";
                                $response["msg"]      =   "Your business signup request has been rejected by the administrator. If you have any questions, please contact support for further assistance.";
                                $response["data"]     =   (object)array();
                            }else{
                                $response["status"]   =   "error";
                                $response["msg"]      =   "Your account request is pending admin approval. Thank you for your patience.";
                                $response["data"]     =   (object)array();
                            }
                        }else{
                            if($users->verify_user == 0){
                                $users->otp                    =          $this->getVerificationCode();
                                $users->verify_token           =          md5($users->email . time() . time());
                                $users->save();

                                $others  = [$users->first_name.$users->last_name,$users->otp,Config("Contact.CompanyName")];
                                $this->setContent($users->email,$users->first_name.$users->last_name,"account_verification",$others);
                                $response["status"]   =   "otp_verify";
                                $response["msg"]      =   "The verification code has been successfully sent to your email address.";
                                $response["data"]                  =   [];
                                $response["data"]["verify_token"]  =   $users->verify_token;
                            }else{
                                
                                Auth::loginUsingId($users->id);
                                $response["status"]       = "success";
                                $response["msg"]          = "You are now logged in";
                                $user                     = Auth::guard('api')->user();
                                $response['token']        = $users->createToken('Wildtag app Personal Access Client')->accessToken;
                                $response["data"]         = $users->makeHidden(['created_at', 'updated_at','is_deleted', 'is_active']);
                            }                       
                        }
                    }  
                }
            }else{
                $response["status"]                =   "error";
                $response["msg"]                   =   "Your enter email and password is incorrect.";
                $response["data"]                  =   (object)array();
            }
            return json_encode($response, 200);
        }catch (\Exception $th) {
            $response["status"]                =   "error";
            $response["msg"]                   =   "Api has been not working please check it.";
            $response["data"]                  =   (object)array();
        }
    }

    public function individualSignup(IndividualSignupRequest $request) {
        try {

            $users                         =          new User;
            $users->user_role_id           =          $request->user_role_id;
            $users->first_name             =          $request->first_name;
            $users->last_name              =          $request->last_name;
            $users->username               =          $request->username;
            $users->email                  =          $request->email;
            $users->phone_code             =          $request->phone_code ?? '';
            $users->phone_prefix           =          $request->phone_prefix ?? '';
            $users->phone_number           =          $request->phone_number ?? '';
            $users->country                =          $request->country;
            $users->age_id                 =          $request->age;
            $users->password               =          Hash::make($request->password);
            $users->image                  =          $this->upload($request,'image',Config('constants.USER_IMAGE_ROOT_PATH'));
            $users->otp                    =          $this->getVerificationCode();
            $users->verify_token           =          md5($users->email . time() . time());
            $users->save();

            if($users != null){
                $others  = [$request->first_name.$request->last_name,$users->otp,Config("Contact.CompanyName")];
                $this->setContent($request->email,$request->first_name.$request->last_name,"account_verification",$others);
                $response["status"]                =    "success";
                $response["msg"]                   =    "The verification code has been successfully sent to your email address.";
                $response["data"]                  =    [];
                $response["data"]["type"]          =    "signup";
                $response["data"]["verify_token"]  =    $users->verify_token;
            }
            return json_encode($response, 200);
        }catch (\Exception $th) {
            $response["status"]                =   "error";
            $response["msg"]                   =   "Api has been not working please check it.";
            $response["data"]                  =    [];
        }
    }

    public function organizationSignup(OrganizationSignupRequest $request) {
        try {

            $users                         =          new User;
            $users->user_role_id           =          $request->user_role_id;
            $users->first_name             =          $request->first_name;
            $users->last_name              =          $request->last_name;
            $users->username               =          $request->username;
            $users->email                  =          $request->email;
            $users->phone_code             =          $request->phone_code ?? '';
            $users->phone_prefix           =          $request->phone_prefix ?? '';
            $users->phone_number           =          $request->phone_number ?? '';
            $users->country                =          $request->country;
            $users->image                  =          $this->upload($request,'image',Config('constants.USER_IMAGE_ROOT_PATH'));
            $users->password               =          Hash::make($request->password);
            $users->otp                    =          $this->getVerificationCode();
            $users->verify_token           =          md5($users->email . time() . time());
            $users->save();

            if($users != null){

                $businessDetails                        =        new BusinessDetails;
                $businessDetails->user_id               =        $users->id; 
                $businessDetails->name                  =        $request->business_name; 
                $businessDetails->address               =        $request->business_address; 
                $businessDetails->email                 =        $request->business_email; 
                $businessDetails->phone_code            =        $request->business_phone_code; 
                $businessDetails->phone_prefix          =        $request->business_phone_prefix; 
                $businessDetails->phone_number          =        $request->business_phone_number; 
                $businessDetails->website               =        $request->website;
                $businessDetails->save();

                $others  = [$request->first_name.$request->last_name,$users->otp,Config("Contact.CompanyName")];
                $this->setContent($request->email,$request->first_name.$request->last_name,"account_verification",$others);
                $response["status"]                =   "success";
                $response["msg"]                   =   "The verification code has been successfully sent to your email address.";
                $response["data"]                  =    [];
                $response["data"]["type"]          =    "signup";
                $response["data"]["verify_token"]  =    $users->verify_token;
            }

        }catch (\Exception $th) {
            $response["status"]                =   "error";
            $response["msg"]                   =   "Api has been not working please check it.";
            $response["data"]                  =    [];
        }
        return json_encode($response, 200);
    }

    public function otpVerify(OtpVerifyRequest $request){
        try {
            $response   = array();
            $users      = User::where("verify_token",$request->verify_token)->first();
            if($users != null){
                if(strtotime(date("Y-m-d H:i:s",strtotime("+ 1 min",strtotime($users->updated_at)))) > strtotime(date('Y-m-d H:i:s'))){
                    if($request->otp == $users->otp){
                        if($request->type == "forgot"){
                            $users->verify_token      =          md5($users->email . time() . time());
                            $users->save();

                            $response["status"]                = "success";
                            $response["msg"]                   = "Your email verification has been successful. Thank you!";
                            $response["data"]                  =   [];
                            $response["type"]                  =   "reset_password";
                            $response["data"]["verify_token"]  =   $users->verify_token;
                        }else{
                            if($users->user_role_id == 1){
                                $users->verify_user    = 1;
                                $users->otp            = null;
                                $users->verify_token   = null;
                                $users->save();

                                Auth::loginUsingId($users->id);
                                $response["status"]       = "success";
                                $response["msg"]          = "You are now logged in";
                                $user                     = Auth::guard('api')->user();
                                $response["type"]         = "login_completed";
                                $response['token']        = $users->createToken('Wildtag app Personal Access Client')->accessToken;
                                $response["data"]         = $users->makeHidden(['created_at', 'updated_at','is_deleted', 'is_active']);
                            }else{
                                $users->otp            = null;
                                $users->verify_token   = null;
                                $users->save();

                                if($users->verify_user == 1){
                                    Auth::loginUsingId($users->id);
                                    $response["status"]       = "success";
                                    $response["msg"]          = "You are now logged in";
                                    $user                     = Auth::guard('api')->user();
                                    $response["type"]         = "login_completed";
                                    $response['token']        = $users->createToken('Wildtag app Personal Access Client')->accessToken;
                                    $response["data"]         = $users->makeHidden(['created_at', 'updated_at','is_deleted', 'is_active']);
                                }else{

                                    $others  = [$users->first_name.$users->last_name,Config("Contact.CompanyName")];
                                    $admin   = [$users->first_name.$users->last_name,$users->email,Config("Contact.CompanyName")];
                                    $this->setContent($users->email,$users->first_name.$users->last_name,"business_user_request",$others);
                                    $this->setContent(Config("Contact.admin_email"),$users->first_name.$users->last_name,"business_admin_request",$admin);

                                    $response["status"]       = "success";
                                    $response["msg"]          = "Your account creation request is awaiting approval. We'll notify you once it's been processed. Thank you for your patience.";
                                    $response["type"]         = "login_page";
                                }
                            }
                        }
                    }else{
                        $response["status"]                =   "error";
                        $response["msg"]                   =   "Security code has been not matched.";                        
                    }
                }else{
                    $response["status"]                =   "error";
                    $response["msg"]                   =    "Security code expired. Please request a new one.";
                }
            }else{
                $response["status"]                =   "error";
                $response["msg"]                   =   "Your account registration was unsuccessful. Please try again.";
            }
            return json_encode($response, 200);
        }catch (\Exception $th) {
            $response["status"]                =   "error";
            $response["msg"]                   =   "Api has been not working please check it.";
        }
    }

    public function resendOtp(ResendRequest $request) {
        $response   = array();
        try {
            $users      = User::where("verify_token",$request->verify_token)->first();
            if($users != null) {
                $users->otp                    =          $this->getVerificationCode();
                $users->verify_token           =          md5($users->email . time() . time());
                $users->save();

                $others  = [$users->first_name.$users->last_name,$users->otp,Config("Contact.CompanyName")];
                $this->setContent($users->email,$users->first_name.$users->last_name,"account_verification",$others);
                $response["status"]                =   "success";
                $response["msg"]                   =   "A new Security code has been sent. Please check your inbox.";
                $response["data"]                  =   [];
                $response["data"]["verify_token"]  =   $users->verify_token;
            }else{
                $response["status"]         =   "error";
                $response["msg"]            =   "Your account registration was unsuccessful. Please try again.";
                $response["data"]           =   [];
            }
            return json_encode($response, 200);
        }catch (\Exception $th) {
            $response["status"]                =   "error";
            $response["msg"]                   =   "Api has been not working please check it.";
            $response["data"]                  =   [];
        }
    }

    public function forgotPassword(ForgotPasswordRequest $request) {
        try {
            $users      =   User::where("user_role_id",$request->user_role_id)->where('email',$request->email)->first();
            $response   = array();
            if($users != null){
                $users->otp                    =   $this->getVerificationCode();
                $users->verify_token           =   md5($users->email . time() . time());
                $users->save();

                $others  = [$users->first_name.$users->last_name,$users->otp,Config("Contact.CompanyName")];
                $this->setContent($users->email,$users->first_name.$users->last_name,"account_verification",$others);
                $response["status"]                =   "success";
                $response["msg"]                   =   "A new Security code has been sent. Please check your inbox.";
                $response["data"]                  =    [];
                $response["data"]["type"]          =    "forgot";
                $response["data"]["verify_token"]  =    $users->verify_token;

            }else{
                $response["status"]     =   "error";
                $response["msg"]        =   "Your account has not been registered. Please try again or contact support for assistance.";
                $response["data"]       =    [];
            }
            return json_encode($response, 200);
        }catch (\Exception $th) {
            $response["status"]                =   "error";
            $response["msg"]                   =   "Api has been not working please check it.";
            $response["data"]                  =    [];
        }
    }

    public function resetPassword(ResetPasswordRequest $request) {
        try {
            $users      =   User::where("verify_token",$request->verify_token)->first();
            $response   =   array();
            if($users != null){
                $users->password     =  Hash::make($request->password);
                $users->verify_token = null;
                $users->save();

                $response["status"]                =   "success";
                $response["msg"]                   =   "Your enter password has been changed successfully.";
            }else{
                $response["status"]     =   "error";
                $response["msg"]        =   "Your account has not been registered. Please try again or contact support for assistance.";
            }
            return json_encode($response, 200);
        }catch (\Exception $th) {
            $response["status"]                =   "error";
            $response["msg"]                   =   "Api has been not working please check it.";
        }
    }


}
