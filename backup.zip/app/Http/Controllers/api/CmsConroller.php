<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Services\CmsService;
use App\Http\Requests\ContactRequest;
use App\Models\ContactUs;

class CmsConroller extends Controller
{
    public $cms;
    public function __construct(Request $request){  
        parent::__construct();
        $this->cms  = new CmsService();
    }

    public function cmsInfo() {
        $response                            =   array();
        $response["status"]                  =   "success";
        $response["msg"]                     =   "";
        $response["privacy_policy"]          =   $this->cms->cms('privacy-policy');
        $response["term_conditions"]         =   $this->cms->cms('term-conditions');
        $response["about_us"]                =   $this->cms->cms('about-us');
        $response["age"]                     =   $this->cms->lookups('age');
        $response["country"]                 =   $this->cms->country();
        $response["security"]                =   $this->cms->security();
        return json_encode($response, 200);
    }

    public function faqs() {
        $response                            =   array();
        $response["status"]                  =   "success";
        $response["msg"]                     =   "";
        $response["data"]                    =   $this->cms->helpSupport();
        return json_encode($response, 200);
    }

    public function contactUs() {
        $response                            =   array();
        $response["status"]                  =   "success";
        $response["msg"]                     =   "";
        $response["data"]['contact_email']   =   Config("Contact.email_address");
        $response["data"]['contact_phone']   =   Config("Contact.phone");
        return json_encode($response, 200);
    }


    public function contactRequest(ContactRequest $request){
        try {
            $contactUs                =  new ContactUs;
            $contactUs->name          =  $request->name ?? '';
            $contactUs->email         =  $request->email ?? '';
            $contactUs->subject       =  $request->subject;
            $contactUs->message       =  $request->message ?? '';
            $contactUs->save();

            $content = [$contactUs->name, $contactUs->email, $contactUs->subject,$contactUs->message,Config("Contact.CompanyName")];
            $this->setContent($contactUs->email,$contactUs->name,'user_contact_enquiry',$content);
            $this->setContent(Config('Contact.email_address'),"Admin",'new_enquiry',$content);

            $response                            =   array();
            $response["status"]                  =   "success";
            $response["msg"]                     =   "Your request has been sent successfully";
        }catch (\Exception $th) {
            $response["status"]                =   "error";
            $response["msg"]                   =   "Api has been not working please check it.";
            $response["data"]                  =   (object)array();
        }
        return json_encode($response, 200);

    }


}
