<?php

namespace App\Http\Controllers\api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\IndividualProfileRequest;
use App\Http\Requests\OrganizationProfileRequest;
use App\Http\Requests\ChangedPasswordRequest;
use App\Http\Requests\LanguageRequest;
use App\Models\BusinessDetails;
use App\Models\User;
use App\Traits\ImageUpload;
use Storage,Hash;

class UsersController extends Controller
{

    use ImageUpload;

    public function logout() {
        auth()->guard('api')->user()->token()->revoke();
        $response = array();
        $response["status"]       = "success";
        $response["msg"]          =  "Your account has been logout successfully.";
        $response["data"]         = (object)array();
        return response()->json($response, 200);
    }

    public function profile() {
        $users                               =   User::with('businessDetails')->find(Login()->id);
        $response                            =   array();
        $response["status"]                  =   "success";
        $response["msg"]                     =   "";
        $response["data"]                    =   $users->makeHidden(['created_at', 'updated_at','is_deleted', 'is_active']);;
        return json_encode($response, 200);
    }

    public function individualProfileRequest(IndividualProfileRequest $request) {
        $users      =   User::find(Login()->id);
        if($users != null){
            $users->first_name             =          $request->first_name;
            $users->last_name              =          $request->last_name;
            $users->username               =          $request->username;
            $users->email                  =          $request->email;
            $users->phone_code             =          $request->phone_code ?? '';
            $users->phone_prefix           =          $request->phone_prefix ?? '';
            $users->phone_number           =          $request->phone_number ?? '';
            $users->country                =          $request->country;
            $users->age_id                 =          $request->age;
            $users->image                  =          $this->upload($request,'image',Config('constants.USER_IMAGE_ROOT_PATH'),$users->image);
            $users->save();
        }
        $response                            =   array();
        $response["status"]                  =   "success";
        $response["msg"]                     =   "Profile has been updated successfully.";
        return json_encode($response, 200);
    }

    public function organizationProfileRequest(OrganizationProfileRequest $request) {
        $users      =   User::find(Login()->id);
        $response   =   array();
        if($users != null){
            if($request->type == "personal_details"){
                $users->first_name         =          $request->first_name;
                $users->last_name          =          $request->last_name;
                $users->email              =          $request->email;
                $users->username           =          $request->username;
                $users->phone_code         =          $request->phone_code ?? '';
                $users->phone_prefix       =          $request->phone_prefix ?? '';
                $users->phone_number       =          $request->phone_number ?? '';
                $users->country            =          $request->country;
                $users->age_id             =          $request->age;
                $users->image              =          $this->upload($request,'image',Config('constants.USER_IMAGE_ROOT_PATH'),$users->image);
                $users->save();
            }else{
                $businessDetails               =  BusinessDetails::where('user_id',$users->id)->first();
                if($businessDetails != null){
                    $businessDetails->name                   =          $request->organization_name;
                    $businessDetails->email                  =          $request->organization_email;
                    $businessDetails->phone_code             =          $request->phone_code ?? '';
                    $businessDetails->phone_prefix           =          $request->phone_prefix ?? '';
                    $businessDetails->phone_number           =          $request->phone_number ?? '';
                    $businessDetails->address                =          $request->business_address;
                    $businessDetails->website                =          $request->website;
                    $businessDetails->save();
                }
            }
        }
        $response["status"]                  =   "success";
        $response["msg"]                     =   "Profile has been updated successfully.";
        return json_encode($response, 200);
    }

    public function updateNotifications(Request $request) {
        $response        =   array();
        if($request->enable_notification != null && $request->enable_email != null){
            $users      =   User::find(Login()->id);
            if($users != null){
                $users->enable_notification  =  $request->enable_notification;  
                $users->enable_email         =  $request->enable_email;  
                $users->save();  
            }
            $response["status"]                  =   "success";
            $response["msg"]                     =   "Notification has been updated successfully.";
        }else{
            $response["status"]                  =   "error";
            $response["msg"]                     =   "The enable notification and email notification field is required.";
        }
        return json_encode($response, 200);
    }

    public function updateEmail(Request $request) {
        $response        =   array();
        if($request->enable_email != null){
            $users      =   User::find(Login()->id);
            if($users != null){
                $users->enable_email  =  $request->enable_email;  
                $users->save();  
            }
            $response                            =   array();
            $response["status"]                  =   "success";
            $response["msg"]                     =   "Email has been updated successfully.";
        }else{
            $response["status"]                  =   "error";
            $response["msg"]                     =   "The enable email field is required.";
        }
        return json_encode($response, 200);
    }

    public function accountDelete() {
        $users      =   User::find(Login()->id);
        if($users != null){
            $users->phone_code    =  null;  
            $users->phone_prefix  =  null;  
            $users->email         =   'delete_' . $users->id . '_' . !empty($users->email);  
            $users->phone_number  =   'delete_' . $users->id . '_' . !empty($users->phone_number);  
            $users->is_deleted  =  1;  
            $users->save();  
        }
        $response                            =   array();
        $response["status"]                  =   "success";
        $response["msg"]                     =   "Your account has been deleted successfully.";
        return json_encode($response, 200);
    }

    public function languageUpdate(LanguageRequest $request) {
        $users      =   User::find(Login()->id);
        if($users != null){
            $users->current_lang  =  $request->lang_code;  
            $users->save();  
        }
        $response                            =   array();
        $response["status"]                  =   "success";
        $response["msg"]                     =   "Your account has been updated successfully.";
        return json_encode($response, 200);
    }

    public function changedPasswordRequest(ChangedPasswordRequest $request) {
        $response                          =   array();
        $users                             =  User::where('id',Login()->id)->first();
        if(!Hash::check($request->old_password, $users->password)){
            $response["status"]            =   "error";
            $response["msg"]               =   "The old password is incorrect, Please try again.";
        }else{
            $users->password               =  Hash::make($request->new_password);
            $users->save();

            $response["status"]            =   "success";
            $response["msg"]               =   "Your new password has been changed successfully.";
        }
        return json_encode($response, 200);
    }

}
