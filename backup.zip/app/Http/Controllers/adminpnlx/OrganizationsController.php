<?php

namespace App\Http\Controllers\adminpnlx;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;
use Illuminate\Support\Facades\Hash;
use Illuminate\Http\Request;
use App\Models\EmailAction;
use App\Models\EmailTemplate;
use App\Models\Country;
use App\Models\User;
use App\Models\BusinessDetails;
use App\Http\Requests\admin\OrganizationsSignupRequest;
use App\Http\Requests\admin\ChangedPasswordRequest;
use App\Http\Requests\admin\OrganizationsSignupUpdateRequest;
use Redirect,Session,Config;

class OrganizationsController extends Controller
{
    public $model                =   'organizations';
    public $sectionNameSingular  =   'users';
    public function __construct(Request $request) {   
        parent::__construct();
        View()->share('model', $this->model);
        View()->share('sectionNameSingular', $this->sectionNameSingular);
        $this->request = $request;
    }

    public function index(Request $request) {
        $DB					=	User::query();
        $searchVariable		=	array();
        $inputGet			=	$request->all();
        if ($request->all()) {
            $searchData			=	$request->all();
            unset($searchData['display']);
            unset($searchData['_token']);

            if (isset($searchData['order'])) {
                unset($searchData['order']);
            }
            if (isset($searchData['sortBy'])) {
                unset($searchData['sortBy']);
            }
            if (isset($searchData['page'])) {
                unset($searchData['page']);
            }
            if ((!empty($searchData['date_from'])) && (!empty($searchData['date_to']))) {
                $dateS = date("Y-m-d",strtotime($searchData['date_from']));
                $dateE =  date("Y-m-d",strtotime($searchData['date_to']));
                $DB->whereBetween('created_at', [$dateS . " 00:00:00", $dateE . " 23:59:59"]);
            } elseif (!empty($searchData['date_from'])) {
                $dateS = $searchData['date_from'];
                $DB->where('created_at', '>=', [$dateS . " 00:00:00"]);
            } elseif (!empty($searchData['date_to'])) {
                $dateE = $searchData['date_to'];
                $DB->where('created_at', '<=', [$dateE . " 00:00:00"]);
            }
            foreach ($searchData as $fieldName => $fieldValue) {
                if ($fieldValue != "") {
                    if ($fieldName == "business_name") {
                        $DB->whereHas('businessDetails', function($qry) use ($fieldValue) {
                            $qry->where("name", 'like', '%' . $fieldValue . '%');
                        });
                    }                    if ($fieldName == "username") {
                        $DB->where("username", 'like', '%' . $fieldValue . '%');
                    }
                    if ($fieldName == "first_name") {
                        $DB->where("first_name", 'like', '%' . $fieldValue . '%');
                    }
                    if ($fieldName == "address") {
                        $DB->where("address", 'like', '%' . $fieldValue . '%');
                    }
                    if ($fieldName == "last_name") {
                        $DB->where("last_name", 'like', '%' . $fieldValue . '%');
                    }
                    if ($fieldName == "name") {
                        $DB->where("name", 'like', '%' . $fieldValue . '%');
                    }
                    if ($fieldName == "email") {
                        $DB->where("email", 'like', '%' . $fieldValue . '%');
                    }
                    if ($fieldName == "is_active") {
                        $DB->where("is_active", 'like', '%' . $fieldValue . '%');
                    }
                }
                $searchVariable	=	array_merge($searchVariable, array($fieldName => $fieldValue));
            }
        }

        $DB->IsDeleted()->where("user_role_id",Config('constants.ROLE_ID.ORGANIZATION_ROLE_ID'));
        $sortBy = ($request->input('sortBy')) ? $request->input('sortBy') : 'created_at';
        $order  = ($request->input('order')) ? $request->input('order')   : 'DESC';
        $records_per_page	=	($request->input('per_page')) ? $request->input('per_page') : Config::get("Reading.records_per_page");
        $results = $DB->orderBy($sortBy, $order)->paginate($records_per_page);
        $complete_string		=	$request->query();
        unset($complete_string["sortBy"]);
        unset($complete_string["order"]);
        $query_string			=	http_build_query($complete_string);
        $results->appends($inputGet)->render();
        $resultcount = $results->count();
        return  View("admin.$this->sectionNameSingular.index", compact('resultcount', 'results', 'searchVariable', 'sortBy', 'order', 'query_string'));
    }

    public function create(Request $request) {       
        $countries   =  Country::get();
        return  View("admin.$this->sectionNameSingular.add",compact('countries'));
    }

    public function store(OrganizationsSignupRequest $request) {
        $thisdata = $request->all();
        $user                               =   new User;
        $user->user_role_id                 =   Config('constants.ROLE_ID.ORGANIZATION_ROLE_ID');
        $user->first_name                   =   $request->first_name;
        $user->last_name                    =   $request->last_name;
        $user->username                     =   $request->username;
        $user->email                        =   $request->email;
        $user->phone_prefix                 =   $request->phone_prefix;
        $user->phone_code                   =   $request->phone_code;
        $user->phone_number                 =   $request->phone_number;
        $user->country                      =   $request->country;
        $user->password                     =   Hash::make($request->password);
        $SavedResponse                      =   $user->save();
        if (!$SavedResponse) {
            Session()->flash('error', trans("Something went wrong."));
            return Redirect()->back()->withInput();
        } else {
            $user_id                            =   $user->id;   
            $company                            =   new BusinessDetails;
            $company->user_id                   =   $user_id;
            $company->email                     =   $request->business_email;
            $company->name                      =   $request->business_name;
            $company->address                   =   $request->address;
            $company->phone_code                =   $request->business_phone_code;
            $company->phone_prefix              =   $request->business_phone_prefix;
            $company->phone_number              =   $request->business_phone_number;
            $company->website                   =   $request->website;
            $companySaved                       =   $company->save();

            Session()->flash('success', ucfirst(Config('constants.CUSTOMER.ORGANIXATION_TITLES')." has been added successfully"));
            return Redirect()->route($this->model . ".index");
        }
    }

    public function edit(Request $request,  $enuserid = null) { 
        $user_id        =  base64_decode($enuserid);
        $userDetails    =  User::find($user_id);
        if (!empty($userDetails)) {
            $countries      =  Country::get();
            return  View("admin.$this->sectionNameSingular.edit", compact('countries','userDetails'));
        } 
        return back();
    }

    public function update(OrganizationsSignupUpdateRequest $request,  $enuserid = null){
        if ($request->isMethod('PUT')) {
            $user_id  =   base64_decode($enuserid);
            $user     =   User::where("id",$user_id)->first();
            if ($user != null) {
                $user->first_name                   =   $request->first_name;
                $user->last_name                    =   $request->last_name;
                $user->username                     =   $request->username;
                $user->email                        =   $request->email;
                $user->phone_prefix                 =   $request->phone_prefix;
                $user->phone_code                   =   $request->phone_code;
                $user->phone_number                 =   $request->phone_number;
                $user->country                      =   $request->country;
                $user->save();
                $company                            = BusinessDetails::where("user_id",$user_id)->first();
                $company->email                     =   $request->business_email;
                $company->name                      =   $request->business_name;
                $company->address                   =   $request->address;
                $company->phone_code                =   $request->business_phone_code;
                $company->phone_prefix              =   $request->business_phone_prefix;
                $company->phone_number              =   $request->business_phone_number;
                $company->website                   =   $request->website;
                $SavedResponse                       =   $company->save();

                if (!$SavedResponse) {
                    Session()->flash('error', trans("Something went wrong."));
                    return Redirect()->back()->withInput();
                }
                return Redirect()->route($this->model . ".index")->with('success',ucfirst(Config('constants.CUSTOMER.ORGANIXATION_TITLES')." has been updated successfully"));
            } 
            return back();
        }
    }

    public function destroy( $enuserid) {
        $user_id        =  base64_decode($enuserid);
        $userDetails    =  User::find($user_id);
        if($userDetails != null){
           $userDetails->email          =   "delete_1_".$userDetails->email;  
           $userDetails->is_deleted     =   1;  
           $userDetails->save();
           Session()->flash('success',ucfirst(Config('constants.CUSTOMER.ORGANIXATION_TITLES')." has been removed successfully"));
        }
        return back();
    }

    public function changeStatus($modelId = 0, $status = 0) {
        if ($status == 1) {
            $statusMessage   =   trans(Config('constants.CUSTOMER.ORGANIXATION_TITLES'). " has been activated successfully");
        } else {
            $statusMessage   =   trans(Config('constants.CUSTOMER.ORGANIXATION_TITLES'). " has been deactivated successfully");
        }
        $user = User::find($modelId);
        if ($user) {
            $currentStatus = $user->is_active;
            if (isset($currentStatus) && $currentStatus == 0) {
                $NewStatus = 1;
            } else {
                $NewStatus = 0;
            }
            $user->is_active = $NewStatus;
            $user->save();
        }
        Session()->flash('flash_notice', $statusMessage);
        return back();
    }

    public function changedPassword($enuserid = null) {
        $userDetails   =  User::find(base64_decode($enuserid));
        if($userDetails != null){
            return view("admin.$this->sectionNameSingular.change_password",compact('userDetails'));
        }
        return back();
    }

    public function changedPasswordRequest(ChangedPasswordRequest $request, $enuserid = null) {
        $userDetails   =  User::find(base64_decode($enuserid));
        if($userDetails != null){
            $userDetails->password     =  Hash::make($request->new_password);
            $userDetails->save();
            Session()->flash('success',ucfirst(Config('constants.CUSTOMER.ORGANIXATION_TITLES')." has been password changed successfully"));
        }   
        return Redirect()->route($this->model . '.index');
    }

    public function show($enuserid = null) {
        $userDetails    =    User::with('businessDetails')->where('id',base64_decode($enuserid))->first();
        if($userDetails != null){
            return  View("admin.$this->sectionNameSingular.view", compact('userDetails'));
        }
        return back();
    }

    public function verifiedStatus($user_id='',$status=null) {
        $userDetails    =    User::where('id',$user_id)->first();
        
        if($userDetails != null){
            $update         =   User::where('id',$user_id)->update(['verify_user'=>$status]);
            if($status == 2){
                $others  = [$userDetails->username,$userDetails->otp,Config("Contact.CompanyName")];
                $this->setContent($userDetails->email,$userDetails->username,"Business_signup_request_rejected",$others);
                Session()->flash('success',ucfirst(Config('constants.CUSTOMER.ORGANIXATION_TITLES')." has been rejected successfully."));

            }else{
                $others  = [$userDetails->username,$userDetails->otp,Config("Contact.CompanyName")];
                $this->setContent($userDetails->email,$userDetails->username,"account_verification_successful",$others);
            Session()->flash('success',ucfirst(Config('constants.CUSTOMER.ORGANIXATION_TITLES')." has been account verified successfully"));
            }
        }
        return back();
    }
    public function rejected(request $request) {
        $thisdata       =   $request->all();
        $userDetails    =    User::where('id',$thisdata['user_id'])->first();
        
        if($userDetails != null){
            $userDetails->verify_user   =   2;
            // $userDetails->reject_reason=$thisdata['reject_reason'];
            $SavedResponse = $userDetails->save();
            $others  = [$userDetails->username,$userDetails->otp,$thisdata['reject_reason'],Config("Contact.CompanyName")];
            $this->setContent($userDetails->email,$userDetails->username,"Business_signup_request_rejected",$others);
               
            if (!$SavedResponse) {
                return response()->json(['error' => false, 'message' => ucfirst(Config('constants.CUSTOMER.ORGANIXATION_TITLES')." has been rejected successfully.")]);
            } else {
                return response()->json(['success' => true, 'message' => ucfirst(Config('constants.CUSTOMER.ORGANIXATION_TITLES')." has been Not rejected successfully.")]);
            }

           
        }
        
    }

    public function sendCredentials($id){
        if(empty($id)){
            return redirect()->back();
        }
        $random = str_shuffle('abcdefghjklmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ234567890!$%^&!$%^&');
        $password = substr($random, 0, 10);
        $user  = 	User::find($id);
        $settingsEmail 	= 	Config::get("Site.from_email");
        $full_name 		= 	$user->name;
        $email 			=	$user->email;
        $user->password = Hash::make($password);
        $user->save();
        $emailActions 	= 	EmailAction::where('action','=','send_login_credentials')->get()->toArray();
        $emailTemplates = 	EmailTemplate::where('action','=','send_login_credentials')->get(array('name','subject','action','body'))-> toArray();
        $cons 			= 	explode(',',$emailActions[0]['options']);
        $constants 		= 	array();
        foreach($cons as $key => $val){
            $constants[] = '{'.$val.'}';
        }
        $subject 		= 	$emailTemplates[0]['subject'];
        $route_url      =  	Config('constants.WEBSITE_ADMIN_URL').'/login';		
        $rep_Array 		= 	array($full_name,$email,$password,$route_url);
        $messageBody 	= 	str_replace($constants, $rep_Array, $emailTemplates[0]['body']);
        $this->sendMail($email,$full_name,$subject,$messageBody,$settingsEmail);
        Session()->flash('flash_notice', trans("Login credentials send successfully"));
        return redirect()->back();
    }    
}
