<?php

namespace App\Http\Controllers\adminpnlx;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\admin\AboutUsRequest;
use App\Models\Page;
use App\Traits\ImageUpload;
use Config;

class AboutUsController extends Controller
{
    use ImageUpload;
    public $model     = 'about-us';
    public $modelName = 'about';
    public function __construct(Request $request)
    {
        parent::__construct();
        View()->share('model', $this->model);
        View()->share('modelName', $this->modelName);
        $this->request = $request;
    }



    public function index()
    {
        $aboutDetails =  PageDataFirst('about-us', 1);
        return View("admin.$this->model.index",compact('aboutDetails'));
    }

    public function store(AboutUsRequest $request){
        $aboutDetails           =  PageDataFirst('about-us', 1);
        $obj                    =   $aboutDetails != '' ? $aboutDetails : new Page();
        $obj->page_name         =   'about-us';
        $obj->section           =   1;
        $obj->title             =   $request->input('title');
        $obj->description       =    $request->input('description');
        $obj->image             =   $this->upload($request,'image',Config('constants.HOMEPAGE_IMAGE_ROOT_PATH'),$aboutDetails ?->image);
        $obj->save();
        Session()->flash('success', Config('constants.ABOUTUS.ABOUTUS_TITLE') . " has been updated successfully");
        return back();
    }

   

   

    

   
  
   

}
