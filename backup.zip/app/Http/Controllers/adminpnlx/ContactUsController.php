<?php
namespace App\Http\Controllers\adminpnlx;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\ContactUs;
use App\Models\ContactUsReplies;
use App\Models\EmailAction;
use App\Models\EmailTemplate;

use Auth,Blade,Config,Cache,Cookie,DB,File,Hash,Input,Mail,Redirect,Response,Session,URL,View,Validator;

/**
* ContactQueryController Controller
*
* Add your methods in the class below
*
*/
class ContactUsController extends Controller {

    public $model               =   'ContactQuery';
    public $sectionName         =   'Contact Us Inquiries';
    public $sectionNameSingular =   'Contact Us Inquiry';

    public function __construct(Request $request) {
        parent::__construct();
        View::share('modelName',$this->model);
        View::share('sectionName',$this->sectionName);
        View::share('sectionNameSingular',$this->sectionNameSingular);
        $this->request = $request;
    }

    /**
    * Function for display all Contacts
    *
    * @param null
    *
    * @return view page.
    */
    public function index(Request $request){

        if($request->status == 'archive'){
            $DB             =   ContactUs::query();
        }else{
            $DB             =   ContactUs::where('status','<>','archive');
        }


        $searchVariable     =   array();
        $inputGet           =   $request->all();
        if ($request->all()) {
            $searchData         =   $request->all();
            unset($searchData['display']);
            unset($searchData['_token']);

            if(isset($searchData['order'])){
                unset($searchData['order']);
            }
            if(isset($searchData['sortBy'])){
                unset($searchData['sortBy']);
            }
            if(isset($searchData['page'])){
                unset($searchData['page']);
            }

            if((!empty($searchData['date_from'])) && (!empty($searchData['date_to']))){
                $dateS = $searchData['date_from'];
                $dateE = $searchData['date_to'];
                $DB->whereBetween('contact_us.created_at', [$dateS." 00:00:00", $dateE." 23:59:59"]);
            }elseif(!empty($searchData['date_from'])){
                $dateS = $searchData['date_from'];
                $DB->where('contact_us.created_at','>=' ,[$dateS." 00:00:00"]);
            }elseif(!empty($searchData['date_to'])){
                $dateE = $searchData['date_to'];
                $DB->where('contact_us.created_at','<=' ,[$dateE." 00:00:00"]);
            }elseif(!empty($searchData['status'])){
                $status = $searchData['status'];
                $DB->where('contact_us.status','=',$status);
            }

            foreach($searchData as $fieldName => $fieldValue){
                if($fieldValue != ""){

                    if($fieldName == "is_read"){
                        $DB->where("is_read",$fieldValue);
                    }
                }
                $searchVariable =   array_merge($searchVariable,array($fieldName => $fieldValue));
            }

        }

        $sortBy = ($request->input('sortBy')) ? $request->input('sortBy') : 'created_at';
        $order  = ($request->input('order')) ? $request->input('order')   : 'DESC';

        $records_per_page       =   ($request->input('per_page')) ? $request->input('per_page') : Config::get("Reading.records_per_page");

        $results = $DB->orderBy($sortBy, $order)->paginate($records_per_page);
        $complete_string        =   $request->query();
        unset($complete_string["sortBy"]);
        unset($complete_string["order"]);
        $query_string           =   http_build_query($complete_string);
        $results->appends($inputGet)->render();

        $query_string           =   http_build_query($complete_string);
        $results->appends($inputGet)->render();

        return  View::make("admin.$this->model.index",compact('results','searchVariable','sortBy','order','query_string'));
    }

    public function show($modelId = 0){
        $result                 =   ContactUs::where('id',$modelId)->first();
        if(empty($result)) {
            return Redirect::route($this->model.".index");
        }
        ContactUs::where('id',$modelId)->update(array('is_read'=>'1'));
        $contactReplies=ContactUsReplies::where('contact_id',$modelId)->get();
        return  View::make("admin.$this->model.view",array('result' => $result,'contactReplies'=>$contactReplies));
    }


    public function reply($modelId=0,Request $request){
        $result             =   ContactUs::where('id',$modelId)->first();
        if(empty($result)) {
            return Redirect::route($this->model.".index");
        }
        if(empty($request->get('message'))){
            Session::flash('error', trans("Please write a reply message."));
            return Redirect::to("adminpnlx/contact-us-inquiry/view/".$modelId);
        }
        $file_nnae  =   "";
        $attachments        =   array();
        if(!empty(Auth::guard('admin')->user())){
        $user_id            =   Auth::guard('admin')->user()->id;

            if($request->all()){
                $obj= new ContactUsReplies;
                $obj->contact_id    =  $modelId;
                $obj->user_id       =  $user_id;
                $obj->message       =   $request->get('message');

                if($request->hasFile('image')){
                    $extension              =   $request->file('image')->getClientOriginalExtension();
                    $original_image_name    =   $request->file('image')->getClientOriginalName();
                    $fileName               =   rand(99999,00000).time().'-image.'.$extension;
                    
                    $file_nnae              =   $original_image_name;
                
                    $folderName             =   strtoupper(date('M'). date('Y'))."/";
                    $folderPath             =   Config('constants.SEO_PAGE_IMAGE_ROOT_PATH').$folderName;
                    if(!File::exists($folderPath)) {
                        File::makeDirectory($folderPath, $mode = 0777,true);
                    }
                    if($request->file('image')->move($folderPath, $fileName)){
                        $obj->image     = $folderName.$fileName;
                        $attachments[]  = Config('constants.SEO_PAGE_IMAGE_IMAGE_PATH').$folderName.$fileName;
                    
                    }
                }
                
                $userId             =  $obj->save();
                $emailActions       =  EmailAction::where('action','=','contact_inquiry_reply')->get()->toArray();
                $emailTemplates     =  EmailTemplate::where('action','=','contact_inquiry_reply')->get()->toArray();
                $cons               =  explode(',',$emailActions[0]['options']);
                $constants          =  array();
                foreach($cons as $key=>$val){
                    $constants[]    = '{'.$val.'}';
                }
                $receiver_email     =   $result->email;
                $receiver_full_name =   $result->name;
                $receiver_subject   =   $result->subject;
                $receiver_message   =   $result->message;
                $replyMsg           =   $request->get('message');
                $subject            =   $emailTemplates[0]['subject'];
                $rep_Array          =    array($receiver_full_name,$replyMsg,$receiver_subject,$receiver_message);
                $messageBody        =    str_replace($constants, $rep_Array, $emailTemplates[0]['body']);
                $settingsEmail      =    Config::get('Site.from_email');
                $this->sendMail($receiver_email,$receiver_full_name,$subject,$messageBody,$settingsEmail);

                if(!$userId){
                    Session::flash('error', trans("Something went wrong."));
                    return Redirect::route($this->model.".index");
                }
                $result             =   ContactUs::where('id',$modelId)->first();
                if(empty($result)) {
                    return Redirect::route($this->model.".index");
                }
                ContactUs::where('id',$modelId)->update(array('is_read'=>'1'));
                $contactReplies=ContactUsReplies::where('contact_id',$modelId)->get();
                Session::flash('flash_notice',trans($this->sectionNameSingular." has been replied successfully"));
                return  View::make("admin.$this->model.view",array('result' => $result,'contactReplies'=>$contactReplies));
            }
        }
    }


    public function Approvestatus($modelId = 0, $status = 0){
        $result     =   ContactUs::where('id',$modelId)->first();
        if(empty($result)) {
            return Redirect::route($this->model.".index");
        }
        if($status == 'on_going'){
            $statusMessage  =   trans($this->sectionNameSingular." status has been updated to on going successfully.");
        }elseif($status == 'close'){
            $statusMessage  =   trans($this->sectionNameSingular." status has been updated to close successfully.");
        }elseif($status == 'archive'){
            $statusMessage  =   trans($this->sectionNameSingular." status has been updated to archive successfully.");
        }else{
            $statusMessage  =   trans($this->sectionNameSingular." status is not correct.");
            Session::flash('error', trans("Status is not correct."));
        }
            if($status == 'on_going' || $status == 'close' || $status == 'archive'){
                $update         =   ContactUs::where('id',$modelId)->update(['status'=>$status]);
                Session::flash('success', $statusMessage);
            }

        return Redirect::back();
    }// end changeApproveStatus()



}// end ContactQueryController
