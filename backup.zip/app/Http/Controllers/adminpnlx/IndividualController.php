<?php

namespace App\Http\Controllers\adminpnlx;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\admin\IndividualSaveRequest;
use App\Http\Requests\admin\IndividualUpdateRequest;
use App\Http\Requests\admin\ChangedPasswordRequest;
use Illuminate\Support\Facades\Hash;
use App\Traits\ImageUpload;
use App\Models\User;
use App\Models\Country;
use App\Models\Lookup;
use Redirect,Session,Config;

class IndividualController extends Controller
{
    use ImageUpload;

    public $model                =   'individuals';
    public function __construct(Request $request) {   
        parent::__construct();
        View()->share('model', $this->model);
        $this->request = $request;
    }

    public function index(Request $request) {
        $DB					=	User::query();
        $searchVariable		=	array();
        $inputGet			=	$request->all();
        if ($request->all()) {
            $searchData			=	$request->all();
            unset($searchData['display']);
            unset($searchData['_token']);

            if (isset($searchData['order'])) {
                unset($searchData['order']);
            }
            if (isset($searchData['sortBy'])) {
                unset($searchData['sortBy']);
            }
            if (isset($searchData['page'])) {
                unset($searchData['page']);
            }
            if ((!empty($searchData['date_from'])) && (!empty($searchData['date_to']))) {
                $dateS = date("Y-m-d",strtotime($searchData['date_from']));
                $dateE =  date("Y-m-d",strtotime($searchData['date_to']));
                $DB->whereBetween('created_at', [$dateS . " 00:00:00", $dateE . " 23:59:59"]);
            } elseif (!empty($searchData['date_from'])) {
                $dateS = $searchData['date_from'];
                $DB->where('created_at', '>=', [$dateS . " 00:00:00"]);
            } elseif (!empty($searchData['date_to'])) {
                $dateE = $searchData['date_to'];
                $DB->where('created_at', '<=', [$dateE . " 00:00:00"]);
            }
            foreach ($searchData as $fieldName => $fieldValue) {
                if ($fieldValue != "") {
                    if ($fieldName == "first_name") {
                        $DB->where("first_name", 'like', '%' . $fieldValue . '%');
                    }
                    if ($fieldName == "last_name") {
                        $DB->where("last_name", 'like', '%' . $fieldValue . '%');
                    }
                    if ($fieldName == "username") {
                        $DB->where("username", 'like', '%' . $fieldValue . '%');
                    }
                    if ($fieldName == "email") {
                        $DB->where("email", 'like', '%' . $fieldValue . '%');
                    }
                    if ($fieldName == "is_active") {
                        $DB->where("is_active", 'like', '%' . $fieldValue . '%');
                    }
                }
                $searchVariable	=	array_merge($searchVariable, array($fieldName => $fieldValue));
            }
        }

        $DB->IsDeleted()->where("user_role_id",  Config('constants.ROLE_ID.INDIVIDUAL_ROLE_ID'));
        $sortBy = ($request->input('sortBy')) ? $request->input('sortBy') : 'created_at';
        $order  = ($request->input('order')) ? $request->input('order')   : 'DESC';
        $records_per_page	=	($request->input('per_page')) ? $request->input('per_page') : Config::get("Reading.records_per_page");
        $results = $DB->orderBy($sortBy, $order)->paginate($records_per_page);
        $complete_string		=	$request->query();
        unset($complete_string["sortBy"]);
        unset($complete_string["order"]);
        $query_string			=	http_build_query($complete_string);
        $results->appends($inputGet)->render();
        $resultcount            = $results->count();
        return  View("admin.$this->model.index", compact('resultcount', 'results', 'searchVariable', 'sortBy', 'order', 'query_string'));
    }

    public function create(Request $request) {    
        $countries   =  Country::get();
        $ages        =  Lookup::where('lookup_type','age')->get(); 
        return  View("admin.$this->model.add",compact('countries','ages'));
    }

    public function store(IndividualSaveRequest $request) {
        $user                               =   new User;
        $user->user_role_id                 =   Config('constants.ROLE_ID.INDIVIDUAL_ROLE_ID');
        $user->first_name                   =   $request->first_name;
        $user->last_name                    =   $request->last_name;
        $user->username                     =   $request->username;
        $user->email                        =   $request->email;
        $user->phone_prefix                 =   $request->phone_prefix;
        $user->phone_code                   =   $request->phone_code;
        $user->phone_number                 =   $request->phone_number;
        $user->country                      =   $request->country;
        $user->age_id                       =   $request->age;
        $user->password                     =   Hash::make($request->password);
        $user->image                        =   $this->upload($request,'image',Config('constants.USER_IMAGE_ROOT_PATH'));
        $user->save();

        return Redirect()->route($this->model . ".index")->with('success',ucfirst(Config('constants.INDIVIDUAL.INDIVIDUAL_TITLE')." has been added successfully"));
    }

    public function edit(Request $request,  $enuserid = null) { 
        $user_id        =  base64_decode($enuserid);
        $userDetails    =  User::find($user_id);
        if (!empty($userDetails)) {
            $countries      =  Country::get();
            $ages           =  Lookup::where('lookup_type','age')->get(); 
            return  View("admin.$this->model.edit", compact('ages','countries','userDetails'));
        } 
        return back();
    }

    public function update(IndividualUpdateRequest $request,  $enuserid = null){
        if ($request->isMethod('PUT')) {
            $user_id  =   base64_decode($enuserid);
            $user     =   User::where("id",$user_id)->first();
            if ($user != null) {
                $user->first_name                   =   $request->first_name;
                $user->last_name                    =   $request->last_name;
                $user->username                     =   $request->username;
                $user->email                        =   $request->email;
                $user->phone_prefix                 =   $request->phone_prefix;
                $user->phone_code                   =   $request->phone_code;
                $user->phone_number                 =   $request->phone_number;
                $user->country                      =   $request->country;
                $user->age_id                       =   $request->age;
                $user->image                        =   $this->upload($request,'image',Config('constants.USER_IMAGE_ROOT_PATH'),$user->image);
                $user->save();
                return Redirect()->route($this->model . ".index")->with('success',ucfirst(Config('constants.INDIVIDUAL.INDIVIDUAL_TITLE')." has been updated successfully"));
            } 
            return back();
        }
    }

    public function destroy( $enuserid) {
        $user_id        =  base64_decode($enuserid);
        $userDetails    =  User::find($user_id);
        if($userDetails != null){
           $userDetails->email          =   "delete_1_".$userDetails->email;  
           $userDetails->is_deleted     =   1;  
           $userDetails->save();
           Session()->flash('flash_notice', trans(ucfirst( "Individual has been removed successfully")));
        }
        return back();
    }

    public function changeStatus($modelId = 0, $status = 0) {
        if ($status == 1) {
            $statusMessage   =   trans(Config('constants.INDIVIDUAL.INDIVIDUAL_TITLE'). " has been activated successfully");
        } else {
            $statusMessage   =   trans(Config('constants.INDIVIDUAL.INDIVIDUAL_TITLE'). " has been deactivated successfully");
        }
        $user = User::find($modelId);
        if ($user) {
            $currentStatus = $user->is_active;
            if (isset($currentStatus) && $currentStatus == 0) {
                $NewStatus = 1;
            } else {
                $NewStatus = 0;
            }
            $user->is_active = $NewStatus;
            $user->save();
        }
        Session()->flash('flash_notice', $statusMessage);
        return back();
    }

    public function show($enuserid = null) {
        $userDetails    =    User::select('users.*','countries.name as country_name','lookups.code as age')
        ->leftjoin('countries','users.country','countries.id')
        ->leftjoin('lookups','users.age_id','lookups.id')
        ->where('users.id',base64_decode($enuserid))->first();
        if($userDetails != null){
            return  View("admin.$this->model.view", compact('userDetails'));
        }
        return back();
    }

    public function changedPassword($enuserid = null) {
        $userDetails   =  User::find(base64_decode($enuserid));
        if($userDetails != null){
            return view("admin.$this->model.change_password",compact('userDetails'));
        }
        return back();
    }

    public function changedPasswordRequest(ChangedPasswordRequest $request, $enuserid = null) {
        $userDetails   =  User::find(base64_decode($enuserid));
        if($userDetails != null){
            $userDetails->password     =  Hash::make($request->new_password);
            $userDetails->save();
            Session()->flash('success', trans("Password changed successfully."));
        }   
        return Redirect()->route($this->model . '.index');
    }

    public function sendCredentials($id){
        if(empty($id)){
            return redirect()->back();
        }
        $random = str_shuffle('abcdefghjklmnopqrstuvwxyzABCDEFGHJKLMNOPQRSTUVWXYZ234567890!$%^&!$%^&');
        $password = substr($random, 0, 10);
        $user  = 	User::find($id);
        $settingsEmail 	= 	Config::get("Site.from_email");
        $full_name 		= 	$user->name;
        $email 			=	$user->email;
        $user->password = Hash::make($password);
        $user->save();
        $emailActions 	= 	EmailAction::where('action','=','send_login_credentials')->get()->toArray();
        $emailTemplates = 	EmailTemplate::where('action','=','send_login_credentials')->get(array('name','subject','action','body'))-> toArray();
        $cons 			= 	explode(',',$emailActions[0]['options']);
        $constants 		= 	array();
        foreach($cons as $key => $val){
            $constants[] = '{'.$val.'}';
        }
        $subject 		= 	$emailTemplates[0]['subject'];
        $route_url      =  	Config('constants.WEBSITE_ADMIN_URL').'/login';		
        $rep_Array 		= 	array($full_name,$email,$password,$route_url);
        $messageBody 	= 	str_replace($constants, $rep_Array, $emailTemplates[0]['body']);
        $this->sendMail($email,$full_name,$subject,$messageBody,$settingsEmail);
        Session()->flash('flash_notice', trans("Login credentials send successfully"));
        return redirect()->back();
    }    

     
}
