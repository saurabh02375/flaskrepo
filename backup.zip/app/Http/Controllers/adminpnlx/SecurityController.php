<?php

namespace App\Http\Controllers\adminpnlx;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Http\Requests\admin\SecuritySaveRequest;
use App\Http\Requests\admin\SecurityUpdateRequest;
use App\Models\Security;
use App\Traits\ImageUpload;
use Storage;

class SecurityController extends Controller
{
    use ImageUpload;
    public $model = 'security';
    public function __construct(Request $request){
        parent::__construct();
        View()->share('modelName', $this->model);
        $this->request = $request;
    }
    public function index(Request $request)
    {  
        
        $DB = Security::query();
        $searchVariable = array();
        $inputGet = $request->all();
        if ($request->all()) {
			$searchData			=	$request->all();
			unset($searchData['display']);
			unset($searchData['_token']);

			if(isset($searchData['order'])){
				unset($searchData['order']);
			}
			if(isset($searchData['sortBy'])){
				unset($searchData['sortBy']);
			}
			if(isset($searchData['page'])){
				unset($searchData['page']);
			}
            foreach ($searchData as $fieldName => $fieldValue) {
                if ($fieldValue != "") {
                   
                    if ($fieldName == "title") {
                        $DB->where("title", 'like', '%' . $fieldValue . '%');
                    }
                }
                $searchVariable = array_merge($searchVariable, array($fieldName => $fieldValue));
            }
        }
        $sortBy = ($request->input('sortBy')) ? $request->input('sortBy') : 'created_at';
        $order = ($request->input('order')) ? $request->input('order') : 'DESC';
        $records_per_page = ($request->input('per_page')) ? $request->input('per_page') : Config("Reading.records_per_page");
        $results = $DB->orderBy($sortBy, $order)->paginate($records_per_page);
        $complete_string = $request->query();
        unset($complete_string["sortBy"]);
        unset($complete_string["order"]);
        $query_string = http_build_query($complete_string);
        $results->appends($inputGet)->render();
        return View("admin.$this->model.index", compact('results', 'searchVariable', 'sortBy', 'order', 'query_string'));
    }


    public function create()
    {
        return View("admin.$this->model.add");
    }

    public function store(SecuritySaveRequest $request) {
        $obj                      = new Security;
        $obj->title               = $request->title;
        $obj->description         = $request->description;
        $obj->portrait_image      = $this->upload($request,'portrait_image',Config('constants.SECURITY_IMAGE_ROOT_PATH'));
        $obj->landscape_image     = $this->upload($request,'landscape_image',Config('constants.SECURITY_IMAGE_ROOT_PATH'));
        $obj->save();
        
        Session()->flash('success', Config('constants.SECURITY.SECURITY_TITLE') . " has been added successfully");
        return Redirect()->route($this->model . ".index");
        
    }
    
    public function edit($enId)
    {
        $slider_id         =   base64_decode($enId);
        $sliderDetails     =   Security::find($slider_id);
        if (!empty($sliderDetails)) {
            return View("admin.$this->model.edit", compact('sliderDetails'));
        }
        return back();
    }

    public function update(SecurityUpdateRequest $request, $enId)
    {

        $security_id      = base64_decode($enId);
        $obj              =   Security::find($security_id);
        if(!empty($obj)){
            $obj->title                 =   $request->title;
            $obj->description           =   $request->description;
            $obj->portrait_image        =   $this->upload($request,'portrait_image', Config('constants.SECURITY_IMAGE_ROOT_PATH'),$obj->portrait_image);
            $obj->landscape_image       =   $this->upload($request,'landscape_image',Config('constants.SECURITY_IMAGE_ROOT_PATH'),$obj->landscape_image);
            $obj->save();
            Session()->flash('success', Config('constants.SECURITY.SECURITY_TITLE') .  " has been updated successfully");
            return Redirect()->route($this->model . ".index");
            
        }
        return back();
    }

    
    public function destroy($enId)
    {
        $security_id         = base64_decode($enId);
        $securityDetails     =  Security::find($security_id);
        if ($securityDetails!=null) {
            $securityDetails->delete();
            $deleteFolderPath = Config('constants.SECURITY_IMAGE_ROOT_PATH').$securityDetails->image;
            if (!empty($securityDetails->image) && Storage::disk('public')->exists($deleteFolderPath)) {
                Storage::disk('public')->delete($deleteFolderPath);
            }
            Session()->flash('flash_notice', trans(Config('constants.SECURITY.SECURITY_TITLE') . " has been removed successfully"));
        }
        return back();
    }

}
