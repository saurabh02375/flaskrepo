<?php
namespace App\Http\Controllers\adminpnlx;
use App\Http\Controllers\Controller;
use App\Http\Requests\admin\AboutTagSaveRequest;
use App\Http\Requests\admin\DownloadAppSaveRequest;
use App\Http\Requests\admin\HomeIntroSaveRequest;
use App\Http\Requests\admin\KeyFeatureSaveRequest;
use App\Http\Requests\admin\KeyFeatureUpdateRequest;
use App\Http\Requests\admin\MapSaveRequest;
use App\Models\Page;
use Illuminate\Http\Request;
use App\Traits\ImageUpload;
class HomeSettingController extends Controller
{
    use ImageUpload;
    public $model = 'home-settings';
    public function __construct(Request $request)
    {
        parent::__construct();
        View()->share('modelName', $this->model);
        $this->request = $request;
    }
    public function index(){
        $homeintro          =  PageDataFirst('home-intro', 1);
        $keyfeature         =  PageDataGet('key-feature', 2);
        $aboutTag           =  PageDataFirst('about-tag', 4);
        $viewmap            =  PageDataFirst('home-map', 3);
        $downloadapp        =  PageDataFirst('download-app', 5);
        return View("admin.$this->model.index" , compact('homeintro', 'downloadapp' , 'viewmap', 'aboutTag','keyfeature') );
    }
    public function store(HomeIntroSaveRequest $request) {
        $homedesc                = Page::where('page_name','home-intro' )->where('section' , 1 )->first();
        $home                    = $homedesc != null ? $homedesc : new Page();
        $home->page_name         = 'home-intro';
        $home->section           = 1;
        $home->title             = $request->input('title');
        $home->description       = $request->input('description');
        $home->image             =   $this->upload($request,'image',Config('constants.HOMEPAGE_IMAGE_ROOT_PATH'),$home ?->image);
        $home->save();
        Session()->flash('flash_notice', Config('constants.HOME_SETTING.HOME_SETTING_TITLES') . " has been Updated successfully");
        return back();
    }
    public function create()
    {
        return View("admin.$this->model.key-feature-add");
    }
    public function KeyFeaturestore(KeyFeatureSaveRequest $request){
        $key                           = new Page();
        $key->page_name                = 'key-feature';
        $key->section                  = 2;
        $key->title                    = $request->input('title');
        $key->description              = $request->input('description');
        $key->image                    =   $this->upload($request,'image',Config('constants.HOMEPAGE_IMAGE_ROOT_PATH'),$key ?->image);
        $key->save();
        Session()->flash('flash_notice', Config('constants.KEY_FEATURE.KEY_FEATURE_TITLE') . " has been added successfully");
        return Redirect()->route($this->model . ".index");
    }
    public function keyFeatureEdit($enId) {
        $keydetails = Page::find(base64_decode($enId));
        if ($keydetails != null) {
            return View("admin.$this->model.key-feature-edit", compact('keydetails'));
        } 
        return back();
    }
    public function keyFeatureupdate(KeyFeatureUpdateRequest $request, $enId)  {
        $key_id                    = base64_decode($enId);
        $obj                        = Page::find($key_id);
        if (!empty($obj)) {
            $obj->title                     = $request->input('title');
            $obj->description               = $request->input('description');
            $obj->image                     = $this->upload($request,'image',Config('constants.HOMEPAGE_IMAGE_ROOT_PATH'),$obj ?->image);
            $obj->save();
            Session()->flash('flash_notice', Config('constants.KEY_FEATURE.KEY_FEATURE_TITLE') . " has been updated successfully");
            return redirect()->route($this->model . ".index");
        } 
        return back();
    }
    public function KeyFeauturedelete($enId){
        $details = Page::find(base64_decode($enId));
        if ($details) {
            $this->imageDeleted(Config('constants.HOMESETTINGS_IMAGE_ROOT_PATH'), $details->image);
            Page::where("id", $details->id)->delete();
            session()->flash('flash_notice', trans(ucfirst("Key Feature has been removed successfully")));
        }
        return back();
    }
    public function mapStore(MapSaveRequest $request) {
        $homedesc                       = Page::where('page_name','home-map' )->where('section' , 3 )->first();
        $home                           = $homedesc != null ? $homedesc : new Page();
        $home->page_name                = 'home-map';
        $home->section                  = 3;
        $home->other                    = $request->input('map_url');
        $home->title                    = $request->input('map_title');
        $home->description              = $request->input('map_description');
        $home->save();
        Session()->flash('flash_notice', Config('constants.HOME_SETTING.HOME_SETTING_TITLES') . " has been Updated successfully");
        return back();
    }
    public function aboutTagStore(AboutTagSaveRequest $request){
        $desc                        = Page::where('page_name','about-tag' )->where('section' , 4 )->first();
        $key                         = $desc != null ? $desc : new Page();
        $key->page_name              = 'about-tag';
        $key->section                = 4;
        $key->title                  = $request->input('about_title');
        $key->image                  =   $this->upload($request,'about_image',Config('constants.HOMEPAGE_IMAGE_ROOT_PATH'),$key ?->image);
        $description = $request->input('about_description');
        $nonNullDescriptions = [];
        foreach ($description as $desc) {
            if ($desc !== null) {
                $nonNullDescriptions[] = $desc;
            }
        }
        if (!empty($nonNullDescriptions)) {
            $descJson = json_encode($nonNullDescriptions);
            $key->description = $descJson;
        } else {
            $key->description = null; 
        }
        $key->save();
        Session()->flash('flash_notice', "About Wildtag has been added successfully");
        return Redirect()->route($this->model . ".index");
    }
    public function downloadAppStore(DownloadAppSaveRequest $request) {
        $homedesc                   = Page::where('page_name','download-app' )->where('section' , 5 )->first();
        $home                       = $homedesc != null ? $homedesc : new Page();
        $home->page_name            = 'download-app';
        $home->section              = 5;
        $home->title                = $request->input('download_title');
        $home->description          = $request->input('download_description');
        $home->image                =   $this->upload($request,'download_image',Config('constants.HOMEPAGE_IMAGE_ROOT_PATH'),$home ?->image);
        $home->save();
        Session()->flash('flash_notice', "DOwnload App Wildtag has been Updated successfully");
        return back();
    }
}
