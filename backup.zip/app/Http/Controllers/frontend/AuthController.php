<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Requests\LoginRequest;

class AuthController extends Controller
{
    public function login() {
        return view('frontend.auth.login');
    }
    
    public function loginRequest(LoginRequest $request) {
        
    }

    public function forgotPassword() {
        return view('frontend.auth.forgot-password');
    }

    public function otpVerify() {
        return view('frontend.auth.otp-verify');
    }

    public function resetPassword() {
        return view('frontend.auth.reset-password');
    }
    
}
