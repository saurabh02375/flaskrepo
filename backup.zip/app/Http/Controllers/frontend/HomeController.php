<?php

namespace App\Http\Controllers\frontend;

use App\Http\Controllers\Controller;
use App\Models\Faq;
use Illuminate\Http\Request;
use App\Http\Requests\ContactRequest;
use App\Services\CmsService;
use App\Models\Page;
use App\Models\ContactUs;
use App\Models\EmailTemplate;
use App\Models\EmailAction;
use Config;

class HomeController extends Controller
{
    public $data;
    public function __construct(Request $request){  
        parent::__construct();
        $this->data  = new CmsService();
    }
    public function index() {
        $response["home-intro"]                  =   $this->data->pageDataFirst('home-intro',1);  
        $response["key_feature"]                 =   $this->data->PageDataGet('key-feature',2);  
        $response["home_map"]                    =   $this->data->pageDataFirst('home-map',3);  
        $response["about_tag"]                   =   $this->data->pageDataFirst('about-tag',4);  
        $response["download_app"]                =   $this->data->pageDataFirst('download-app',5);  

        return view('frontend.index',compact('response'));
    }
    public function aboutus() {
        $response["about_us"]                =   $this->data->pageDataFirst('about-us',1);  
        return view('frontend.about-us',compact('response'));
    }
    public function contactUs() {
        return view('frontend.contact-us');
    }
    public function faq() {
        $faq        = Faq::where('is_active' , 1 )->get();
        return view('frontend.faq', compact('faq'));
    }
    public function contactRequest(ContactRequest $request){
        
        $contactUs                =  new ContactUs;
        $contactUs->name          =  $request->name ?? '';
        $contactUs->email         =  $request->email ?? '';
        $contactUs->mobile_number =  $request->phone_number ?? '';
        $contactUs->subject       = $request->subject;
        $contactUs->message       = $request->message ?? '';
        $contactUs->save();

        $content = [$contactUs->name, $contactUs->email, $contactUs->mobile_number, $contactUs->subject, $contactUs->message];
        $this->setContent($contactUs->email,$contactUs->name,'user_contact_enquiry',$content);
        $this->setContent(Config('Contact.email_address'),"Admin",'new_enquiry',$content);
        return Redirect()->back()->with('success', trans("Your request has been send successfully."));
    }

    public function termsConditions() {
        return view('frontend.terms-conditions');
    }

    public function privacyPolicy() {
        return view('frontend.privacy-policy');
    }
    
}
