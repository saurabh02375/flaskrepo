<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Storage;

class BusinessDetails extends Model
{
    use HasFactory;

    protected $appends = ['image_url'];

    public function getImageUrlAttribute() {
        if (!empty($this->image) && Storage::disk('public')->exists(Config('constants.USER_IMAGE_ROOT_PATH') . $this->image)) {
            $file = Storage::disk('public')->url(Config('constants.USER_IMAGE_ROOT_PATH').$this->image);
        } 
        else{
            $file = asset('img/users.png');
        }
        return $file;
    }
}
