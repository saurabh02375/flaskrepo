<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Storage;

class Security extends Model
{
    use HasFactory;

    protected $appends = ['portrait_image_url','landscape_image_url'];

    public function getPortraitImageUrlAttribute() {
        
        if (!empty($this->portrait_image) && Storage::disk('public')->exists(Config('constants.SECURITY_IMAGE_ROOT_PATH') . $this->portrait_image)) {
            $file = Storage::disk('public')->url(Config('constants.SECURITY_IMAGE_ROOT_PATH').$this->portrait_image);
        } 
        else{
            $file = asset('img/users.png');
        }
        return $file;
    }
    public function getLandscapeImageUrlAttribute() {
        if (!empty($this->landscape_image) && Storage::disk('public')->exists(Config('constants.SECURITY_IMAGE_ROOT_PATH') . $this->landscape_image)) {
            $file = Storage::disk('public')->url(Config('constants.SECURITY_IMAGE_ROOT_PATH').$this->landscape_image);
        } 
        else{
            $file = asset('img/users.png');
        }
        return $file;
    }


}
