<?php
 
namespace App\Models;
 
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Passport\HasApiTokens;
use Illuminate\Support\Facades\File;
use Storage;
 
class User extends Authenticatable
{
    use Notifiable, HasApiTokens;
 
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];
 
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
 
    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    protected $appends = ['image_url'];

    public function scopeIsDeleted($query){
        return $query->where('is_deleted',0);
    }

    public function getImageUrlAttribute() {
        if (!empty($this->image) && Storage::disk('public')->exists(Config('constants.USER_IMAGE_ROOT_PATH') . $this->image)) {
            $file = Storage::disk('public')->url(Config('constants.USER_IMAGE_ROOT_PATH').$this->image);
        } 
        else{
            $file = asset('img/users.png');
        }
        return $file;
    }

    public function businessDetails() {
        
        return $this->hasOne(BusinessDetails::class,'user_id','id');
    }

       
}