<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\api\AuthConroller as ApiAuthConroller;
use App\Http\Controllers\api\CmsConroller as ApiCmsConroller;
use App\Http\Controllers\api\UsersController as ApiUsersController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware(['GuestApi'])->group(function () {

    Route::controller(ApiCmsConroller::class)->group(function() {
        Route::get('cms','cmsInfo');
        Route::get('faqs','faqs');
        Route::get('contact-us','contactUs');
        Route::post('contact-request','contactRequest');
    });

    Route::controller(ApiAuthConroller::class)->group(function() {
        Route::post('login','login');
        Route::post('organization-signup','organizationSignup');
        Route::post('individual-signup','individualSignup');
        Route::post('otp-verify','otpVerify');
        Route::post('resend-otp','resendOtp');
        Route::post('forgot-password','forgotPassword');
        Route::post('reset-password','resetPassword');
    });
});


Route::middleware(['AuthApi'])->group(function () {
    Route::controller(ApiUsersController::class)->group(function() {
        Route::post('logout','logout');
        Route::get('profile','profile');
        Route::post('individual-profile-request','individualProfileRequest');
        Route::post('organization-profile-request','organizationProfileRequest');
        Route::post('update-notification','updateNotifications');
        Route::post('update-email','updateEmail');
        Route::get('account-delete','accountDelete');
        Route::post('language-update','languageUpdate');
        Route::post('changed-password','changedPasswordRequest');
    });
});
