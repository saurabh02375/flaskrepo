<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Artisan;

use App\Http\Controllers\adminpnlx\LanguageSettingsController as AdminLanguageSettingsController; 
use App\Http\Controllers\adminpnlx\EmailtemplateController as AdminEmailtemplateController; 
use App\Http\Controllers\adminpnlx\OrganizationsController as AdminOrganizationsController; 
use App\Http\Controllers\adminpnlx\DesignationsController as AdminDesignationsController; 
use App\Http\Controllers\adminpnlx\AdminDashboardController as AdminDashboardController; 
use App\Http\Controllers\adminpnlx\IndividualController as AdminIndividualsController; 
use App\Http\Controllers\adminpnlx\LanguagesController as AdminLanguagesController; 
use App\Http\Controllers\adminpnlx\EmailLogsController as AdminEmailLogsController; 
use App\Http\Controllers\adminpnlx\CmspagesController as AdminCmspagesController; 
use App\Http\Controllers\adminpnlx\SecurityController as AdminSecurityController; 
use App\Http\Controllers\adminpnlx\SettingsController as AdminSettingsController; 
use App\Http\Controllers\adminpnlx\LookupsController as AdminLookupsController; 
use App\Http\Controllers\adminpnlx\SeoPageController as AdminSeoPageController; 
use App\Http\Controllers\adminpnlx\LoginController as AdminLoginController; 
use App\Http\Controllers\adminpnlx\StaffController as AdminStaffController; 
use App\Http\Controllers\adminpnlx\FaqController as AdminFaqController; 
use App\Http\Controllers\adminpnlx\AclController as AdminAclController; 
use App\Http\Controllers\adminpnlx\ContactUsController as AdminContactUsController; 
use App\Http\Controllers\adminpnlx\AboutUsController as AdminAboutUsController; 
use App\Http\Controllers\adminpnlx\HomeSettingController as AdminHomeSettingController; 

Route::get('clear-cache', function () {
    Artisan::call('config:cache');
    Artisan::call('route:clear');
    Artisan::call('optimize:clear');
});

Route::prefix('adminpnlx')->group(function () {
    Route::match(['get', 'post'], '', [AdminLoginController::class, 'login'])->name('adminpnlx');
    Route::match(['get', 'post'], 'forget_password', [AdminLoginController::class, 'forgetPassword'])->name('forgetPassword');
    Route::match(['get', 'post'], 'reset_password/{validstring}', [AdminLoginController::class, 'resetPassword'])->name('reset_password/{validstring}');
    Route::match(['get', 'post'], 'save_password', [AdminLoginController::class, 'save_password'])->name('save_password');

    Route::middleware(['AuthAdmin'])->group(function () {
        // Dashboard Route
        Route::get('dashboard', [AdminDashboardController::class, 'showdashboard'])->name('dashboard');
        Route::get('logout', [AdminLoginController::class, 'logout'])->name('logout');
        Route::match(['get', 'post'], 'myaccount', [AdminDashboardController::class, 'myaccount'])->name('myaccount');
        Route::match(['get', 'post'], 'changedPassword', [AdminDashboardController::class, 'changedPassword'])->name('changedPassword');

        // Resource Route Group
        Route::resources([
            'organizations'                     =>      AdminOrganizationsController::class,
            'individuals'                       =>      AdminIndividualsController::class,
            'cms-manager'                       =>      AdminCmspagesController::class,
            'languages'                         =>      AdminLanguagesController::class,
            'faqs'                              =>      AdminFaqController::class,
            'language-settings'                 =>      AdminLanguageSettingsController::class,
            'email-templates'                   =>      AdminEmailtemplateController::class,
            'settings'                          =>      AdminSettingsController::class,
            'acl'                               =>      AdminAclController::class,
            'staff'                             =>      AdminStaffController::class,
            'security'                          =>      AdminSecurityController::class,
            'home-settings'                     =>      AdminHomeSettingController::class,
        ]);


        // home settings 

        Route::post('home-settings/home/store', [AdminHomeSettingController::class, 'store'])->name('homeetting.store');
        // key feature
        Route::post('home-settings/key-feature/store', [AdminHomeSettingController::class, 'KeyFeaturestore'])->name('KeyFeaturestore');
        Route::get('home-settings/Key-feauture/destroy/{enuserid?}', [AdminHomeSettingController::class, 'KeyFeauturedelete'])->name('KeyFeauturedelete');
        Route::get('home-settings/key-feature/{id}', [AdminHomeSettingController::class, 'keyFeatureEdit'])->name('keyFeatureEdit');
        Route::post('home-settings/key-feature/update/{id}', [AdminHomeSettingController::class, 'keyFeatureupdate'])->name('keyFeatureupdate');
        
        Route::post('home-settings/about-tag/store', [AdminHomeSettingController::class, 'aboutTagStore'])->name('aboutTagStore');
            // map
        Route::post('home-settings/map/store', [AdminHomeSettingController::class, 'mapStore'])->name('mapStore');
        // download app
        Route::post('home-settings/download-app/store', [AdminHomeSettingController::class, 'downloadAppStore'])->name('downloadAppStore');
        // Users Route
        Route::get('organizations/destroy/{enuserid?}', [AdminOrganizationsController::class, 'destroy'])->name('organizations.delete');
        Route::get('organizations/update-status/{id}/{status}', [AdminOrganizationsController::class, 'changeStatus'])->name('organizations.status');
        Route::match(['get', 'post'], 'organizations/changed-password/{enuserid?}', [AdminOrganizationsController::class, 'changedPassword'])->name('organizations.changedPassword');
        Route::post('organizations/changed-password-request/{enuserid?}', [AdminOrganizationsController::class, 'changedPasswordRequest'])->name('organizations.changedPasswordRequest');
        Route::get('organizations/send-credentials/{id}', [AdminOrganizationsController::class, 'sendCredentials'])->name('organizations.sendCredentials');
        Route::get('organizations/verified/{id}/{status}', [AdminOrganizationsController::class, 'verifiedStatus'])->name('organizations.verifiedStatus');
        Route::post('organizations/rejected', [AdminOrganizationsController::class, 'rejected'])->name('organizations.rejected');



        // Individuals Route
        Route::get('individuals/destroy/{enuserid?}', [AdminIndividualsController::class, 'destroy'])->name('individuals.delete');
        Route::get('individuals/update-status/{id}/{status}', [AdminIndividualsController::class, 'changeStatus'])->name('individuals.status');
        Route::get('individuals/changed-password/{enuserid?}', [AdminIndividualsController::class, 'changedPassword'])->name('individuals.changedPassword');
        Route::post('individuals/changed-password-request/{enuserid?}', [AdminIndividualsController::class, 'changedPasswordRequest'])->name('individuals.changedPasswordRequest');
        Route::get('individuals/send-credentials/{id}', [AdminIndividualsController::class, 'sendCredentials'])->name('individuals.sendCredentials');

        // CMS Manage Route
        Route::get('cms-manager/destroy/{encmsid?}', [AdminCmspagesController::class, 'destroy'])->name('cms-manager.delete');

        // FAQ Route 
        Route::get('faqs/destroy/{enfaqid?}', [AdminFaqController::class, 'destroy'])->name('faqs.delete');

        // Language Route
        Route::match(['get', 'post'], 'language-settings/update1/{id?}', [AdminLanguageSettingsController::class, 'update1'])->name('language-settings.update1');
        Route::get('languages/update-status/{id}/{status}',[AdminLanguagesController::class, 'changeStatus'])->name('languages.status');

        // Email Templates Route
        Route::match(['get', 'post'], 'email-templates/get-constant',[AdminEmailtemplateController::class, 'getConstant'])->name('email-templates.getConstant');

        // Email Logs Route
        Route::match(['get', 'post'], 'email-logs', [AdminEmailLogsController::class, 'index'])->name('emaillogs.listEmail');
        Route::match(['get', 'post'], 'email-logs/email_details/{enmailid?}', [AdminEmailLogsController::class, 'emailDetail'])->name('emaillogs.emailDetail');

        // Setting Route
        Route::match(['get', 'post'], '/settings/prefix/{enslug?}', [AdminSettingsController::class, 'prefix'])->name('settings.prefix');
        Route::get('settings/destroy/{ensetid?}', [AdminSettingsController::class, 'destroy'])->name('settings.delete');

        // Acl Route
        Route::get('acl/destroy/{enaclid?}', [AdminAclController::class, 'destroy'])->name('acl.delete');
        Route::get('acl/update-status/{id}/{status}', [AdminAclController::class, 'changeStatus'])->name('acl.status');
        Route::post('acl/add-more/add-more', [AdminAclController::class, 'addMoreRow'])->name('acl.addMoreRow');
        Route::get('acl/delete-function/{id}', [AdminAclController::class, 'delete_function'])->name('acl.delete_function');

        // Staff Route
        Route::get('staff/update-status/{id}/{status}', [AdminStaffController::class, 'changeStatus'])->name('staff.status');
        Route::get('staff/destroy/{enstfid?}', [AdminStaffController::class, 'destroy'])->name('staff.delete');
        Route::match(['get', 'post'], 'staff/changed-password/{enstfid?}', [AdminStaffController::class, 'changedPassword'])->name('staff.changerpassword');
        Route::match(['get', 'post'], 'staff/get-designations', [AdminStaffController::class, 'getDesignations'])->name('staff.getDesignations');
        Route::match(['get', 'post'], 'staff/get-staff-permission', [AdminStaffController::class, 'getStaffPermission'])->name('staff.getStaffPermission');

        // Lookups manager Route
        Route::match(['get', 'post'], '/lookups-manager/{type}', [AdminLookupsController::class, 'index'])->name('lookups-manager.index');
        Route::match(['get', 'post'], '/lookups-manager/add/{type}', [AdminLookupsController::class, 'add'])->name('lookups-manager.add');
        Route::get('lookups-manager/destroy/{enlokid?}', [AdminLookupsController::class, 'destroy'])->name('lookups-manager.delete');
        Route::get('lookups-manager/update-status/{id}/{status}', [AdminLookupsController::class, 'changeStatus'])->name('lookups-manager.status');
        Route::match(['get', 'post'], 'lookups-manager/{type?}/edit/{enlokid?}', [AdminLookupsController::class, 'update'])->name('lookups-manager.edit');

        // Seo Route
        Route::match(['get', 'post'],'seo-page-manager', [AdminSeoPageController::class, 'index'])->name('SeoPage.index');
        Route::get('seo-page-manager/add-doc', [AdminSeoPageController::class, 'addDoc'])->name('SeoPage.create');
        Route::post('seo-page-manager/add-doc', [AdminSeoPageController::class, 'saveDoc'])->name('SeoPage.save');
        Route::get('seo-page-manager/edit-doc/{id}', [AdminSeoPageController::class, 'editDoc'])->name('SeoPage.edit');
        Route::post('seo-page-manager/edit-doc/{id}', [AdminSeoPageController::class, 'updateDoc'])->name('SeoPage.update');
        Route::any('seo-page-manager/delete-page/{id}', [AdminSeoPageController::class, 'deletePage'])->name('SeoPage.delete');

        // Designations Route
        Route::match(['get', 'post'], '/designations', [AdminDesignationsController::class, 'index'])->name('designations.index');
        Route::match(['get', 'post'], 'designations/add', [AdminDesignationsController::class, 'add'])->name('designations.add');
        Route::match(['get', 'post'], 'designations/edit/{endesid?}', [AdminDesignationsController::class, 'update'])->name('designations.edit');
        Route::get('designations/update-status/{id}/{status}', [AdminDesignationsController::class, 'changeStatus'])->name('designations.status');
        Route::get('designations/delete/{endesid}', [AdminDesignationsController::class, 'delete'])->name('designations.delete');


        // Security Route
        Route::get('security/destroy/{encmsid?}', [AdminSecurityController::class, 'destroy'])->name('security.delete');
       
        /*Contact-Us routes */
        Route::match(['get', 'post'], '/contact-us-inquiry', [AdminContactUsController::class, 'index'])->name('ContactQuery.index');
        Route::get('/contact-us-inquiry/view/{id}', [AdminContactUsController::class, 'show'])->name('ContactQuery.view');
        Route::match(['get', 'post'], '/contact-us-inquiry/reply-contact-query/{id}', [AdminContactUsController::class, 'reply'])->name('ContactQuery.reply');
        Route::match(['get', 'post'], '/contact-us-inquiry/delete-contact-us/{id}', [AdminContactUsController::class, 'delete'])->name('ContactQuery.delete');
        Route::match(['get', 'post'], '/contact/update-contact-queries-approve-status/{id}/{status}', [AdminContactUsController::class, 'Approvestatus'])->name('ContactQuery.status');
        /*Contact-Us routes */

        Route::get('/about-us',[AdminAboutUsController::class,'index'])->name('about.index');
        Route::post('/about-us/store',[AdminAboutUsController::class,'store'])->name('about.store');
 
   
    });
});

Route::get('/base/uploder', [App\Http\Controllers\Controller::class, 'saveCkeditorImages']);
Route::post('/base/uploder', [App\Http\Controllers\Controller::class, 'saveCkeditorImages']);
