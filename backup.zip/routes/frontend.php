<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\frontend\HomeController as FrontendHomeController;
use App\Http\Controllers\frontend\AuthController as FrontendAuthController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware(['GuestApi'])->group(function () {
    Route::controller(FrontendHomeController::class)->name('web.')->group(function() {
        Route::get('/','index')->name('index');
        Route::get('about-us','aboutus')->name('aboutus');
        Route::get('contact-us','contactUs')->name('contactUs');
        Route::post('contact-request', 'contactRequest')->name('contactRequest');
        Route::get('terms-&-conditions','termsConditions')->name('termsConditions');
        Route::get('privacy-policy','privacyPolicy')->name('privacyPolicy');
        Route::get('faq','faq')->name('faq');
    });

    Route::controller(FrontendAuthController::class)->name('auth.')->group(function() {
        Route::get('login','login')->name('login');
        Route::post('login-request','loginRequest')->name('loginRequest');
        Route::get('forgot-password','forgotPassword')->name('forgotPassword');
        Route::get('otp-verify','otpVerify')->name('otpVerify');
        Route::get('reset-password','resetPassword')->name('resetPassword');
    });
});
