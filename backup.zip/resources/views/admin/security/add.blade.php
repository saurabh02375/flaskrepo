@extends('admin.layouts.layout')
@section('content')
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <div class="subheader py-2 py-lg-4  subheader-solid " id="kt_subheader">
        <div class=" container-fluid  d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
            <div class="d-flex align-items-center flex-wrap mr-1">
                <div class="d-flex align-items-baseline flex-wrap mr-5">
                    <h5 class="text-dark font-weight-bold my-1 mr-5">
                        Add New {{Config('constants.SECURITY.SECURITY_TITLE')}} </h5>
                    <ul class="breadcrumb breadcrumb-transparent breadcrumb-dot font-weight-bold p-0 my-2 font-size-sm">
                        <li class="breadcrumb-item">
                            <a href="{{ route('dashboard')}}" class="text-muted">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route($modelName.'.index')}}" class="text-muted"> {{Config('constants.SECURITY.SECURITY_TITLES')}}</a>
                        </li>
                    </ul>
                </div>
            </div>
            @include("admin.elements.quick_links")
        </div>
    </div>
    <div class="d-flex flex-column-fluid">
        <div class="container">
            <form action="{{route($modelName.'.store')}}" method="post" class="mws-form" autocomplete="off" enctype="multipart/form-data">
                @csrf
                <div class="card card-custom gutter-b">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-xl-1"></div>
                            <div class="col-xl-10">
                                <h3 class="mb-10 font-weight-bold text-dark">
                                    {{Config('constants.SECURITY.SECURITY_TITLE')}} Information
                                </h3>
                                <div class="row">
                                    <div class="col-xl-12">
                                        <div class="form-group">
                                            <label for="title">Title</label><span class="text-danger"> * </span>
                                            <input type="text" name="title" class="form-control form-control-solid form-control-lg @error('title') is-invalid @enderror" value="{{ old('title') }}">
                                            @if ($errors->has('title'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('title') }}
                                            </div>
                                            @endif
                                            
                                        </div>
                                    </div>
                                    <div class="col-xl-6">
                                        <div class="form-group">
                                            <label name="portrait_image">Portrait Image</label><span class="text-danger"> * </span>
                                            <input type="file" name="portrait_image" class="form-control form-control-solid form-control-lg  @error('portrait_image') is-invalid @enderror" value="{{old('portrait_image')}}">
                                            @if ($errors->has('portrait_image'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('portrait_image') }}
                                            </div>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col-xl-6">
                                        <div class="form-group">
                                            <label name="landscape_image">Landscape Image</label><span class="text-danger"> * </span>
                                            <input type="file" name="landscape_image" class="form-control form-control-solid form-control-lg  @error('landscape_image') is-invalid @enderror" value="{{old('landscape_image')}}">
                                            @if ($errors->has('landscape_image'))
                                            <div class="invalid-feedback">
                                                {{ $errors->first('landscape_image') }}
                                            </div>
                                            @endif
                                        </div>
                                    </div>
                                    
                                    <div class="col-xl-12">
                                        <div class="form-group">
                                            <div id="kt-ckeditor-1-toolbar"></div>
                                            <label>Description </label><span class="text-danger"> * </span>
                                            <textarea id="description" name="description" class="form-control form-control-solid form-control-lg  @error('body') is-invalid @enderror" value="{{ old('description') }}">
                                            {{ old('description') }} </textarea>
                                            @if ($errors->has('description'))
                                            <div class="alert invalid-feedback d-block">
                                                {{ $errors->first('description') }}
                                            </div>
                                            @endif
                                            
                                        </div>
                                        <script src="{{asset('/js/ckeditor/ckeditor.js')}}"></script>
                                        <script>
                                            CKEDITOR.replace(<?php echo 'description'; ?>, {
                                                filebrowserUploadUrl: '<?php echo URL()->to('base/uploder'); ?>',
                                                removeButtons:'New Page,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteWord,Save,PasteFromWord,Undo,Redo,Find,Replace,SelectAll,Form,Checkbox,RadioButton,HiddenField,Strike,Subscript,Superscript,Language,Link,Unlink,Anchor,ShowBlocks',
                                                enterMode: CKEDITOR.ENTER_BR
                                            });
                                            CKEDITOR.config.allowedContent = true;
                                            CKEDITOR.config.removePlugins = 'scayt';
                                        </script>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-between border-top mt-5 pt-10">
                                    <div>
                                        <button button type="submit" class="btn btn-success font-weight-bold text-uppercase px-9 py-4">
                                            Submit
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
@stop