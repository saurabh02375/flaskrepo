@extends('admin.layouts.layout')
@section('content')
<!--begin::Content-->
<div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
    <!--begin::Subheader-->
    <div class="subheader py-2 py-lg-4  subheader-solid " id="kt_subheader">
        <div class=" container-fluid  d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
            <!--begin::Info-->
            <div class="d-flex align-items-center flex-wrap mr-1">
                <!--begin::Page Heading-->
                <div class="d-flex align-items-baseline flex-wrap mr-5">
                    <!--begin::Page Title-->
                    <h5 class="text-dark font-weight-bold my-1 mr-5">
                    View {{ $sectionNameSingular }} </h5>
                    <!--end::Page Title-->

                    <!--begin::Breadcrumb-->
                    <ul class="breadcrumb breadcrumb-transparent breadcrumb-dot font-weight-bold p-0 my-2 font-size-sm">
                        <li class="breadcrumb-item">
                             <a href="{{ route('dashboard')}}" class="text-muted">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a href="{{ route($modelName.'.index')}}" class="text-muted">{{ $sectionName }}</a>
                        </li>
                    </ul>
                    <!--end::Breadcrumb-->
                </div>
                <!--end::Page Heading-->
            </div>
            <!--end::Info-->
            @include("admin.elements.quick_links")
        </div>
    </div>
    <!--end::Subheader-->

    <!--begin::Entry-->
    <div class="d-flex flex-column-fluid">
        <!--begin::Container-->
        <div class=" container ">
            <div class="card card-custom gutter-b">
                <!--begin::Header-->
                <div class="card-header card-header-tabs-line">
                    <div class="card-toolbar">
                        <ul class="nav nav-tabs nav-tabs-space-lg nav-tabs-line nav-bold nav-tabs-line-3x"
                            role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" data-toggle="tab" href="#kt_apps_contacts_view_tab_2">
                                    <span class="nav-text">
                                    {{ $sectionNameSingular }} Information
                                    </span>
                                </a>
                            </li>
                             <li class="nav-item">
                                <a class="nav-link" data-toggle="tab" href="#kt_apps_contacts_view_tab_3">
                                    <span class="nav-text">
                                    {{ $sectionNameSingular }} Image
                                    </span>
                                </a>
                            </li>
                            <li class="nav-item">
								<a class="nav-link" data-toggle="tab"
									href="#kt_apps_contacts_view_tab_1">
									<span class="nav-text">
                                     Reply
									</span>
								</a>
							</li>
                        </ul>
                    </div>
                </div>
                <!--end::Header-->

                <!--begin::Body-->
                <div class="card-body px-0">
                    <div class="tab-content px-10">
                        <!--begin::Tab Content-->
                        <div class="tab-pane active" id="kt_apps_contacts_view_tab_2" role="tabpanel">
                            <div class="form-group row my-2">
                                    <label class="col-4 col-form-label">Name:</label>
                                    <div class="col-8">
                                        <span
                                            class="form-control-plaintext font-weight-bolder">{{ isset($result->name) ?ucfirst($result->name) :'' }}</span>
                                    </div>
                                </div>
                                <div class="form-group row my-2">
                                    <label class="col-4 col-form-label">Email:</label>
                                    <div class="col-8">
                                        <span
                                            class="form-control-plaintext font-weight-bolder">{{ isset($result->email) ? $result->email :'' }}</span>
                                    </div>
                                </div>

                                <div class="form-group row my-2">
                                    <label class="col-4 col-form-label">Subject:</label>
                                    <div class="col-8">
                                        <span
                                            class="form-control-plaintext font-weight-bolder">{{ isset($result->subject)?$result->subject:'N/A' }}</span>
                                    </div>
                                </div>
                                <div class="form-group row my-2">
                                    <label class="col-4 col-form-label">Message:</label>
                                    <div class="col-8">
                                        <span
                                            class="form-control-plaintext font-weight-bolder">{{ isset($result->message)?$result->message:'N/A' }}</span>
                                    </div>
                                </div>
                                <div class="form-group row my-2">
                                    <label class="col-4 col-form-label">Message Date:</label>
                                    <div class="col-8">
                                        <span
                                            class="form-control-plaintext font-weight-bolder">{{ isset($result->created_at)?date(Config::get("Reading.date_format"),strtotime($result->created_at)):'N/A' }}</span>
                                    </div>
                                </div>

                                <div class="form-group row my-2">
    								<label class="col-4 col-form-label">Status:</label>
    								<div class="col-8">
    								@if($result->status	== 'open')
    									<span class="label label-lg label-light-success label-inline">Open</span>
    								@elseif($result->status	== 'on_going')
    									<span class="label label-lg label-light-warning label-inline">On Going</span>
    								@elseif($result->status	== 'close')
    									<span class="label label-lg label-light-danger label-inline">Closed</span>
    								@elseif($result->status	== 'archive')
    								<span class="label label-lg label-light-danger label-inline">Archive</span>	
    								@endif
    															
    								</div>
    							</div>
                        </div>

                        <div class="tab-pane" id="kt_apps_contacts_view_tab_3" role="tabpanel">
                            @if(@$result->image)
                            <div class="form-group row my-2">
                                @foreach(explode(",",$result->image) as $image)
                                    <div class="text-dark-75 mb-1 font-size-lg ml-5" style="border: double; padding: 15px;">
                                        <a class="fancybox-buttons" data-fancybox-group="button" href="{{Config('constants.CONTACT_IMAGE_PATH').$image}}"><img height="80px" width="80px" src="{{Config('constants.CONTACT_IMAGE_PATH').$image}}"></a>
                                    </div>
                                @endforeach
                            </div>
                            @endif
                        </div>

                        <div class="tab-pane" id="kt_apps_contacts_view_tab_1" role="tabpanel">
							{{ Form::open(['role' => 'form','url' => route($modelName.'.reply',$result->id),'class' => 'mbs-form','id'=>'replyForm', 'files' => true,"autocomplete"=>"off"]) }}
                            
							<div class="row pad" style='margin-bottom:20px;'>
								<div class="col-xl-12">
									<!--begin::Input-->
									<div class="form-group">
										{!! HTML::decode( Form::label('message', trans("Message").'<span class="text-danger"> * </span>')) !!}
										{{ Form::textarea('message','', ['class' => 'form-control form-control-solid form-control-lg '.($errors->has('message') ? 'is-invalid':''), 'rows' => 5,'id' => "message"]) }}
										<div class="invalid-feedback"><?php echo $errors->first('message'); ?></div>
                                        <script src="{{asset('/public/js/ckeditor/ckeditor.js')}}"></script>
                                        <script>
                                        /* CKEDITOR for description */
                                        CKEDITOR.replace( <?php echo 'message'; ?>,
                                        {
                                            filebrowserUploadUrl : '<?php echo URL::to('base/uploder'); ?>',
                                            enterMode : CKEDITOR.ENTER_BR
                                        });
                                        CKEDITOR.config.allowedContent = true;	
                                        
                                    </script>
									</div>
								</div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="image">Attachment</label>
                                        <input type="file" accept=".pdf,.doc,.jpeg,.jpg,.png" name="image" class="form-control form-control-solid form-control-lg" >
                                    </div>
                                </div>

								<div class="col-xl-12">
									<div class="d-flex justify-content-between">
										<div>
											<button onclick="submit_form();" class="btn btn-success font-weight-bold text-uppercase px-9 py-4">Reply</button>
										</div>
									</div>
								</div>
							</div>
							{{ Form::close() }} 
							<hr>
							<div class="row pad" style='margin-top:20px;'>
								<div class="col-md-12 col-sm-12">
									
									<table class="table table-striped">
										<thead>
											<tr>
												<th width="30%">Message</th>
												
												<th width="20%">Replied at</th>
											</tr>
										</thead>
										<tbody>
										@if(count($contactReplies) > 0)
										@foreach($contactReplies as $row)
										<tr>
											<td  width="20%" data-th='Name' class="txtFntSze">
                                                {!! !empty($row->message)?nl2br($row->message):'' !!}
                                                @if(!empty($row->image))
                                                <br>
                                                <a  download href="<?php echo Config('constants.SEO_PAGE_IMAGE_IMAGE_PATH').$row->image; ?>"> Download Attachment</a>
                                                @endif
                                            </td>

											<td  width="20%" data-th='Name' class="txtFntSze">{{ $row->created_at }}</td>
										</tr>
										@endforeach
										@else
										<tr><td colspan="4" style="text-align:center;">Not replyed yet</td></tr>
										@endif
										</tbody>
									</table>
								</div>
							</div>
						</div>

                        <!--end::Tab Content-->
                    </div>
                </div>
                <!--end::Body-->
            </div>

        </div>
        <!--end::Container-->
    </div>
    <!--end::Entry-->
</div>
<!--end::Content-->
<script>
	function submit_form(){
		$('.mbs-form').submit();
	}
</script>
@stop