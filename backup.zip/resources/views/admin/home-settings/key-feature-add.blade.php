<?php $i = 1; ?>
@extends('admin.layouts.layout')
@section('content')
    <div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
        <div class="subheader py-2 py-lg-4  subheader-solid " id="kt_subheader">
            <div class=" container-fluid  d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
                <div class="d-flex align-items-center flex-wrap mr-1">
                    <div class="d-flex align-items-baseline flex-wrap mr-5">
                        <h5 class="text-dark font-weight-bold my-1 mr-5">
                            Add New {{ config('constants.KEY_FEATURE.KEY_FEATURE_TITLE') }} </h5>
                        <ul class="breadcrumb breadcrumb-transparent breadcrumb-dot font-weight-bold p-0 my-2 font-size-sm">
                            <li class="breadcrumb-item">
                                <a href="{{ route('dashboard') }}" class="text-muted">Dashboard</a>
                            </li>
                            <li class="breadcrumb-item">
                                <a href="{{ route($modelName . '.index') }}" class="text-muted">
                                    {{ Config('constants.HOME_SETTING.HOME_SETTING_TITLES') }}</a>
                            </li>
                        </ul>
                    </div>
                </div>
                @include('admin.elements.quick_links')
            </div>
        </div>
        <div class="d-flex flex-column-fluid">
            <div class="container">
                <form action="{{ route('KeyFeaturestore') }}" method="post" class="mws-form" autocomplete="off"
                    enctype="multipart/form-data">
                    @csrf
                    <div class="card card-custom gutter-b">
                        <div class="card-header">
                            <div class="card-title"> {{ config('constants.KEY_FEATURE.KEY_FEATURE_TITLE') }} Information
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="tab-content">
                                <div class="row">
                                    <div class="col-xl-6">
                                        <div class="form-group">
                                            <label for="image">Image</label><span class="text-danger"> * </span>
                                            <input type="file" name="image"
                                                class="form-control form-control-solid form-control-lg @error('image') is-invalid @enderror"
                                                value="">
                                            @error('image')
                                                <div class="invalid-feedback">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-xl-6">
                                        <div class="form-group">
                                            <label>Title</label><span class="text-danger"> *</span>
                                            <input type="text" name="title"
                                                class="form-control form-control-solid form-control-lg @error('title') is-invalid @enderror"
                                                value="{{ old('title') }}">
                                            @error('title')
                                                <div class="invalid-feedback d-block text-danger">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                    </div>
                                    <div class="col-xl-12">
                                        <div class="form-group">
                                            <div id="kt-ckeditor-1-toolbar"></div>
                                            <label>Description </label><span class="text-danger"> *</span>
                                            <textarea id="body" name="description"
                                                class="form-control form-control-solid form-control-lg @error('description') is-invalid @enderror">{{ old('description') }}</textarea>
                                            @error('description')
                                                <div class="invalid-feedback d-block text-danger">
                                                    {{ $message }}
                                                </div>
                                            @enderror
                                        </div>
                                        <script src="{{ asset('/js/ckeditor/ckeditor.js') }}"></script>
                                        <script>
                                            CKEDITOR.replace('body', {
                                                filebrowserUploadUrl: '<?php echo URL()->to('base/uploader'); ?>',
                                                removeButtons: 'New Page,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteWord,Save,PasteFromWord,Undo,Redo,Find,Replace,SelectAll,Form,Checkbox,RadioButton,HiddenField,Strike,Subscript,Superscript,Language,Link,Unlink,Anchor,ShowBlocks',
                                                enterMode: CKEDITOR.ENTER_BR
                                            });
                                            CKEDITOR.config.allowedContent = true;
                                            CKEDITOR.config.removePlugins = 'scayt';
                                        </script>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-between border-top mt-5 pt-10">
                                    <div>
                                        <button button type="submit"
                                            class="btn btn-success font-weight-bold text-uppercase px-9 py-4">
                                            Submit
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>
                </form>
            </div>
        </div>
    </div>
@stop
