@extends('admin.layouts.layout')
@section('content')
    <div class="content  d-flex flex-column flex-column-fluid" id="kt_content">
        <div class="subheader py-2 py-lg-4  subheader-solid " id="kt_subheader">
            <div class=" container-fluid  d-flex align-items-center justify-content-between flex-wrap flex-sm-nowrap">
                <div class="d-flex align-items-center flex-wrap mr-1">
                    <div class="d-flex align-items-baseline flex-wrap mr-5">
                        <h5 class="text-dark font-weight-bold my-1 mr-5">
                            {{ Config('constants.HOME_SETTING.HOME_SETTING_TITLES') }} </h5>
                        <ul class="breadcrumb breadcrumb-transparent breadcrumb-dot font-weight-bold p-0 my-2 font-size-sm">
                            <li class="breadcrumb-item">
                                <a href="{{ route('dashboard') }}" class="text-muted">Dashboard</a>
                            </li>
                        </ul>
                    </div>
                </div>
                @include('admin.elements.quick_links')
            </div>
        </div>
        <div class="d-flex flex-column-fluid">
            <div class="container">
                <form action="{{ route($modelName . '.store') }}" method="post" class="mws-form" autocomplete="off"
                    enctype="multipart/form-data">
                    @csrf
                    <div class="card card-custom gutter-b">
                        <div class="card-header">
                            <div class="card-title">Home Introduction</div>
                        </div>
                        <div class="card-body">
                            <div class="tab-content">
                                <div class="tab-pane fade show active" id="description" role="tabpanel"
                                    aria-labelledby="description">
                                    <div class="row">
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label for="image">Image</label><span class="text-danger"> * </span>
                                                <input type="file" name="image"
                                                    class="form-control form-control-solid form-control-lg @error('image') is-invalid @enderror"
                                                    value="">
                                                @if ($errors->has('image'))
                                                    <div class="invalid-feedback">
                                                        {{ $errors->first('image') }}
                                                    </div>
                                                @endif
                                                @if (!empty($homeintro->image))
                                                    <a class="fancybox-buttons"
                                                        data-fancybox-group="button"href="{{ url($homeintro->image_url) }}">
                                                        <img width="50px" height="50px"
                                                            src="{{ url($homeintro->image_url) }}" />
                                                    </a>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label>Title</label><span class="text-danger"> *</span>
                                                <input type="text" name="title"
                                                    class="form-control form-control-solid form-control-lg @error('title') is-invalid @enderror"
                                                    value="{{ $homeintro->title ?? old('title') }}">
                                                @if ($errors->has('title'))
                                                    <div class="invalid-feedback d-block text-danger">
                                                        {{ $errors->first('title') }}
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-xl-12">
                                            <div class="form-group">
                                                <div id="kt-ckeditor-1-toolbar"></div>
                                                <label>Description </label><span class="text-danger"> *</span>
                                                <textarea id="body" name="description"
                                                    class="form-control form-control-solid form-control-lg @error('description') is-invalid @enderror">{{ $homeintro->description ?? old('description') }}</textarea>
                                                @if ($errors->has('description'))
                                                    <div class="invalid-feedback d-block text-danger">
                                                        {{ $errors->first('description') }}
                                                    </div>
                                                @endif
                                            </div>
                                            <script src="{{ asset('/js/ckeditor/ckeditor.js') }}"></script>
                                            <script>
                                                CKEDITOR.replace('body', {
                                                    filebrowserUploadUrl: '<?php echo URL()->to('base/uploder'); ?>',
                                                    removeButtons: 'New Page,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteWord,Save,PasteFromWord,Undo,Redo,Find,Replace,SelectAll,Form,Checkbox,RadioButton,HiddenField,Strike,Subscript,Superscript,Language,Link,Unlink,Anchor,ShowBlocks',
                                                    enterMode: CKEDITOR.ENTER_BR
                                                });
                                                CKEDITOR.config.allowedContent = true;
                                                CKEDITOR.config.removePlugins = 'scayt';
                                            </script>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between border-top mt-5 pt-10">
                                <div>
                                    <button button type="submit"
                                        class="btn btn-success font-weight-bold text-uppercase px-9 py-4">
                                        Submit
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="d-flex flex-column-fluid mb-3">
            <div class=" container ">
                <form action="" method="get" class="kt-form kt-form--fit mb-0" autocomplete="off">
                    <input type="hidden" name="display">
                    @csrf
                    <div class="row">
                        <div class="col-12">
                            <div class="card card-custom card-stretch card-shadowless">
                                <div class="card-header">
                                    <div class="card-title">
                                        KEY FEATURES OF WILDTAG
                                    </div>
                                    <div class="card-toolbar">
                                        <a href="{{ route($modelName . '.create') }}" class="btn btn-primary">Add New
                                            {{ config('constants.KEY_FEATURE.KEY_FEATURE_TITLE') }}</a>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="dataTables_wrapper">
                                        <div class="table-responsive">
                                            <table
                                                class="table dataTable table-head-custom table-head-bg table-borderless table-vertical-center"
                                                id="taskTable">
                                                <thead>
                                                    <tr class="text-uppercase">
                                                        <th>image</th>
                                                        <th>Title</th>
                                                        <th>Description</th>
                                                        <th class="text-right">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="powerwidgets">
                                                    @if ($keyfeature)
                                                        @foreach ($keyfeature as $result)
                                                            <tr>
                                                                <td>
                                                                    <div class="text-dark-75 mb-1 font-size-lg">
                                                                        @if (!empty($result->image))
                                                                            <a class="fancybox-buttons"
                                                                                data-fancybox-group="button"href="{{ $result->image_url }}">
                                                                                <img width="70px" height="70"
                                                                                    src="{{ $result->image_url }}" />
                                                                            </a>
                                                                        @endif
                                                                    </div>
                                                                </td>
                                                                <td>
                                                                    <div class="text-dark-75 mb-1 font-size-lg">
                                                                        {{ ucfirst($result->title) ?? '' }}</div>
                                                                </td>
                                                                <td>
                                                                    <div class="text-dark-75 mb-1 font-size-lg">
                                                                        {!! $result->description !!}
                                                                    </div>
                                                                </td>
                                                                <td class="text-right pr-2">
                                                                    <a href="{{ route('keyFeatureEdit', base64_encode($result->id)) }}"
                                                                        class="btn btn-icon btn-light btn-hover-primary btn-sm"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        data-container="body" data-boundary="window"
                                                                        title="" data-original-title="Edit">
                                                                        <span
                                                                            class="svg-icon svg-icon-md svg-icon-primary">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                                width="24px" height="24px"
                                                                                viewBox="0 0 24 24" version="1.1">
                                                                                <g stroke="none" stroke-width="1"
                                                                                    fill="none" fill-rule="evenodd">
                                                                                    <rect x="0" y="0" width="24"
                                                                                        height="24" />
                                                                                    <path
                                                                                        d="M3,16 L5,16 C5.55228475,16 6,15.5522847 6,15 C6,14.4477153 5.55228475,14 5,14 L3,14 L3,12 L5,12 C5.55228475,12 6,11.5522847 6,11 C6,10.4477153 5.55228475,10 5,10 L3,10 L3,8 L5,8 C5.55228475,8 6,7.55228475 6,7 C6,6.44771525 5.55228475,6 5,6 L3,6 L3,4 C3,3.44771525 3.44771525,3 4,3 L10,3 C10.5522847,3 11,3.44771525 11,4 L11,19 C11,19.5522847 10.5522847,20 10,20 L4,20 C3.44771525,20 3,19.5522847 3,19 L3,16 Z"
                                                                                        fill="#000000" opacity="0.3" />
                                                                                    <path
                                                                                        d="M16,3 L19,3 C20.1045695,3 21,3.8954305 21,5 L21,15.2485298 C21,15.7329761 20.8241635,16.200956 20.5051534,16.565539 L17.8762883,19.5699562 C17.6944473,19.7777745 17.378566,19.7988332 17.1707477,19.6169922 C17.1540423,19.602375 17.1383289,19.5866616 17.1237117,19.5699562 L14.4948466,16.565539 C14.1758365,16.200956 14,15.7329761 14,15.2485298 L14,5 C14,3.8954305 14.8954305,3 16,3 Z"
                                                                                        fill="#000000" />
                                                                                </g>
                                                                            </svg>
                                                                        </span>
                                                                    </a>
                                                                    <a href="{{ route('KeyFeauturedelete', base64_encode($result->id)) }}"
                                                                        class="btn btn-icon btn-light btn-hover-danger btn-sm confirmDelete"
                                                                        data-toggle="tooltip" data-placement="top"
                                                                        data-container="body" data-boundary="window"
                                                                        title="" data-original-title="Delete">
                                                                        <span class="svg-icon svg-icon-md svg-icon-danger">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                xmlns:xlink="http://www.w3.org/1999/xlink"
                                                                                width="24px" height="24px"
                                                                                viewBox="0 0 24 24" version="1.1">
                                                                                <g stroke="none" stroke-width="1"
                                                                                    fill="none" fill-rule="evenodd">
                                                                                    <rect x="0" y="0" width="24"
                                                                                        height="24" />
                                                                                    <path
                                                                                        d="M6,8 L6,20.5 C6,21.3284271 6.67157288,22 7.5,22 L16.5,22 C17.3284271,22 18,21.3284271 18,20.5 L18,8 L6,8 Z"
                                                                                        fill="#000000"
                                                                                        fill-rule="nonzero" />
                                                                                    <path
                                                                                        d="M14,4.5 L14,4 C14,3.44771525 13.5522847,3 13,3 L11,3 C10.4477153,3 10,3.44771525 10,4 L10,4.5 L5.5,4.5 C5.22385763,4.5 5,4.72385763 5,5 L5,5.5 C5,5.77614237 5.22385763,6 5.5,6 L18.5,6 C18.7761424,6 19,5.77614237 19,5.5 L19,5 C19,4.72385763 18.7761424,4.5 18.5,4.5 L14,4.5 Z"
                                                                                        fill="#000000" opacity="0.3" />
                                                                                </g>
                                                                            </svg>
                                                                        </span>
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                    @else
                                                        <tr>
                                                            <td colspan="6" style="text-align:center;">
                                                                {{ trans('Record not found.') }}</td>
                                                        </tr>
                                                    @endif
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="d-flex flex-column-fluid">
            <div class="container">
                <form action="{{ route('mapStore') }}" method="post" class="mws-form" autocomplete="off"
                    enctype="multipart/form-data">
                    @csrf
                    <div class="card card-custom gutter-b">
                        <div class="card-header">
                            <div class="card-title">Home View Map</div>
                        </div>
                        <div class="card-body">
                            <div class="tab-content">
                                <div class="tab-pane fade show active" id="description" role="tabpanel"
                                    aria-labelledby="description">
                                    <div class="row">
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label>Url</label><span class="text-danger"> *</span>
                                                <input type="text" name="map_url"
                                                    class="form-control form-control-solid form-control-lg @error('map_url') is-invalid @enderror"
                                                    value="{{ $viewmap->other ?? old('map_url') }}">
                                                @if ($errors->has('map_url'))
                                                    <div class="invalid-feedback d-block text-danger">
                                                        {{ $errors->first('map_url') }}
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label>Title</label><span class="text-danger"> *</span>
                                                <input type="text" name="map_title"
                                                    class="form-control form-control-solid form-control-lg @error('map_title') is-invalid @enderror"
                                                    value="{{ $viewmap->title ?? old('map_title') }}">
                                                @if ($errors->has('map_title'))
                                                    <div class="invalid-feedback d-block text-danger">
                                                        {{ $errors->first('map_title') }}
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-xl-12">
                                            <div class="form-group">
                                                <div id="kt-ckeditor-1-toolbar"></div>
                                                <label>Description </label><span class="text-danger"> *</span>
                                                <textarea id="body_11" name="map_description"
                                                    class="form-control form-control-solid form-control-lg @error('map_description') is-invalid @enderror">{{ $viewmap->description ?? old('map_description') }}</textarea>
                                                @if ($errors->has('map_description'))
                                                    <div class="invalid-feedback d-block text-danger">
                                                        {{ $errors->first('map_description') }}
                                                    </div>
                                                @endif
                                            </div>
                                            <script src="{{ asset('/js/ckeditor/ckeditor.js') }}"></script>
                                            <script>
                                                CKEDITOR.replace('body_11', {
                                                    filebrowserUploadUrl: '<?php echo URL()->to('base/uploder'); ?>',
                                                    removeButtons: 'New Page,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteWord,Save,PasteFromWord,Undo,Redo,Find,Replace,SelectAll,Form,Checkbox,RadioButton,HiddenField,Strike,Subscript,Superscript,Language,Link,Unlink,Anchor,ShowBlocks',
                                                    enterMode: CKEDITOR.ENTER_BR
                                                });
                                                CKEDITOR.config.allowedContent = true;
                                                CKEDITOR.config.removePlugins = 'scayt';
                                            </script>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between border-top mt-5 pt-10">
                                <div>
                                    <button button type="submit"
                                        class="btn btn-success font-weight-bold text-uppercase px-9 py-4">
                                        Submit
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="d-flex flex-column-fluid">
            <div class="container">
                <form action="{{ route('aboutTagStore') }}" method="post" class="mws-form" autocomplete="off"
                    enctype="multipart/form-data">
                    @csrf
                    <div class="card card-custom gutter-b">
                        <div class="card-header">
                            <div class="card-title">ABOUT WILDTAG </div>
                        </div>
                        <div class="card-body">
                            <div class="tab-content">
                                <div class="tab-pane fade show active" id="description" role="tabpanel"
                                    aria-labelledby="description">
                                    <div class="row">
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label for="image">Image</label><span class="text-danger"> * </span>
                                                <input type="file" name="about_image"
                                                    class="form-control form-control-solid form-control-lg @error('about_image') is-invalid @enderror"
                                                    value="">
                                                @if ($errors->has('about_image'))
                                                    <div class="invalid-feedback">
                                                        {{ $errors->first('about_image') }}
                                                    </div>
                                                @endif
                                                @if (!empty($aboutTag->image))
                                                    <a class="fancybox-buttons"
                                                        data-fancybox-group="button"href="{{ url($aboutTag->image_url) }}">
                                                        <img width="50px" height="50px"
                                                            src="{{ url($aboutTag->image_url) }}" />
                                                    </a>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label>Title</label><span class="text-danger"> *</span>
                                                <input type="text" name="about_title"
                                                    class="form-control form-control-solid form-control-lg @error('about_title') is-invalid @enderror"
                                                    value="{{ $aboutTag->title ?? old('about_title') }}">
                                                @if ($errors->has('about_title'))
                                                    <div class="invalid-feedback d-block text-danger">
                                                        {{ $errors->first('about_title') }}
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                        @if (isset($aboutTag))
                                            @php
                                                $descriptions = json_decode($aboutTag->description);
                                            @endphp
                                        @endif
                                        <div class="col-xl-10">
                                            <div class="form-group">
                                                <label>Description</label><span class="text-danger"> *</span>
                                                <div id="titleInputs">
                                                    @if (isset($aboutTag) && !empty($aboutTag->description))
                                                        <div class="contact-us-inner-form mt-4 d-flex">
                                                            <input type="text" class="form-control"
                                                                name="about_description[]" placeholder="Description"
                                                                value="{{ $descriptions[0] }}">
                                                            <a href="javascript:void(0);"
                                                                class="mx-3 btn btn-icon btn-light-primary adddescriptionBtn">
                                                                <i class="flaticon2-add-1"></i>
                                                            </a>
                                                        </div>
                                                        @if ($errors->has('about_description'))
                                                            <div class="invalid-feedback d-block text-danger">
                                                                {{ $errors->first('about_description') }}
                                                            </div>
                                                        @endif
                                                        @foreach (array_slice($descriptions, 1) as $description)
                                                            <div class="contact-us-inner-form mt-4 d-flex">
                                                                <input type="text" class="form-control"
                                                                    name="about_description[]" placeholder="Description"
                                                                    value="{{ $description }}">
                                                                <a href="javascript:void(0);"
                                                                    class="mx-2 btn btn-icon btn-danger btn-circle removeTitleBtn">
                                                                    <i class="flaticon2-trash"></i>
                                                                </a>
                                                            </div>
                                                        @endforeach
                                                    @else
                                                        <div class="contact-us-inner-form mt-4 d-flex">
                                                            <input type="text" class="form-control"
                                                                name="about_description[]" placeholder="Description">
                                                            <a href="javascript:void(0);"
                                                                class="mx-3 btn btn-icon btn-light-primary adddescriptionBtn">
                                                                <i class="flaticon2-add-1"></i>
                                                            </a>
                                                        </div>
                                                    @endif
                                                </div>
                                                @if ($errors->has('about_description'))
                                                    <div class="invalid-feedback d-block text-danger">
                                                        {{ $errors->first('about_description') }}
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between border-top mt-5 pt-10">
                                <div>
                                    <button button type="submit"
                                        class="btn btn-success font-weight-bold text-uppercase px-9 py-4">
                                        Submit
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="d-flex flex-column-fluid">
            <div class="container">
                <form action="{{ route('downloadAppStore') }}" method="post" class="mws-form" autocomplete="off"
                    enctype="multipart/form-data">
                    @csrf
                    <div class="card card-custom gutter-b">
                        <div class="card-header">
                            <div class="card-title">Download the App</div>
                        </div>
                        <div class="card-body">
                            <div class="tab-content">
                                <div class="tab-pane fade show active" id="description" role="tabpanel"
                                    aria-labelledby="description">
                                    <div class="row">
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label for="image">Image</label><span class="text-danger"> * </span>
                                                <input type="file" name="download_image"
                                                    class="form-control form-control-solid form-control-lg @error('download_image') is-invalid @enderror"
                                                    value="">
                                                @if ($errors->has('download_image'))
                                                    <div class="invalid-feedback">
                                                        {{ $errors->first('download_image') }}
                                                    </div>
                                                @endif
                                                @if (!empty($downloadapp->image))
                                                    <a class="fancybox-buttons"
                                                        data-fancybox-group="button"href="{{ url($downloadapp->image_url) }}">
                                                        <img width="50px" height="50px"
                                                            src="{{ url($downloadapp->image_url) }}" />
                                                    </a>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-xl-6">
                                            <div class="form-group">
                                                <label>Title</label><span class="text-danger"> *</span>
                                                <input type="text" name="download_title"
                                                    class="form-control form-control-solid form-control-lg @error('download_title') is-invalid @enderror"
                                                    value="{{ $downloadapp->title ?? old('download_title') }}">
                                                @if ($errors->has('download_title'))
                                                    <div class="invalid-feedback d-block text-danger">
                                                        {{ $errors->first('download_title') }}
                                                    </div>
                                                @endif
                                            </div>
                                        </div>
                                        <div class="col-xl-12">
                                            <div class="form-group">
                                                <div id="kt-ckeditor-1-toolbar"></div>
                                                <label>Description </label><span class="text-danger"> *</span>
                                                <textarea id="body_23" name="download_description"
                                                    class="form-control form-control-solid form-control-lg @error('download_description') is-invalid @enderror">{{ $downloadapp->description ?? old('download_description') }}</textarea>
                                                @if ($errors->has('download_description'))
                                                    <div class="invalid-feedback d-block text-danger">
                                                        {{ $errors->first('download_description') }}
                                                    </div>
                                                @endif
                                            </div>
                                            <script src="{{ asset('/js/ckeditor/ckeditor.js') }}"></script>
                                            <script>
                                                CKEDITOR.replace('body_23', {
                                                    filebrowserUploadUrl: '<?php echo URL()->to('base/uploder'); ?>',
                                                    removeButtons: 'New Page,Preview,Print,Templates,Cut,Copy,Paste,PasteText,PasteWord,Save,PasteFromWord,Undo,Redo,Find,Replace,SelectAll,Form,Checkbox,RadioButton,HiddenField,Strike,Subscript,Superscript,Language,Link,Unlink,Anchor,ShowBlocks',
                                                    enterMode: CKEDITOR.ENTER_BR
                                                });
                                                CKEDITOR.config.allowedContent = true;
                                                CKEDITOR.config.removePlugins = 'scayt';
                                            </script>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between border-top mt-5 pt-10">
                                <div>
                                    <button button type="submit"
                                        class="btn btn-success font-weight-bold text-uppercase px-9 py-4">
                                        Submit
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            var titleCount = 0;
            $('body').on("click", ".adddescriptionBtn", function() {
                titleCount++;
                var html = `<div class="contact-us-inner-form mt-4 d-flex">
                        <input type="text" class="form-control" name="about_description[]" placeholder="Description">
                        <a href="javascript:void(0);" class="mx-2 btn btn-icon btn-danger btn-circle removeTitleBtn">
                            <i class="flaticon2-trash"></i>
                        </a>
                    </div>`;
                $('#titleInputs').append(html);
            });
            $('body').on("click", ".removeTitleBtn", function() {
                var removeButton = $(this);
                removeButton.parent().remove();

            });
        });
    </script>
@stop
