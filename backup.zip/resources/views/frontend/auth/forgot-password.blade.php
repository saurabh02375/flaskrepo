@extends("frontend.layouts.default")
@section("title","Forgot Password")
@section("content")
<div class="section-box" style="background: linear-gradient(rgb(27 60 100 / 60%), rgb(27 60 100 / 60%)), linear-gradient(rgb(27 60 100 / 50%), rgb(27 60 100 / 50%)), url({{asset('frontend/img/login-bg.png')}});">
    <div class="container">
        <div>
            <a href="{{route('web.index')}}" class="logo-box">
                <img src="{{asset('frontend/img/login-logo.png')}}" alt="">
            </a>
            <div class="login-box login-page">
                <div class="form-header">
                    <div class="login-header text-center">
                        <h2 class="form-heading login-title">Forgot Password</h2>
                        <p class="login-sub-title">Forgot your password? No Worries! Enter your email to reset it.</p>
                    </div>
                    <form action="#" class="form_input_box">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" placeholder="Enter Email Address">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="button-box">
                                    <button class="btn-primary w-100">Login</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@stop