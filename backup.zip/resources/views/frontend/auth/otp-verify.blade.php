@extends("frontend.layouts.default")
@section("title","OTP Verify")
@section("content")
<div class="section-box" style="background: linear-gradient(rgb(27 60 100 / 60%), rgb(27 60 100 / 60%)), linear-gradient(rgb(27 60 100 / 50%), rgb(27 60 100 / 50%)), url({{asset('frontend/img/login-bg.png')}});">
    <div class="container">
        <div>
            <a href="{{route('web.index')}}" class="logo-box">
                <img src="{{asset('frontend/img/login-logo.png')}}" alt="">
            </a>
            <div class="login-box login-page">
                <div class="form-header">
                    <div class="login-header text-center">
                        <h2 class="form-heading login-title">Enter Security Code</h2>
                        <p class="login-sub-title">Enter security code to verify your account.</p>
                    </div>         
                    <form action="#" class="otp_verificationBlock">
                       <div class="col-12">
                        <div class="otp_verification">
                            <input class="otp form-control dark-form-control" type="text" oninput='digitValidate(this)' onkeyup='tabChange(1)' maxlength=1 >
                            <input class="otp form-control dark-form-control" type="text" oninput='digitValidate(this)' onkeyup='tabChange(2)' maxlength=1 >
                            <input class="otp form-control dark-form-control" type="text" oninput='digitValidate(this)' onkeyup='tabChange(3)' maxlength=1 >
                            <input class="otp form-control dark-form-control" type="text" oninput='digitValidate(this)'onkeyup='tabChange(4)' maxlength=1 >
                            </div>
                       </div>
                        <div class="col-12">
                            <div class="button-box">
                                <button class="btn-primary w-100">Submit</button>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="receive-code">Didn't receive the Code? <a href="#!" class="resend-links">Resend Code</a></div>
                        </div>
                      </form>
                </div>
            </div>
        </div>
    </div>
</div>
@stop