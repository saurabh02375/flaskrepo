@extends("frontend.layouts.default")
@section("title","Login")
@section("content")
<div class="section-box" style="background: linear-gradient(rgb(27 60 100 / 60%), rgb(27 60 100 / 60%)), linear-gradient(rgb(27 60 100 / 50%), rgb(27 60 100 / 50%)), url({{asset('frontend/img/login-bg.png')}});">
    <div class="container">
        <div>
            <a href="{{route('web.index')}}" class="logo-box">
                <img src="{{asset('frontend/img/login-logo.png')}}" alt="">
            </a>
            <div class="login-box login-page">
                <div class="form-header">
                    <div class="login-header text-center">
                        <h2 class="form-heading login-title"> Welcome to Wildtag</h2>
                        <p class="login-sub-title">Please enter your credentials to access your account </p>
                    </div>
                    <form action="{{route('auth.loginRequest')}}" method="POST" class="form_input_box">
                        @csrf
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-label">Email</label>
                                    <input type="text" class="form-control" name="email" placeholder="Enter Email Address">
                                    @if ($errors->has('email'))
                                        <div class="text-danger">{{ $errors->first('email') }}</div>
                                    @endif
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group">
                                    <label class="form-label">Password</label>
                                    <div class="input_iconBox">
                                        <input type="password" name="password" class="form-control" placeholder="Enter your Password"
                                            id="password">
                                        <span toggle="#password" class="toggle-password  password_icon">
                                            <svg class="password_showIcon" width="20" height="20" viewBox="0 0 18 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M17.981 7.01978C17.0627 4.61779 14.0136 0.870605 8.96739 0.870605C3.92115 0.870605 0.89677 4.58864 -0.0136719 6.99955C-0.0136719 6.99955 2.15895 13.3082 8.96739 13.1256C14.2388 13.1256 17.4064 8.81492 17.981 7.01978C18.0952 6.91802 17.8668 7.12154 17.981 7.01978ZM8.96739 10.8105C6.83715 10.8105 5.11036 9.08347 5.11036 6.95347C5.11036 4.82347 6.83715 3.09643 8.96739 3.09643C11.0974 3.09643 12.8244 4.82347 12.8244 6.95347C12.8244 9.08347 11.0974 10.8105 8.96739 10.8105Z" fill="#1B3C64"/>
                                                <path d="M8.84712 5.30786C7.8528 5.30786 7.04712 6.11378 7.04712 7.10786C7.04712 8.10194 7.8528 8.90786 8.84712 8.90786C9.8412 8.90786 10.6471 8.10194 10.6471 7.10786C10.6471 6.11378 9.8412 5.30786 8.84712 5.30786Z" fill="#1B3C64"/>
                                                </svg>
                                                <svg class="password_hideIcon" width="20" height="20" viewBox="0 0 18 15" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M8.86279 5.14997L11.4395 7.72665L11.4518 7.59168C11.4518 6.23789 10.3516 5.1377 8.99776 5.1377L8.86279 5.14997Z" fill="#1B3C64"/>
                                                    <path d="M8.99795 3.50103C11.2556 3.50103 13.0879 5.33335 13.0879 7.59102C13.0879 8.11863 12.9816 8.6217 12.7976 9.08385L15.1902 11.4765C16.4254 10.4458 17.3988 9.1125 18 7.59102C16.5808 4.00003 13.092 1.45605 8.99798 1.45605C7.85278 1.45605 6.75669 1.66054 5.73828 2.02864L7.50515 3.79141C7.96727 3.61146 8.47034 3.50103 8.99795 3.50103Z" fill="#1B3C64"/>
                                                    <path d="M0.817983 1.27244L2.68301 3.13747L3.05521 3.50967C1.70552 4.56488 0.638037 5.96776 0 7.59145C1.41515 11.1824 4.90798 13.7264 8.99797 13.7264C10.2659 13.7264 11.4765 13.481 12.5849 13.0352L12.9326 13.3829L15.317 15.7714L16.36 14.7326L1.86093 0.229492L0.817983 1.27244ZM5.34153 5.79188L6.60533 7.05568C6.56852 7.23156 6.54398 7.40741 6.54398 7.59145C6.54398 8.94525 7.64417 10.0454 8.99797 10.0454C9.18202 10.0454 9.3579 10.0209 9.52968 9.98409L10.7935 11.2479C10.2495 11.5178 9.64421 11.6814 8.99797 11.6814C6.7403 11.6814 4.90798 9.84912 4.90798 7.59145C4.90798 6.94525 5.07159 6.33992 5.34153 5.79188Z" fill="#1B3C64"/>
                                                </svg>
                                        </span>
                                    </div>
                                    @if ($errors->has('password'))
                                        <div class="text-danger">{{ $errors->first('password') }}</div>
                                    @endif
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="account-register-box">
                                    <div class="form-custom-check">
                                        <div class="custom-control custom-checkbox">
                                            <div class="form-group  mb-0 custom_checkbox d-flex align-items-center ">
                                                <input type="checkbox" name="" id="check1">
                                                <label for="check1">Remember me</label>
                                            </div>
                                        </div>
                                    </div>
                                    <a href="{{route('auth.forgotPassword')}}" class="forgot-password">Forgot Password?</a>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="button-box">
                                    <button class="btn-primary w-100">Login</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@stop