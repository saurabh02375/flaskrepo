@extends('frontend.layouts.default')
@section('content')
    <!-- top section -->
    <section class="banner-section" style="background-image: url({{ asset('frontend/img/banner-bgImg.png') }});">
        <div class="banner-sectionImg">
            <img src="{{ asset('frontend/img/banner-left.png') }}" alt="" class="left-img">
            <img src="{{ asset('frontend/img/banner-right.png') }}" alt="" class="right-img">
        </div>
        <div class="container">
            <div class="breadcrumb_box">
                <nav aria-label="breadcrumb">
                    <div class="page_banner_heading">
                        FAQ
                    </div>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">FAQ</li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>
    <!-- top section end -->
    <section class="faq-page-wrapper section_padding">
        <div class="container">
            <div class="faq-page-block">
                @if ($faq->IsNotEmpty())
                    <div class="accordion" id="common-questions">
                        <div class="accordion DashboardBoxFrame" id="accordionfaq1">
                            @foreach ($faq as $index => $item)
                                <div class="accordion-item {{ $index === 0 ? 'active' : '' }}">
                                    <div class="accordion-header" id="heading{{ $index + 1 }}">
                                        <h2 class="accordion-button faq-accord {{ $index === 0 ? '' : 'collapsed' }}"
                                            data-bs-toggle="collapse" data-bs-target="#collapse{{ $index + 1 }}"
                                            aria-expanded="{{ $index === 0 ? 'true' : 'false' }}"
                                            aria-controls="collapse{{ $index + 1 }}">
                                            {{ $item['question'] }}
                                        </h2>
                                    </div>
                                    <div id="collapse{{ $index + 1 }}"
                                        class="accordion-collapse collapse {{ $index === 0 ? 'show' : '' }}"
                                        aria-labelledby="heading{{ $index + 1 }}" data-bs-parent="#accordionfaq1">
                                        <div class="accordion-body">
                                            <div class="faq_Questions_title">
                                                <p>
                                                    {{ $item['answer'] }}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    </div>
                @endif
            </div>
        </div>
    </section>
@stop
