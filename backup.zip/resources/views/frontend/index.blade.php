@extends('frontend.layouts.default')
@section('title', 'Home')
@section('content')
    <!-- top section -->
    @if (!empty($response['home-intro']))
        <section class="heroBanner-section section-wrapper"
            style="background: linear-gradient(to bottom, rgb(0 4 108 / 50%), rgb(16 47 53 / 50%)), url({{ $response['home-intro']->image_url }});">
            <div class="banner-sectionImg">
                <img src="{{ asset('frontend/img/banner-left.png') }}" alt="" class="left-img">
                <img src="{{ asset('frontend/img/banner-right.png') }}" alt="" class="right-img">
            </div>
            <div class="container">
                <div class="heroBanner-block">
                    <h2 class="heroBanner-head">{{ $response['home-intro']->title }}</h2>
                    <p class="heroBanner-subText">{{ $response['home-intro']->description }}</p>
                </div>
            </div>
        </section>
    @endif
    <!-- top section end -->
    @if ($response['key_feature']->IsNotEmpty())
        <section class="key-features-wrapper">
            <div class="key-featuresSection">
                <div class="shef-img">
                    <img src="{{ asset('frontend/img/shef-img.png') }}" alt="image">
                </div>
                <div class="container">
                    <div class="key-features-content">
                        <div class="key-featuresBox">
                            <span class="section-title">Key Features</span>
                            <h2 class="section-heading text-trans">Key Features of Wildtag</h2>
                        </div>
                        @foreach ($response['key_feature'] as $index => $key)
                            @if ($index < 1)
                                <div class="row align-items-center">
                                    <div class="col-md-6">
                                        <div class="key-feat-box">
                                            <figure class="images-box"
                                                style="background-image: url({{ asset('frontend/img/filter-bgImg.png') }});">
                                                <img src="{{ $key->image_url }}" alt="image">
                                            </figure>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="key-feat-rightBox">
                                            <div class="number-box">
                                                <span class="number-text">1</span>
                                            </div>
                                            <div class="key-feat-dataBox">
                                                <h3 class="section-subHead">{{ $key->title }}</h3>
                                                <p class="section-text">
                                                    {{ $key->description }}.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                    </div>
    @endif
    @endforeach
    </div>
    </div>
    <div class="key-featuresSection section-bgImg">
        <div class="shef-img shef-div">
            <img src="{{ asset('frontend/img/shef-img01.png') }}" alt="image">
        </div>
        <div class="shef-img shef-div01">
            <img src="{{ asset('frontend/img/shef-img02.png') }}" alt="image">
        </div>
        <div class="shef-img shef-div02">
            <img src="{{ asset('frontend/img/shef-img03.png') }}" alt="image">
        </div>
        <div class="container">
            <div class="key-features-content">
                @foreach ($response['key_feature'] as $index => $key)
                    @if ($index == 1)
                        <div class="row align-items-center">
                            <div class="col-md-6 order-2 order-ms-1">
                                <div class="key-feat-rightBox">
                                    <div class="number-box">
                                        <span class="number-text">2</span>
                                    </div>
                                    <div class="key-feat-dataBox">
                                        <h3 class="section-subHead">{{ $key->title }}</h3>
                                        <p class="section-text">
                                            {{ $key->description }}
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 order-1 order-md-2">
                                <div class="key-feat-box">
                                    <figure class="images-box"
                                        style="background-image: url({{ asset('frontend/img/filter-bgImg01.png') }});">
                                        <img src="{{ $key->image_url }}" alt="image">
                                    </figure>
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </div>
    <div class="key-featuresSection">
        <div class="shef-img shef-div03">
            <img src="{{ asset('frontend/img/shef-img04.png') }}" alt="image">
        </div>
        <div class="shef-img shef-div04">
            <img src="{{ asset('frontend/img/shef-img05.png') }}" alt="image">
        </div>
        <div class="container">
            <div class="key-features-content">
                @foreach ($response['key_feature'] as $index => $key)
                    @if ($index > 1 && $index < 3)
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <div class="key-feat-box">
                                    <figure class="images-box"
                                        style="background-image: url({{ asset('frontend/img/filter-bgImg.png') }});">
                                        <img src="{{ $key->image_url }}" alt="image">
                                    </figure>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="key-feat-rightBox">
                                    <div class="number-box">
                                        <span class="number-text">3</span>
                                    </div>
                                    <div class="key-feat-dataBox">
                                        <h3 class="section-subHead">{{ $key->title }}</h3>
                                        <p class="section-text">
                                            {{ $key->description }}.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </div>
    <div class="key-featuresSection section-bgImg">
        <div class="container">
            <div class="key-features-content">
                @foreach ($response['key_feature'] as $index => $key)
                    @if ($index == 3)
                        <div class="row align-items-center">
                            <div class="col-md-6 order-2 order-ms-1">
                                <div class="key-feat-rightBox">
                                    <div class="number-box">
                                        <span class="number-text">4</span>
                                    </div>
                                    <div class="key-feat-dataBox">
                                        <h3 class="section-subHead">{{ $key->title }}</h3>
                                        <p class="section-text">
                                            {{ $key->description }}
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 order-1 order-md-2">
                                <div class="key-feat-box">
                                    <figure class="images-box"
                                        style="background-image: url({{ asset('frontend/img/filter-bgImg01.png') }});">
                                        <img src="{{ $key->image_url }}" alt="image">
                                    </figure>
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </div>
    <div class="key-featuresSection">
        <div class="shef-img shef-div05">
            <img src="{{ asset('frontend/img/shef-img06.png') }}" alt="image">
        </div>
        <div class="shef-img shef-div06">
            <img src="{{ asset('frontend/img/shef-img07.png') }}" alt="image">
        </div>
        <div class="shef-img shef-div07">
            <img src="{{ asset('frontend/img/shef-img08.png') }}" alt="image">
        </div>
        <div class="container">
            <div class="key-features-content">
                @foreach ($response['key_feature'] as $index => $key)
                    @if ($index == 4)
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <div class="key-feat-box">
                                    <figure class="images-box"
                                        style="background-image: url({{ asset('frontend/img/filter-bgImg.png') }});">
                                        <img src="{{ $key->image_url }}" alt="image">
                                    </figure>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="key-feat-rightBox">
                                    <div class="number-box">
                                        <span class="number-text">5</span>
                                    </div>
                                    <div class="key-feat-dataBox">
                                        <h3 class="section-subHead">{{ $key->title }}</h3>
                                        <p class="section-text">
                                            {{ $key->description }}.
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </div>
    <div class="key-featuresSection section-bgImg mb-0">
        <div class="shef-img shef-div08">
            <img src="{{ asset('frontend/img/shef-img09.png') }}" alt="image">
        </div>
        <div class="container">
            <div class="key-features-content">
                @foreach ($response['key_feature'] as $index => $key)
                    @if ($index > 4)
                        <div class="row align-items-center">
                            <div class="col-md-6 order-2 order-ms-1">
                                <div class="key-feat-rightBox">
                                    <div class="number-box">
                                        <span class="number-text">6</span>
                                    </div>
                                    <div class="key-feat-dataBox">
                                        <h3 class="section-subHead">{{ $key->title }}</h3>
                                        <p class="section-text">
                                            {{ $key->description }}
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 order-1 order-md-2">
                                <div class="key-feat-box">
                                    <figure class="images-box"
                                        style="background-image: url({{ asset('frontend/img/filter-bgImg01.png') }});">
                                        <img src="{{ $key->image_url }}" alt="image">
                                    </figure>
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
            </div>
        </div>
    </div>
    </section>
    @endif
    <section class="recent-postsSection section-wrapper"
        style="background: linear-gradient(to bottom, rgb(24 71 115 / 90%), rgb(24 71 115 / 90%)), url({{ asset('frontend/img/section-bgImg.png') }});">
        <div class="banner-sectionImg">
            <img src="{{ asset('frontend/img/banner-left.png') }}" alt="" class="left-img">
            <img src="{{ asset('frontend/img/banner-right.png') }}" alt="" class="right-img">
        </div>
        <div class="header_container">
            <div class="recent-postsPage">
                <div class="section_box">
                    <span class="section-title">Feeds</span>
                    <h2 class="section-heading text-trans text-white">Catch Up On Recent Posts</h2>
                </div>
                <div class="post-slideContent">
                    <div class="swiper postSlide">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="postCard-block">
                                    <div class="postCard-box">
                                        <div class="postCard-details">
                                            <figure class="userImg">
                                                <img src="{{ asset('frontend/img/user01.png') }}" alt="image">
                                            </figure>
                                            <div class="user-info">
                                                <h3 class="userName">Jemma Ray</h3>
                                                <div class="user-data">
                                                    <span class="user-subText">Turtles/Leatherback</span>
                                                    <span class="user-subText text-color">Shiloh, Hawaii</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="postCard-rightBox">
                                            <div class="dropdown">
                                                <a class="action_btnEdite dropdown-toggle" href="#" role="button"
                                                    id="dropdownMenuLink72" data-bs-toggle="dropdown"
                                                    aria-expanded="false"><svg width="3" height="13"
                                                        viewBox="0 0 3 13" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M2.60261 1.45805C2.60261 2.13683 2.05235 2.68709 1.37357 2.68709C0.694792 2.68709 0.144531 2.13683 0.144531 1.45805C0.144531 0.779264 0.694792 0.229004 1.37357 0.229004C2.05235 0.229004 2.60261 0.779264 2.60261 1.45805Z"
                                                            fill="currentcolor" />
                                                        <path
                                                            d="M2.60261 6.37421C2.60261 7.05299 2.05235 7.60325 1.37357 7.60325C0.694792 7.60325 0.144531 7.05299 0.144531 6.37421C0.144531 5.69543 0.694792 5.14517 1.37357 5.14517C2.05235 5.14517 2.60261 5.69543 2.60261 6.37421Z"
                                                            fill="currentcolor" />
                                                        <path
                                                            d="M1.37357 12.5194C2.05235 12.5194 2.60261 11.9692 2.60261 11.2904C2.60261 10.6116 2.05235 10.0613 1.37357 10.0613C0.694792 10.0613 0.144531 10.6116 0.144531 11.2904C0.144531 11.9692 0.694792 12.5194 1.37357 12.5194Z"
                                                            fill="currentcolor" />
                                                    </svg>
                                                </a>
                                                <ul class="dropdown-menu dropdown-menu-end action-dropdown">
                                                    <li><a class="dropdown-item" href="#!">
                                                            <span class="link-icons">
                                                                <svg width="15" height="15" viewBox="0 0 15 15"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M8.58012 10.47C8.58012 10.87 8.25012 11.2 7.85012 11.2C7.45012 11.2 7.12012 10.87 7.12012 10.47C7.12012 10.07 7.45012 9.75 7.85012 9.75C8.25012 9.75 8.58012 10.08 8.58012 10.47Z"
                                                                        fill="currentcolor" stroke="black"
                                                                        stroke-width="0.1" />
                                                                    <path
                                                                        d="M8.54016 4.96L8.30016 8.73C8.30016 8.81 8.23016 8.87 8.16016 8.87H7.54016C7.47016 8.87 7.40016 8.81 7.40016 8.73L7.16016 4.96C7.16016 4.84 7.20016 4.73 7.28016 4.64C7.36016 4.55 7.47016 4.5 7.60016 4.5H8.10016C8.23016 4.5 8.34016 4.55 8.42016 4.64C8.50016 4.73 8.54016 4.84 8.54016 4.96Z"
                                                                        fill="currentcolor" stroke="black"
                                                                        stroke-width="0.1" />
                                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                                        d="M7.85 1C4.07 1 1 4.07 1 7.85C1 11.63 4.07 14.7 7.85 14.7C11.63 14.7 14.7 11.63 14.7 7.85C14.7 4.07 11.63 1 7.85 1ZM7.85 13.83C4.55 13.83 1.87 11.15 1.87 7.85C1.87 4.55 4.55 1.87 7.85 1.87C11.15 1.87 13.83 4.55 13.83 7.85C13.83 11.15 11.15 13.83 7.85 13.83Z"
                                                                        fill="currentcolor" stroke="black"
                                                                        stroke-width="0.1" />
                                                                </svg>
                                                            </span> Report</a></li>
                                                    <li><a class="dropdown-item" href="#!"><span class="link-icons">
                                                                <svg width="14" height="14" viewBox="0 0 14 14"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M6.9 0C3.1 0 0 3.1 0 6.9C0 10.7 3.1 13.8 6.9 13.8C10.7 13.8 13.8 10.7 13.8 6.9C13.8 3.1 10.7 0 6.9 0ZM2.32 10.62C1.47 9.57 1 8.25 1 6.9C1 3.65 3.65 1 6.9 1C8.25 1 9.57 1.47 10.62 2.32L10.7 2.39L2.39 10.7L2.32 10.62ZM6.9 12.8C5.55 12.8 4.23 12.33 3.19 11.48L3.1 11.41L11.41 3.1L11.48 3.19C12.33 4.23 12.8 5.55 12.8 6.9C12.8 10.15 10.15 12.8 6.9 12.8Z"
                                                                        fill="currentcolor" />
                                                                </svg>
                                                            </span>Block</a></li>
                                                    <li><a class="dropdown-item" href="#!"><span class="link-icons">
                                                                <svg width="14" height="14" viewBox="0 0 14 14"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <mask id="mask0_575_1255" style="mask-type:luminance"
                                                                        maskUnits="userSpaceOnUse" x="0" y="0"
                                                                        width="14" height="14">
                                                                        <path d="M14 0H0V14H14V0Z" fill="white" />
                                                                        <path
                                                                            d="M7.68359 7C7.68359 7.37754 7.37753 7.68359 7 7.68359C6.62246 7.68359 6.31641 7.37754 6.31641 7C6.31641 6.62247 6.62246 6.31641 7 6.31641C7.37753 6.31641 7.68359 6.62247 7.68359 7Z"
                                                                            fill="white" />
                                                                        <path
                                                                            d="M10.418 7C10.418 7.37754 10.1119 7.68359 9.73437 7.68359C9.35684 7.68359 9.05078 7.37754 9.05078 7C9.05078 6.62247 9.35684 6.31641 9.73437 6.31641C10.1119 6.31641 10.418 6.62247 10.418 7Z"
                                                                            fill="white" />
                                                                        <path
                                                                            d="M4.94921 7C4.94921 7.37754 4.64316 7.68359 4.26562 7.68359C3.88809 7.68359 3.58203 7.37754 3.58203 7C3.58203 6.62247 3.88809 6.31641 4.26562 6.31641C4.64316 6.31641 4.94921 6.62247 4.94921 7Z"
                                                                            fill="white" />
                                                                    </mask>
                                                                    <g mask="url(#mask0_575_1255)">
                                                                        <mask id="mask1_575_1255"
                                                                            style="mask-type:luminance"
                                                                            maskUnits="userSpaceOnUse" x="0" y="0"
                                                                            width="14" height="14">
                                                                            <path d="M0 5.62668e-05H14V14H0V5.62668e-05Z"
                                                                                fill="white" />
                                                                        </mask>
                                                                        <g mask="url(#mask1_575_1255)">
                                                                            <path
                                                                                d="M6.99998 0.546927C3.43603 0.546927 0.546875 3.43609 0.546875 7.00003C0.546875 8.2547 0.905323 9.42547 1.52485 10.4163L0.546875 13.4531L3.58375 12.4752C4.57454 13.0947 5.74532 13.4531 6.99998 13.4531C10.5639 13.4531 13.4531 10.564 13.4531 7.00003C13.4531 3.43609 10.5639 0.546927 6.99998 0.546927Z"
                                                                                stroke="currentcolor"
                                                                                stroke-miterlimit="10"
                                                                                stroke-linecap="round"
                                                                                stroke-linejoin="round" />
                                                                            <path
                                                                                d="M7.68359 7.00002C7.68359 7.37755 7.37753 7.68361 7 7.68361C6.62246 7.68361 6.31641 7.37755 6.31641 7.00002C6.31641 6.62248 6.62246 6.31643 7 6.31643C7.37753 6.31643 7.68359 6.62248 7.68359 7.00002Z"
                                                                                fill="currentcolor" />
                                                                            <path
                                                                                d="M10.418 7.00002C10.418 7.37755 10.1119 7.68361 9.73437 7.68361C9.35684 7.68361 9.05078 7.37755 9.05078 7.00002C9.05078 6.62248 9.35684 6.31643 9.73437 6.31643C10.1119 6.31643 10.418 6.62248 10.418 7.00002Z"
                                                                                fill="currentcolor" />
                                                                            <path
                                                                                d="M4.94921 7.00002C4.94921 7.37755 4.64316 7.68361 4.26562 7.68361C3.88809 7.68361 3.58203 7.37755 3.58203 7.00002C3.58203 6.62248 3.88809 6.31643 4.26562 6.31643C4.64316 6.31643 4.94921 6.62248 4.94921 7.00002Z"
                                                                                fill="currentcolor" />
                                                                        </g>
                                                                    </g>
                                                                </svg>
                                                            </span>Chat</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="inner-swiperblock">
                                        <div class="swiper postSwiper">
                                            <div class="swiper-wrapper">
                                                <div class="swiper-slide">
                                                    <div class="post-innerBox">
                                                        <img src="{{ asset('frontend/img/psot-img01.png') }}"
                                                            alt="">
                                                    </div>
                                                </div>
                                                <div class="swiper-slide">
                                                    <div class="post-innerBox">
                                                        <img src="{{ asset('frontend/img/psot-img02.png') }}"
                                                            alt="">
                                                    </div>
                                                </div>
                                                <div class="swiper-slide">
                                                    <div class="post-innerBox">
                                                        <img src="{{ asset('frontend/img/psot-img.png') }}"
                                                            alt="">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="swiper-button-next inner-swiper"></div>
                                            <div class="swiper-button-prev inner-swiper"></div>
                                            <div class="swiper-pagination inner-swiperSlide"></div>
                                        </div>
                                        <div class="slideCounter">
                                            <span class="activeSlideNumber">1</span>
                                            <span class="counterCenterIcon">/</span>
                                            <span class="totalSlideNumber">4</span>
                                        </div>
                                    </div>
                                    <div class="post-infoBlock">
                                        <div class="post-btnBox">
                                            <ul class="social-mediaButton">
                                                <li><a href="#!" class="post-icons">
                                                        <svg width="16" height="15" viewBox="0 0 16 15"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M3.59569 1.83301C2.48335 2.00177 1.47256 2.93609 1.47256 4.67515C1.47256 5.5205 1.82572 6.44707 2.42806 7.39843C3.026 8.34285 3.83471 9.25703 4.66211 10.0636C5.48699 10.8678 6.31457 11.5497 6.93727 12.0313C7.19267 12.2288 7.41269 12.3919 7.58274 12.5151C7.75278 12.3919 7.97281 12.2288 8.22821 12.0313C8.85091 11.5497 9.67849 10.8678 10.5034 10.0636C11.3308 9.25703 12.1395 8.34285 12.7374 7.39843C13.3398 6.44707 13.6929 5.5205 13.6929 4.67515C13.6929 2.93609 12.6821 2.00177 11.5698 1.83301C10.4402 1.66164 9.01529 2.25621 8.19954 4.02982C8.08875 4.2707 7.84787 4.42504 7.58274 4.42504C7.31761 4.42504 7.07673 4.2707 6.96594 4.02982C6.15019 2.25621 4.72528 1.66164 3.59569 1.83301ZM7.58274 13.3459L7.96163 13.9092C7.73253 14.0633 7.43295 14.0633 7.20385 13.9092L7.58274 13.3459ZM7.58274 2.40523C6.4862 0.904226 4.88184 0.264531 3.39202 0.490558C1.57272 0.766573 0.114746 2.3096 0.114746 4.67515C0.114746 5.88212 0.610222 7.06555 1.28084 8.12476C1.95585 9.19092 2.84441 10.1879 3.71428 11.0359C4.58668 11.8864 5.45637 12.6025 6.10662 13.1054C6.43231 13.3572 6.70431 13.5566 6.89588 13.6938C6.99169 13.7623 7.06748 13.8154 7.1199 13.8517C7.14611 13.8699 7.16649 13.8838 7.18062 13.8935L7.19707 13.9047L7.20169 13.9078L7.20385 13.9092C7.20385 13.9092 7.20385 13.9092 7.58274 13.3459C7.96163 13.9092 7.96163 13.9092 7.96163 13.9092L7.96379 13.9078L7.96841 13.9047L7.98486 13.8935C7.99899 13.8838 8.01937 13.8699 8.04558 13.8517C8.098 13.8154 8.17379 13.7623 8.2696 13.6938C8.46117 13.5566 8.73317 13.3572 9.05886 13.1054C9.70911 12.6025 10.5788 11.8864 11.4512 11.0359C12.3211 10.1879 13.2096 9.19092 13.8846 8.12476C14.5553 7.06555 15.0507 5.88212 15.0507 4.67515C15.0507 2.3096 13.5928 0.766573 11.7735 0.490558C10.2836 0.264531 8.67928 0.904226 7.58274 2.40523Z"
                                                                fill="currentcolor" />
                                                        </svg>
                                                    </a></li>
                                                <li><a href="#!" class="post-icons">
                                                        <svg width="18" height="17" viewBox="0 0 18 17"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <g clip-path="url(#clip0_802_15128)">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M3.76153 3.6347C3.00663 4.49254 2.82754 5.7047 2.82754 7.21721C2.82754 8.7262 3.00242 9.99683 3.5691 10.8823C4.09303 11.7009 5.03358 12.309 6.90099 12.309C7.11469 12.309 7.31591 12.4096 7.44412 12.5806L8.93772 14.5721L10.4313 12.5806C10.5595 12.4096 10.7608 12.309 10.9744 12.309C12.8419 12.309 13.7824 11.7009 14.3063 10.8823C14.873 9.99683 15.0479 8.7262 15.0479 7.21721C15.0479 5.7047 14.8688 4.49254 14.1139 3.6347C13.3716 2.79114 11.9176 2.1254 8.93772 2.1254C5.95785 2.1254 4.50385 2.79114 3.76153 3.6347ZM2.7422 2.73768C3.86687 1.45965 5.80741 0.767578 8.93772 0.767578C12.068 0.767578 14.0086 1.45965 15.1332 2.73768C16.2453 4.00143 16.4057 5.67463 16.4057 7.21721C16.4057 8.7633 16.2411 10.378 15.45 11.6142C14.6603 12.8481 13.3309 13.5858 11.3186 13.6606L10.024 15.3867C9.48085 16.1109 8.39459 16.1109 7.85147 15.3867L6.55683 13.6606C4.54452 13.5858 3.21515 12.8481 2.42545 11.6142C1.6343 10.378 1.46973 8.7633 1.46973 7.21721C1.46973 5.67463 1.6301 4.00143 2.7422 2.73768Z"
                                                                    fill="currentcolor" />
                                                            </g>
                                                            <defs>
                                                                <clipPath id="clip0_802_15128">
                                                                    <rect width="16.2938" height="16.2938" fill="white"
                                                                        transform="translate(0.790527 0.0888672)" />
                                                                </clipPath>
                                                            </defs>
                                                        </svg>
                                                    </a></li>
                                                <li><a href="#!" class="post-icons">
                                                        <svg width="16" height="15" viewBox="0 0 16 15"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M0.881358 0.85583C0.989046 0.607764 1.23369 0.447266 1.50412 0.447266H15.0823C15.3226 0.447266 15.545 0.574273 15.667 0.781227C15.7891 0.98818 15.7927 1.24425 15.6765 1.45455L8.54796 14.3538C8.40955 14.6043 8.12895 14.7411 7.84639 14.6958C7.56383 14.6506 7.33998 14.433 7.28671 14.1518L5.89765 6.82066L1.00815 1.58978C0.823478 1.39222 0.773671 1.1039 0.881358 0.85583ZM7.28128 6.8294L8.27027 12.0491L13.2152 3.10106L7.28128 6.8294ZM12.7256 1.80508H3.06804L6.64135 5.62788L12.7256 1.80508Z"
                                                                fill="currentcolor" />
                                                        </svg>
                                                    </a></li>
                                            </ul>
                                            <button type="button" class="save-button">
                                                <svg width="11" height="14" viewBox="0 0 11 14" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M0.569336 2.60009C0.569336 1.66676 1.32594 0.910156 2.25927 0.910156H9.019C9.95232 0.910156 10.7089 1.66676 10.7089 2.60009V12.7397C10.7089 12.9607 10.5797 13.1613 10.3784 13.2526C10.1771 13.344 9.94102 13.3092 9.77467 13.1636L5.63913 9.54501L1.50359 13.1636C1.33725 13.3092 1.10115 13.344 0.899877 13.2526C0.6986 13.1613 0.569336 12.9607 0.569336 12.7397V2.60009ZM2.25927 2.03678C1.94816 2.03678 1.69596 2.28898 1.69596 2.60009V11.4983L5.26819 8.37257C5.48057 8.18674 5.79769 8.18674 6.01007 8.37257L9.58231 11.4983V2.60009C9.58231 2.28898 9.3301 2.03678 9.019 2.03678H2.25927Z"
                                                        fill="currentcolor" />
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="likes-commentsBox">
                                            <a href="#!" class="post-likes number-link">25 Likes </a>
                                            <a href="#!" class="post-likes  number-link"> | 12 Comments</a>
                                        </div>
                                        <p class="post-mess">
                                            Lorem ipsum dolor sit amet consectetur. Vulputate blandit quam aenean tempus.
                                            Quis consequat habitasse malesuada neque. Et tortor ntristique aenean... <a
                                                href="#!" class="more-btn">more</a>
                                        </p>
                                        <span class="post-time number-link">17 April 2024, 9:30 pM</span>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="postCard-block">
                                    <div class="postCard-box">
                                        <div class="postCard-details">
                                            <figure class="userImg">
                                                <img src="{{ asset('frontend/img/user01.png') }}" alt="image">
                                            </figure>
                                            <div class="user-info">
                                                <h3 class="userName">Jemma Ray</h3>
                                                <div class="user-data">
                                                    <span class="user-subText">Turtles/Leatherback</span>
                                                    <span class="user-subText text-color">Shiloh, Hawaii</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="postCard-rightBox">
                                            <div class="dropdown">
                                                <a class="action_btnEdite dropdown-toggle" href="#" role="button"
                                                    id="dropdownMenuLink72" data-bs-toggle="dropdown"
                                                    aria-expanded="false"><svg width="3" height="13"
                                                        viewBox="0 0 3 13" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M2.60261 1.45805C2.60261 2.13683 2.05235 2.68709 1.37357 2.68709C0.694792 2.68709 0.144531 2.13683 0.144531 1.45805C0.144531 0.779264 0.694792 0.229004 1.37357 0.229004C2.05235 0.229004 2.60261 0.779264 2.60261 1.45805Z"
                                                            fill="currentcolor" />
                                                        <path
                                                            d="M2.60261 6.37421C2.60261 7.05299 2.05235 7.60325 1.37357 7.60325C0.694792 7.60325 0.144531 7.05299 0.144531 6.37421C0.144531 5.69543 0.694792 5.14517 1.37357 5.14517C2.05235 5.14517 2.60261 5.69543 2.60261 6.37421Z"
                                                            fill="currentcolor" />
                                                        <path
                                                            d="M1.37357 12.5194C2.05235 12.5194 2.60261 11.9692 2.60261 11.2904C2.60261 10.6116 2.05235 10.0613 1.37357 10.0613C0.694792 10.0613 0.144531 10.6116 0.144531 11.2904C0.144531 11.9692 0.694792 12.5194 1.37357 12.5194Z"
                                                            fill="currentcolor" />
                                                    </svg>
                                                </a>
                                                <ul class="dropdown-menu dropdown-menu-end action-dropdown">
                                                    <li><a class="dropdown-item" href="#!">
                                                            <span class="link-icons">
                                                                <svg width="15" height="15" viewBox="0 0 15 15"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M8.58012 10.47C8.58012 10.87 8.25012 11.2 7.85012 11.2C7.45012 11.2 7.12012 10.87 7.12012 10.47C7.12012 10.07 7.45012 9.75 7.85012 9.75C8.25012 9.75 8.58012 10.08 8.58012 10.47Z"
                                                                        fill="currentcolor" stroke="black"
                                                                        stroke-width="0.1" />
                                                                    <path
                                                                        d="M8.54016 4.96L8.30016 8.73C8.30016 8.81 8.23016 8.87 8.16016 8.87H7.54016C7.47016 8.87 7.40016 8.81 7.40016 8.73L7.16016 4.96C7.16016 4.84 7.20016 4.73 7.28016 4.64C7.36016 4.55 7.47016 4.5 7.60016 4.5H8.10016C8.23016 4.5 8.34016 4.55 8.42016 4.64C8.50016 4.73 8.54016 4.84 8.54016 4.96Z"
                                                                        fill="currentcolor" stroke="black"
                                                                        stroke-width="0.1" />
                                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                                        d="M7.85 1C4.07 1 1 4.07 1 7.85C1 11.63 4.07 14.7 7.85 14.7C11.63 14.7 14.7 11.63 14.7 7.85C14.7 4.07 11.63 1 7.85 1ZM7.85 13.83C4.55 13.83 1.87 11.15 1.87 7.85C1.87 4.55 4.55 1.87 7.85 1.87C11.15 1.87 13.83 4.55 13.83 7.85C13.83 11.15 11.15 13.83 7.85 13.83Z"
                                                                        fill="currentcolor" stroke="black"
                                                                        stroke-width="0.1" />
                                                                </svg>
                                                            </span> Report</a></li>
                                                    <li><a class="dropdown-item" href="#!"><span class="link-icons">
                                                                <svg width="14" height="14" viewBox="0 0 14 14"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M6.9 0C3.1 0 0 3.1 0 6.9C0 10.7 3.1 13.8 6.9 13.8C10.7 13.8 13.8 10.7 13.8 6.9C13.8 3.1 10.7 0 6.9 0ZM2.32 10.62C1.47 9.57 1 8.25 1 6.9C1 3.65 3.65 1 6.9 1C8.25 1 9.57 1.47 10.62 2.32L10.7 2.39L2.39 10.7L2.32 10.62ZM6.9 12.8C5.55 12.8 4.23 12.33 3.19 11.48L3.1 11.41L11.41 3.1L11.48 3.19C12.33 4.23 12.8 5.55 12.8 6.9C12.8 10.15 10.15 12.8 6.9 12.8Z"
                                                                        fill="currentcolor" />
                                                                </svg>
                                                            </span>Block</a></li>
                                                    <li><a class="dropdown-item" href="#!"><span class="link-icons">
                                                                <svg width="14" height="14" viewBox="0 0 14 14"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <mask id="mask0_575_1255" style="mask-type:luminance"
                                                                        maskUnits="userSpaceOnUse" x="0" y="0"
                                                                        width="14" height="14">
                                                                        <path d="M14 0H0V14H14V0Z" fill="white" />
                                                                        <path
                                                                            d="M7.68359 7C7.68359 7.37754 7.37753 7.68359 7 7.68359C6.62246 7.68359 6.31641 7.37754 6.31641 7C6.31641 6.62247 6.62246 6.31641 7 6.31641C7.37753 6.31641 7.68359 6.62247 7.68359 7Z"
                                                                            fill="white" />
                                                                        <path
                                                                            d="M10.418 7C10.418 7.37754 10.1119 7.68359 9.73437 7.68359C9.35684 7.68359 9.05078 7.37754 9.05078 7C9.05078 6.62247 9.35684 6.31641 9.73437 6.31641C10.1119 6.31641 10.418 6.62247 10.418 7Z"
                                                                            fill="white" />
                                                                        <path
                                                                            d="M4.94921 7C4.94921 7.37754 4.64316 7.68359 4.26562 7.68359C3.88809 7.68359 3.58203 7.37754 3.58203 7C3.58203 6.62247 3.88809 6.31641 4.26562 6.31641C4.64316 6.31641 4.94921 6.62247 4.94921 7Z"
                                                                            fill="white" />
                                                                    </mask>
                                                                    <g mask="url(#mask0_575_1255)">
                                                                        <mask id="mask1_575_1255"
                                                                            style="mask-type:luminance"
                                                                            maskUnits="userSpaceOnUse" x="0" y="0"
                                                                            width="14" height="14">
                                                                            <path d="M0 5.62668e-05H14V14H0V5.62668e-05Z"
                                                                                fill="white" />
                                                                        </mask>
                                                                        <g mask="url(#mask1_575_1255)">
                                                                            <path
                                                                                d="M6.99998 0.546927C3.43603 0.546927 0.546875 3.43609 0.546875 7.00003C0.546875 8.2547 0.905323 9.42547 1.52485 10.4163L0.546875 13.4531L3.58375 12.4752C4.57454 13.0947 5.74532 13.4531 6.99998 13.4531C10.5639 13.4531 13.4531 10.564 13.4531 7.00003C13.4531 3.43609 10.5639 0.546927 6.99998 0.546927Z"
                                                                                stroke="currentcolor"
                                                                                stroke-miterlimit="10"
                                                                                stroke-linecap="round"
                                                                                stroke-linejoin="round" />
                                                                            <path
                                                                                d="M7.68359 7.00002C7.68359 7.37755 7.37753 7.68361 7 7.68361C6.62246 7.68361 6.31641 7.37755 6.31641 7.00002C6.31641 6.62248 6.62246 6.31643 7 6.31643C7.37753 6.31643 7.68359 6.62248 7.68359 7.00002Z"
                                                                                fill="currentcolor" />
                                                                            <path
                                                                                d="M10.418 7.00002C10.418 7.37755 10.1119 7.68361 9.73437 7.68361C9.35684 7.68361 9.05078 7.37755 9.05078 7.00002C9.05078 6.62248 9.35684 6.31643 9.73437 6.31643C10.1119 6.31643 10.418 6.62248 10.418 7.00002Z"
                                                                                fill="currentcolor" />
                                                                            <path
                                                                                d="M4.94921 7.00002C4.94921 7.37755 4.64316 7.68361 4.26562 7.68361C3.88809 7.68361 3.58203 7.37755 3.58203 7.00002C3.58203 6.62248 3.88809 6.31643 4.26562 6.31643C4.64316 6.31643 4.94921 6.62248 4.94921 7.00002Z"
                                                                                fill="currentcolor" />
                                                                        </g>
                                                                    </g>
                                                                </svg>
                                                            </span>Chat</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="inner-swiperblock">
                                        <div class="swiper postSwiper">
                                            <div class="swiper-wrapper">
                                                <div class="swiper-slide">
                                                    <div class="post-innerBox">
                                                        <img src="{{ asset('frontend/img/psot-img02.png') }}"
                                                            alt="">
                                                    </div>
                                                </div>
                                                <div class="swiper-slide">
                                                    <div class="post-innerBox">
                                                        <img src="{{ asset('frontend/img/psot-img.png') }}"
                                                            alt="">
                                                    </div>
                                                </div>
                                                <div class="swiper-slide">
                                                    <div class="post-innerBox">
                                                        <img src="{{ asset('frontend/img/psot-img01.png') }}"
                                                            alt="">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="swiper-button-next inner-swiper"></div>
                                            <div class="swiper-button-prev inner-swiper"></div>
                                            <div class="swiper-pagination inner-swiperSlide"></div>
                                        </div>
                                        <div class="slideCounter">
                                            <span class="activeSlideNumber">1</span>
                                            <span class="counterCenterIcon">/</span>
                                            <span class="totalSlideNumber">4</span>
                                        </div>
                                    </div>
                                    <div class="post-infoBlock">
                                        <div class="post-btnBox">
                                            <ul class="social-mediaButton">
                                                <li><a href="#!" class="post-icons">
                                                        <svg width="16" height="15" viewBox="0 0 16 15"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M3.59569 1.83301C2.48335 2.00177 1.47256 2.93609 1.47256 4.67515C1.47256 5.5205 1.82572 6.44707 2.42806 7.39843C3.026 8.34285 3.83471 9.25703 4.66211 10.0636C5.48699 10.8678 6.31457 11.5497 6.93727 12.0313C7.19267 12.2288 7.41269 12.3919 7.58274 12.5151C7.75278 12.3919 7.97281 12.2288 8.22821 12.0313C8.85091 11.5497 9.67849 10.8678 10.5034 10.0636C11.3308 9.25703 12.1395 8.34285 12.7374 7.39843C13.3398 6.44707 13.6929 5.5205 13.6929 4.67515C13.6929 2.93609 12.6821 2.00177 11.5698 1.83301C10.4402 1.66164 9.01529 2.25621 8.19954 4.02982C8.08875 4.2707 7.84787 4.42504 7.58274 4.42504C7.31761 4.42504 7.07673 4.2707 6.96594 4.02982C6.15019 2.25621 4.72528 1.66164 3.59569 1.83301ZM7.58274 13.3459L7.96163 13.9092C7.73253 14.0633 7.43295 14.0633 7.20385 13.9092L7.58274 13.3459ZM7.58274 2.40523C6.4862 0.904226 4.88184 0.264531 3.39202 0.490558C1.57272 0.766573 0.114746 2.3096 0.114746 4.67515C0.114746 5.88212 0.610222 7.06555 1.28084 8.12476C1.95585 9.19092 2.84441 10.1879 3.71428 11.0359C4.58668 11.8864 5.45637 12.6025 6.10662 13.1054C6.43231 13.3572 6.70431 13.5566 6.89588 13.6938C6.99169 13.7623 7.06748 13.8154 7.1199 13.8517C7.14611 13.8699 7.16649 13.8838 7.18062 13.8935L7.19707 13.9047L7.20169 13.9078L7.20385 13.9092C7.20385 13.9092 7.20385 13.9092 7.58274 13.3459C7.96163 13.9092 7.96163 13.9092 7.96163 13.9092L7.96379 13.9078L7.96841 13.9047L7.98486 13.8935C7.99899 13.8838 8.01937 13.8699 8.04558 13.8517C8.098 13.8154 8.17379 13.7623 8.2696 13.6938C8.46117 13.5566 8.73317 13.3572 9.05886 13.1054C9.70911 12.6025 10.5788 11.8864 11.4512 11.0359C12.3211 10.1879 13.2096 9.19092 13.8846 8.12476C14.5553 7.06555 15.0507 5.88212 15.0507 4.67515C15.0507 2.3096 13.5928 0.766573 11.7735 0.490558C10.2836 0.264531 8.67928 0.904226 7.58274 2.40523Z"
                                                                fill="currentcolor" />
                                                        </svg>
                                                    </a></li>
                                                <li><a href="#!" class="post-icons">
                                                        <svg width="18" height="17" viewBox="0 0 18 17"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <g clip-path="url(#clip0_802_15128)">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M3.76153 3.6347C3.00663 4.49254 2.82754 5.7047 2.82754 7.21721C2.82754 8.7262 3.00242 9.99683 3.5691 10.8823C4.09303 11.7009 5.03358 12.309 6.90099 12.309C7.11469 12.309 7.31591 12.4096 7.44412 12.5806L8.93772 14.5721L10.4313 12.5806C10.5595 12.4096 10.7608 12.309 10.9744 12.309C12.8419 12.309 13.7824 11.7009 14.3063 10.8823C14.873 9.99683 15.0479 8.7262 15.0479 7.21721C15.0479 5.7047 14.8688 4.49254 14.1139 3.6347C13.3716 2.79114 11.9176 2.1254 8.93772 2.1254C5.95785 2.1254 4.50385 2.79114 3.76153 3.6347ZM2.7422 2.73768C3.86687 1.45965 5.80741 0.767578 8.93772 0.767578C12.068 0.767578 14.0086 1.45965 15.1332 2.73768C16.2453 4.00143 16.4057 5.67463 16.4057 7.21721C16.4057 8.7633 16.2411 10.378 15.45 11.6142C14.6603 12.8481 13.3309 13.5858 11.3186 13.6606L10.024 15.3867C9.48085 16.1109 8.39459 16.1109 7.85147 15.3867L6.55683 13.6606C4.54452 13.5858 3.21515 12.8481 2.42545 11.6142C1.6343 10.378 1.46973 8.7633 1.46973 7.21721C1.46973 5.67463 1.6301 4.00143 2.7422 2.73768Z"
                                                                    fill="currentcolor" />
                                                            </g>
                                                            <defs>
                                                                <clipPath id="clip0_802_15128">
                                                                    <rect width="16.2938" height="16.2938" fill="white"
                                                                        transform="translate(0.790527 0.0888672)" />
                                                                </clipPath>
                                                            </defs>
                                                        </svg>
                                                    </a></li>
                                                <li><a href="#!" class="post-icons">
                                                        <svg width="16" height="15" viewBox="0 0 16 15"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M0.881358 0.85583C0.989046 0.607764 1.23369 0.447266 1.50412 0.447266H15.0823C15.3226 0.447266 15.545 0.574273 15.667 0.781227C15.7891 0.98818 15.7927 1.24425 15.6765 1.45455L8.54796 14.3538C8.40955 14.6043 8.12895 14.7411 7.84639 14.6958C7.56383 14.6506 7.33998 14.433 7.28671 14.1518L5.89765 6.82066L1.00815 1.58978C0.823478 1.39222 0.773671 1.1039 0.881358 0.85583ZM7.28128 6.8294L8.27027 12.0491L13.2152 3.10106L7.28128 6.8294ZM12.7256 1.80508H3.06804L6.64135 5.62788L12.7256 1.80508Z"
                                                                fill="currentcolor" />
                                                        </svg>
                                                    </a></li>
                                            </ul>
                                            <button type="button" class="save-button">
                                                <svg width="11" height="14" viewBox="0 0 11 14" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M0.569336 2.60009C0.569336 1.66676 1.32594 0.910156 2.25927 0.910156H9.019C9.95232 0.910156 10.7089 1.66676 10.7089 2.60009V12.7397C10.7089 12.9607 10.5797 13.1613 10.3784 13.2526C10.1771 13.344 9.94102 13.3092 9.77467 13.1636L5.63913 9.54501L1.50359 13.1636C1.33725 13.3092 1.10115 13.344 0.899877 13.2526C0.6986 13.1613 0.569336 12.9607 0.569336 12.7397V2.60009ZM2.25927 2.03678C1.94816 2.03678 1.69596 2.28898 1.69596 2.60009V11.4983L5.26819 8.37257C5.48057 8.18674 5.79769 8.18674 6.01007 8.37257L9.58231 11.4983V2.60009C9.58231 2.28898 9.3301 2.03678 9.019 2.03678H2.25927Z"
                                                        fill="currentcolor" />
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="likes-commentsBox">
                                            <a href="#!" class="post-likes number-link">25 Likes </a>
                                            <a href="#!" class="post-likes  number-link"> | 12 Comments</a>
                                        </div>
                                        <p class="post-mess">
                                            Lorem ipsum dolor sit amet consectetur. Vulputate blandit quam aenean tempus.
                                            Quis consequat habitasse malesuada neque. Et tortor ntristique aenean... <a
                                                href="#!" class="more-btn">more</a>
                                        </p>
                                        <span class="post-time number-link">17 April 2024, 9:30 pM</span>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="postCard-block">
                                    <div class="postCard-box">
                                        <div class="postCard-details">
                                            <figure class="userImg">
                                                <img src="{{ asset('frontend/img/user01.png') }}" alt="image">
                                            </figure>
                                            <div class="user-info">
                                                <h3 class="userName">Jemma Ray</h3>
                                                <div class="user-data">
                                                    <span class="user-subText">Turtles/Leatherback</span>
                                                    <span class="user-subText text-color">Shiloh, Hawaii</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="postCard-rightBox">
                                            <div class="dropdown">
                                                <a class="action_btnEdite dropdown-toggle" href="#" role="button"
                                                    id="dropdownMenuLink72" data-bs-toggle="dropdown"
                                                    aria-expanded="false"><svg width="3" height="13"
                                                        viewBox="0 0 3 13" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M2.60261 1.45805C2.60261 2.13683 2.05235 2.68709 1.37357 2.68709C0.694792 2.68709 0.144531 2.13683 0.144531 1.45805C0.144531 0.779264 0.694792 0.229004 1.37357 0.229004C2.05235 0.229004 2.60261 0.779264 2.60261 1.45805Z"
                                                            fill="currentcolor" />
                                                        <path
                                                            d="M2.60261 6.37421C2.60261 7.05299 2.05235 7.60325 1.37357 7.60325C0.694792 7.60325 0.144531 7.05299 0.144531 6.37421C0.144531 5.69543 0.694792 5.14517 1.37357 5.14517C2.05235 5.14517 2.60261 5.69543 2.60261 6.37421Z"
                                                            fill="currentcolor" />
                                                        <path
                                                            d="M1.37357 12.5194C2.05235 12.5194 2.60261 11.9692 2.60261 11.2904C2.60261 10.6116 2.05235 10.0613 1.37357 10.0613C0.694792 10.0613 0.144531 10.6116 0.144531 11.2904C0.144531 11.9692 0.694792 12.5194 1.37357 12.5194Z"
                                                            fill="currentcolor" />
                                                    </svg>
                                                </a>
                                                <ul class="dropdown-menu dropdown-menu-end action-dropdown">
                                                    <li><a class="dropdown-item" href="#!">
                                                            <span class="link-icons">
                                                                <svg width="15" height="15" viewBox="0 0 15 15"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M8.58012 10.47C8.58012 10.87 8.25012 11.2 7.85012 11.2C7.45012 11.2 7.12012 10.87 7.12012 10.47C7.12012 10.07 7.45012 9.75 7.85012 9.75C8.25012 9.75 8.58012 10.08 8.58012 10.47Z"
                                                                        fill="currentcolor" stroke="black"
                                                                        stroke-width="0.1" />
                                                                    <path
                                                                        d="M8.54016 4.96L8.30016 8.73C8.30016 8.81 8.23016 8.87 8.16016 8.87H7.54016C7.47016 8.87 7.40016 8.81 7.40016 8.73L7.16016 4.96C7.16016 4.84 7.20016 4.73 7.28016 4.64C7.36016 4.55 7.47016 4.5 7.60016 4.5H8.10016C8.23016 4.5 8.34016 4.55 8.42016 4.64C8.50016 4.73 8.54016 4.84 8.54016 4.96Z"
                                                                        fill="currentcolor" stroke="black"
                                                                        stroke-width="0.1" />
                                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                                        d="M7.85 1C4.07 1 1 4.07 1 7.85C1 11.63 4.07 14.7 7.85 14.7C11.63 14.7 14.7 11.63 14.7 7.85C14.7 4.07 11.63 1 7.85 1ZM7.85 13.83C4.55 13.83 1.87 11.15 1.87 7.85C1.87 4.55 4.55 1.87 7.85 1.87C11.15 1.87 13.83 4.55 13.83 7.85C13.83 11.15 11.15 13.83 7.85 13.83Z"
                                                                        fill="currentcolor" stroke="black"
                                                                        stroke-width="0.1" />
                                                                </svg>
                                                            </span> Report</a></li>
                                                    <li><a class="dropdown-item" href="#!"><span class="link-icons">
                                                                <svg width="14" height="14" viewBox="0 0 14 14"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M6.9 0C3.1 0 0 3.1 0 6.9C0 10.7 3.1 13.8 6.9 13.8C10.7 13.8 13.8 10.7 13.8 6.9C13.8 3.1 10.7 0 6.9 0ZM2.32 10.62C1.47 9.57 1 8.25 1 6.9C1 3.65 3.65 1 6.9 1C8.25 1 9.57 1.47 10.62 2.32L10.7 2.39L2.39 10.7L2.32 10.62ZM6.9 12.8C5.55 12.8 4.23 12.33 3.19 11.48L3.1 11.41L11.41 3.1L11.48 3.19C12.33 4.23 12.8 5.55 12.8 6.9C12.8 10.15 10.15 12.8 6.9 12.8Z"
                                                                        fill="currentcolor" />
                                                                </svg>
                                                            </span>Block</a></li>
                                                    <li><a class="dropdown-item" href="#!"><span class="link-icons">
                                                                <svg width="14" height="14" viewBox="0 0 14 14"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <mask id="mask0_575_1255" style="mask-type:luminance"
                                                                        maskUnits="userSpaceOnUse" x="0" y="0"
                                                                        width="14" height="14">
                                                                        <path d="M14 0H0V14H14V0Z" fill="white" />
                                                                        <path
                                                                            d="M7.68359 7C7.68359 7.37754 7.37753 7.68359 7 7.68359C6.62246 7.68359 6.31641 7.37754 6.31641 7C6.31641 6.62247 6.62246 6.31641 7 6.31641C7.37753 6.31641 7.68359 6.62247 7.68359 7Z"
                                                                            fill="white" />
                                                                        <path
                                                                            d="M10.418 7C10.418 7.37754 10.1119 7.68359 9.73437 7.68359C9.35684 7.68359 9.05078 7.37754 9.05078 7C9.05078 6.62247 9.35684 6.31641 9.73437 6.31641C10.1119 6.31641 10.418 6.62247 10.418 7Z"
                                                                            fill="white" />
                                                                        <path
                                                                            d="M4.94921 7C4.94921 7.37754 4.64316 7.68359 4.26562 7.68359C3.88809 7.68359 3.58203 7.37754 3.58203 7C3.58203 6.62247 3.88809 6.31641 4.26562 6.31641C4.64316 6.31641 4.94921 6.62247 4.94921 7Z"
                                                                            fill="white" />
                                                                    </mask>
                                                                    <g mask="url(#mask0_575_1255)">
                                                                        <mask id="mask1_575_1255"
                                                                            style="mask-type:luminance"
                                                                            maskUnits="userSpaceOnUse" x="0" y="0"
                                                                            width="14" height="14">
                                                                            <path d="M0 5.62668e-05H14V14H0V5.62668e-05Z"
                                                                                fill="white" />
                                                                        </mask>
                                                                        <g mask="url(#mask1_575_1255)">
                                                                            <path
                                                                                d="M6.99998 0.546927C3.43603 0.546927 0.546875 3.43609 0.546875 7.00003C0.546875 8.2547 0.905323 9.42547 1.52485 10.4163L0.546875 13.4531L3.58375 12.4752C4.57454 13.0947 5.74532 13.4531 6.99998 13.4531C10.5639 13.4531 13.4531 10.564 13.4531 7.00003C13.4531 3.43609 10.5639 0.546927 6.99998 0.546927Z"
                                                                                stroke="currentcolor"
                                                                                stroke-miterlimit="10"
                                                                                stroke-linecap="round"
                                                                                stroke-linejoin="round" />
                                                                            <path
                                                                                d="M7.68359 7.00002C7.68359 7.37755 7.37753 7.68361 7 7.68361C6.62246 7.68361 6.31641 7.37755 6.31641 7.00002C6.31641 6.62248 6.62246 6.31643 7 6.31643C7.37753 6.31643 7.68359 6.62248 7.68359 7.00002Z"
                                                                                fill="currentcolor" />
                                                                            <path
                                                                                d="M10.418 7.00002C10.418 7.37755 10.1119 7.68361 9.73437 7.68361C9.35684 7.68361 9.05078 7.37755 9.05078 7.00002C9.05078 6.62248 9.35684 6.31643 9.73437 6.31643C10.1119 6.31643 10.418 6.62248 10.418 7.00002Z"
                                                                                fill="currentcolor" />
                                                                            <path
                                                                                d="M4.94921 7.00002C4.94921 7.37755 4.64316 7.68361 4.26562 7.68361C3.88809 7.68361 3.58203 7.37755 3.58203 7.00002C3.58203 6.62248 3.88809 6.31643 4.26562 6.31643C4.64316 6.31643 4.94921 6.62248 4.94921 7.00002Z"
                                                                                fill="currentcolor" />
                                                                        </g>
                                                                    </g>
                                                                </svg>
                                                            </span>Chat</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="inner-swiperblock">
                                        <div class="swiper postSwiper">
                                            <div class="swiper-wrapper">
                                                <div class="swiper-slide">
                                                    <div class="post-innerBox">
                                                        <img src="{{ asset('frontend/img/psot-img.png') }}"
                                                            alt="">
                                                    </div>
                                                </div>
                                                <div class="swiper-slide">
                                                    <div class="post-innerBox">
                                                        <img src="{{ asset('frontend/img/psot-img01.png') }}"
                                                            alt="">
                                                    </div>
                                                </div>
                                                <div class="swiper-slide">
                                                    <div class="post-innerBox">
                                                        <img src="{{ asset('frontend/img/psot-img02.png') }}"
                                                            alt="">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="swiper-button-next inner-swiper"></div>
                                            <div class="swiper-button-prev inner-swiper"></div>
                                            <div class="swiper-pagination inner-swiperSlide"></div>
                                        </div>
                                        <div class="slideCounter">
                                            <span class="activeSlideNumber">1</span>
                                            <span class="counterCenterIcon">/</span>
                                            <span class="totalSlideNumber">4</span>
                                        </div>
                                    </div>
                                    <div class="post-infoBlock">
                                        <div class="post-btnBox">
                                            <ul class="social-mediaButton">
                                                <li><a href="#!" class="post-icons">
                                                        <svg width="16" height="15" viewBox="0 0 16 15"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M3.59569 1.83301C2.48335 2.00177 1.47256 2.93609 1.47256 4.67515C1.47256 5.5205 1.82572 6.44707 2.42806 7.39843C3.026 8.34285 3.83471 9.25703 4.66211 10.0636C5.48699 10.8678 6.31457 11.5497 6.93727 12.0313C7.19267 12.2288 7.41269 12.3919 7.58274 12.5151C7.75278 12.3919 7.97281 12.2288 8.22821 12.0313C8.85091 11.5497 9.67849 10.8678 10.5034 10.0636C11.3308 9.25703 12.1395 8.34285 12.7374 7.39843C13.3398 6.44707 13.6929 5.5205 13.6929 4.67515C13.6929 2.93609 12.6821 2.00177 11.5698 1.83301C10.4402 1.66164 9.01529 2.25621 8.19954 4.02982C8.08875 4.2707 7.84787 4.42504 7.58274 4.42504C7.31761 4.42504 7.07673 4.2707 6.96594 4.02982C6.15019 2.25621 4.72528 1.66164 3.59569 1.83301ZM7.58274 13.3459L7.96163 13.9092C7.73253 14.0633 7.43295 14.0633 7.20385 13.9092L7.58274 13.3459ZM7.58274 2.40523C6.4862 0.904226 4.88184 0.264531 3.39202 0.490558C1.57272 0.766573 0.114746 2.3096 0.114746 4.67515C0.114746 5.88212 0.610222 7.06555 1.28084 8.12476C1.95585 9.19092 2.84441 10.1879 3.71428 11.0359C4.58668 11.8864 5.45637 12.6025 6.10662 13.1054C6.43231 13.3572 6.70431 13.5566 6.89588 13.6938C6.99169 13.7623 7.06748 13.8154 7.1199 13.8517C7.14611 13.8699 7.16649 13.8838 7.18062 13.8935L7.19707 13.9047L7.20169 13.9078L7.20385 13.9092C7.20385 13.9092 7.20385 13.9092 7.58274 13.3459C7.96163 13.9092 7.96163 13.9092 7.96163 13.9092L7.96379 13.9078L7.96841 13.9047L7.98486 13.8935C7.99899 13.8838 8.01937 13.8699 8.04558 13.8517C8.098 13.8154 8.17379 13.7623 8.2696 13.6938C8.46117 13.5566 8.73317 13.3572 9.05886 13.1054C9.70911 12.6025 10.5788 11.8864 11.4512 11.0359C12.3211 10.1879 13.2096 9.19092 13.8846 8.12476C14.5553 7.06555 15.0507 5.88212 15.0507 4.67515C15.0507 2.3096 13.5928 0.766573 11.7735 0.490558C10.2836 0.264531 8.67928 0.904226 7.58274 2.40523Z"
                                                                fill="currentcolor" />
                                                        </svg>
                                                    </a></li>
                                                <li><a href="#!" class="post-icons">
                                                        <svg width="18" height="17" viewBox="0 0 18 17"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <g clip-path="url(#clip0_802_15128)">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M3.76153 3.6347C3.00663 4.49254 2.82754 5.7047 2.82754 7.21721C2.82754 8.7262 3.00242 9.99683 3.5691 10.8823C4.09303 11.7009 5.03358 12.309 6.90099 12.309C7.11469 12.309 7.31591 12.4096 7.44412 12.5806L8.93772 14.5721L10.4313 12.5806C10.5595 12.4096 10.7608 12.309 10.9744 12.309C12.8419 12.309 13.7824 11.7009 14.3063 10.8823C14.873 9.99683 15.0479 8.7262 15.0479 7.21721C15.0479 5.7047 14.8688 4.49254 14.1139 3.6347C13.3716 2.79114 11.9176 2.1254 8.93772 2.1254C5.95785 2.1254 4.50385 2.79114 3.76153 3.6347ZM2.7422 2.73768C3.86687 1.45965 5.80741 0.767578 8.93772 0.767578C12.068 0.767578 14.0086 1.45965 15.1332 2.73768C16.2453 4.00143 16.4057 5.67463 16.4057 7.21721C16.4057 8.7633 16.2411 10.378 15.45 11.6142C14.6603 12.8481 13.3309 13.5858 11.3186 13.6606L10.024 15.3867C9.48085 16.1109 8.39459 16.1109 7.85147 15.3867L6.55683 13.6606C4.54452 13.5858 3.21515 12.8481 2.42545 11.6142C1.6343 10.378 1.46973 8.7633 1.46973 7.21721C1.46973 5.67463 1.6301 4.00143 2.7422 2.73768Z"
                                                                    fill="currentcolor" />
                                                            </g>
                                                            <defs>
                                                                <clipPath id="clip0_802_15128">
                                                                    <rect width="16.2938" height="16.2938" fill="white"
                                                                        transform="translate(0.790527 0.0888672)" />
                                                                </clipPath>
                                                            </defs>
                                                        </svg>
                                                    </a></li>
                                                <li><a href="#!" class="post-icons">
                                                        <svg width="16" height="15" viewBox="0 0 16 15"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M0.881358 0.85583C0.989046 0.607764 1.23369 0.447266 1.50412 0.447266H15.0823C15.3226 0.447266 15.545 0.574273 15.667 0.781227C15.7891 0.98818 15.7927 1.24425 15.6765 1.45455L8.54796 14.3538C8.40955 14.6043 8.12895 14.7411 7.84639 14.6958C7.56383 14.6506 7.33998 14.433 7.28671 14.1518L5.89765 6.82066L1.00815 1.58978C0.823478 1.39222 0.773671 1.1039 0.881358 0.85583ZM7.28128 6.8294L8.27027 12.0491L13.2152 3.10106L7.28128 6.8294ZM12.7256 1.80508H3.06804L6.64135 5.62788L12.7256 1.80508Z"
                                                                fill="currentcolor" />
                                                        </svg>
                                                    </a></li>
                                            </ul>
                                            <button type="button" class="save-button">
                                                <svg width="11" height="14" viewBox="0 0 11 14" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M0.569336 2.60009C0.569336 1.66676 1.32594 0.910156 2.25927 0.910156H9.019C9.95232 0.910156 10.7089 1.66676 10.7089 2.60009V12.7397C10.7089 12.9607 10.5797 13.1613 10.3784 13.2526C10.1771 13.344 9.94102 13.3092 9.77467 13.1636L5.63913 9.54501L1.50359 13.1636C1.33725 13.3092 1.10115 13.344 0.899877 13.2526C0.6986 13.1613 0.569336 12.9607 0.569336 12.7397V2.60009ZM2.25927 2.03678C1.94816 2.03678 1.69596 2.28898 1.69596 2.60009V11.4983L5.26819 8.37257C5.48057 8.18674 5.79769 8.18674 6.01007 8.37257L9.58231 11.4983V2.60009C9.58231 2.28898 9.3301 2.03678 9.019 2.03678H2.25927Z"
                                                        fill="currentcolor" />
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="likes-commentsBox">
                                            <a href="#!" class="post-likes number-link">25 Likes </a>
                                            <a href="#!" class="post-likes  number-link"> | 12 Comments</a>
                                        </div>
                                        <p class="post-mess">
                                            Lorem ipsum dolor sit amet consectetur. Vulputate blandit quam aenean tempus.
                                            Quis consequat habitasse malesuada neque. Et tortor ntristique aenean... <a
                                                href="#!" class="more-btn">more</a>
                                        </p>
                                        <span class="post-time number-link">17 April 2024, 9:30 pM</span>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="postCard-block">
                                    <div class="postCard-box">
                                        <div class="postCard-details">
                                            <figure class="userImg">
                                                <img src="{{ asset('frontend/img/user01.png') }}" alt="image">
                                            </figure>
                                            <div class="user-info">
                                                <h3 class="userName">Jemma Ray</h3>
                                                <div class="user-data">
                                                    <span class="user-subText">Turtles/Leatherback</span>
                                                    <span class="user-subText text-color">Shiloh, Hawaii</span>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="postCard-rightBox">
                                            <div class="dropdown">
                                                <a class="action_btnEdite dropdown-toggle" href="#" role="button"
                                                    id="dropdownMenuLink72" data-bs-toggle="dropdown"
                                                    aria-expanded="false"><svg width="3" height="13"
                                                        viewBox="0 0 3 13" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M2.60261 1.45805C2.60261 2.13683 2.05235 2.68709 1.37357 2.68709C0.694792 2.68709 0.144531 2.13683 0.144531 1.45805C0.144531 0.779264 0.694792 0.229004 1.37357 0.229004C2.05235 0.229004 2.60261 0.779264 2.60261 1.45805Z"
                                                            fill="currentcolor" />
                                                        <path
                                                            d="M2.60261 6.37421C2.60261 7.05299 2.05235 7.60325 1.37357 7.60325C0.694792 7.60325 0.144531 7.05299 0.144531 6.37421C0.144531 5.69543 0.694792 5.14517 1.37357 5.14517C2.05235 5.14517 2.60261 5.69543 2.60261 6.37421Z"
                                                            fill="currentcolor" />
                                                        <path
                                                            d="M1.37357 12.5194C2.05235 12.5194 2.60261 11.9692 2.60261 11.2904C2.60261 10.6116 2.05235 10.0613 1.37357 10.0613C0.694792 10.0613 0.144531 10.6116 0.144531 11.2904C0.144531 11.9692 0.694792 12.5194 1.37357 12.5194Z"
                                                            fill="currentcolor" />
                                                    </svg>
                                                </a>
                                                <ul class="dropdown-menu dropdown-menu-end action-dropdown">
                                                    <li><a class="dropdown-item" href="#!">
                                                            <span class="link-icons">
                                                                <svg width="15" height="15" viewBox="0 0 15 15"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M8.58012 10.47C8.58012 10.87 8.25012 11.2 7.85012 11.2C7.45012 11.2 7.12012 10.87 7.12012 10.47C7.12012 10.07 7.45012 9.75 7.85012 9.75C8.25012 9.75 8.58012 10.08 8.58012 10.47Z"
                                                                        fill="currentcolor" stroke="black"
                                                                        stroke-width="0.1" />
                                                                    <path
                                                                        d="M8.54016 4.96L8.30016 8.73C8.30016 8.81 8.23016 8.87 8.16016 8.87H7.54016C7.47016 8.87 7.40016 8.81 7.40016 8.73L7.16016 4.96C7.16016 4.84 7.20016 4.73 7.28016 4.64C7.36016 4.55 7.47016 4.5 7.60016 4.5H8.10016C8.23016 4.5 8.34016 4.55 8.42016 4.64C8.50016 4.73 8.54016 4.84 8.54016 4.96Z"
                                                                        fill="currentcolor" stroke="black"
                                                                        stroke-width="0.1" />
                                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                                        d="M7.85 1C4.07 1 1 4.07 1 7.85C1 11.63 4.07 14.7 7.85 14.7C11.63 14.7 14.7 11.63 14.7 7.85C14.7 4.07 11.63 1 7.85 1ZM7.85 13.83C4.55 13.83 1.87 11.15 1.87 7.85C1.87 4.55 4.55 1.87 7.85 1.87C11.15 1.87 13.83 4.55 13.83 7.85C13.83 11.15 11.15 13.83 7.85 13.83Z"
                                                                        fill="currentcolor" stroke="black"
                                                                        stroke-width="0.1" />
                                                                </svg>
                                                            </span> Report</a></li>
                                                    <li><a class="dropdown-item" href="#!"><span class="link-icons">
                                                                <svg width="14" height="14" viewBox="0 0 14 14"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <path
                                                                        d="M6.9 0C3.1 0 0 3.1 0 6.9C0 10.7 3.1 13.8 6.9 13.8C10.7 13.8 13.8 10.7 13.8 6.9C13.8 3.1 10.7 0 6.9 0ZM2.32 10.62C1.47 9.57 1 8.25 1 6.9C1 3.65 3.65 1 6.9 1C8.25 1 9.57 1.47 10.62 2.32L10.7 2.39L2.39 10.7L2.32 10.62ZM6.9 12.8C5.55 12.8 4.23 12.33 3.19 11.48L3.1 11.41L11.41 3.1L11.48 3.19C12.33 4.23 12.8 5.55 12.8 6.9C12.8 10.15 10.15 12.8 6.9 12.8Z"
                                                                        fill="currentcolor" />
                                                                </svg>
                                                            </span>Block</a></li>
                                                    <li><a class="dropdown-item" href="#!"><span class="link-icons">
                                                                <svg width="14" height="14" viewBox="0 0 14 14"
                                                                    fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                    <mask id="mask0_575_1255" style="mask-type:luminance"
                                                                        maskUnits="userSpaceOnUse" x="0" y="0"
                                                                        width="14" height="14">
                                                                        <path d="M14 0H0V14H14V0Z" fill="white" />
                                                                        <path
                                                                            d="M7.68359 7C7.68359 7.37754 7.37753 7.68359 7 7.68359C6.62246 7.68359 6.31641 7.37754 6.31641 7C6.31641 6.62247 6.62246 6.31641 7 6.31641C7.37753 6.31641 7.68359 6.62247 7.68359 7Z"
                                                                            fill="white" />
                                                                        <path
                                                                            d="M10.418 7C10.418 7.37754 10.1119 7.68359 9.73437 7.68359C9.35684 7.68359 9.05078 7.37754 9.05078 7C9.05078 6.62247 9.35684 6.31641 9.73437 6.31641C10.1119 6.31641 10.418 6.62247 10.418 7Z"
                                                                            fill="white" />
                                                                        <path
                                                                            d="M4.94921 7C4.94921 7.37754 4.64316 7.68359 4.26562 7.68359C3.88809 7.68359 3.58203 7.37754 3.58203 7C3.58203 6.62247 3.88809 6.31641 4.26562 6.31641C4.64316 6.31641 4.94921 6.62247 4.94921 7Z"
                                                                            fill="white" />
                                                                    </mask>
                                                                    <g mask="url(#mask0_575_1255)">
                                                                        <mask id="mask1_575_1255"
                                                                            style="mask-type:luminance"
                                                                            maskUnits="userSpaceOnUse" x="0" y="0"
                                                                            width="14" height="14">
                                                                            <path d="M0 5.62668e-05H14V14H0V5.62668e-05Z"
                                                                                fill="white" />
                                                                        </mask>
                                                                        <g mask="url(#mask1_575_1255)">
                                                                            <path
                                                                                d="M6.99998 0.546927C3.43603 0.546927 0.546875 3.43609 0.546875 7.00003C0.546875 8.2547 0.905323 9.42547 1.52485 10.4163L0.546875 13.4531L3.58375 12.4752C4.57454 13.0947 5.74532 13.4531 6.99998 13.4531C10.5639 13.4531 13.4531 10.564 13.4531 7.00003C13.4531 3.43609 10.5639 0.546927 6.99998 0.546927Z"
                                                                                stroke="currentcolor"
                                                                                stroke-miterlimit="10"
                                                                                stroke-linecap="round"
                                                                                stroke-linejoin="round" />
                                                                            <path
                                                                                d="M7.68359 7.00002C7.68359 7.37755 7.37753 7.68361 7 7.68361C6.62246 7.68361 6.31641 7.37755 6.31641 7.00002C6.31641 6.62248 6.62246 6.31643 7 6.31643C7.37753 6.31643 7.68359 6.62248 7.68359 7.00002Z"
                                                                                fill="currentcolor" />
                                                                            <path
                                                                                d="M10.418 7.00002C10.418 7.37755 10.1119 7.68361 9.73437 7.68361C9.35684 7.68361 9.05078 7.37755 9.05078 7.00002C9.05078 6.62248 9.35684 6.31643 9.73437 6.31643C10.1119 6.31643 10.418 6.62248 10.418 7.00002Z"
                                                                                fill="currentcolor" />
                                                                            <path
                                                                                d="M4.94921 7.00002C4.94921 7.37755 4.64316 7.68361 4.26562 7.68361C3.88809 7.68361 3.58203 7.37755 3.58203 7.00002C3.58203 6.62248 3.88809 6.31643 4.26562 6.31643C4.64316 6.31643 4.94921 6.62248 4.94921 7.00002Z"
                                                                                fill="currentcolor" />
                                                                        </g>
                                                                    </g>
                                                                </svg>
                                                            </span>Chat</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="inner-swiperblock">
                                        <div class="swiper postSwiper">
                                            <div class="swiper-wrapper">
                                                <div class="swiper-slide">
                                                    <div class="post-innerBox">
                                                        <img src="{{ asset('frontend/img/psot-img.png') }}"
                                                            alt="">
                                                    </div>
                                                </div>
                                                <div class="swiper-slide">
                                                    <div class="post-innerBox">
                                                        <img src="{{ asset('frontend/img/psot-img01.png') }}"
                                                            alt="">
                                                    </div>
                                                </div>
                                                <div class="swiper-slide">
                                                    <div class="post-innerBox">
                                                        <img src="{{ asset('frontend/img/psot-img02.png') }}"
                                                            alt="">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="swiper-button-next inner-swiper"></div>
                                            <div class="swiper-button-prev inner-swiper"></div>
                                            <div class="swiper-pagination inner-swiperSlide"></div>
                                        </div>
                                        <div class="slideCounter">
                                            <span class="activeSlideNumber">1</span>
                                            <span class="counterCenterIcon">/</span>
                                            <span class="totalSlideNumber">4</span>
                                        </div>
                                    </div>
                                    <div class="post-infoBlock">
                                        <div class="post-btnBox">
                                            <ul class="social-mediaButton">
                                                <li><a href="#!" class="post-icons">
                                                        <svg width="16" height="15" viewBox="0 0 16 15"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M3.59569 1.83301C2.48335 2.00177 1.47256 2.93609 1.47256 4.67515C1.47256 5.5205 1.82572 6.44707 2.42806 7.39843C3.026 8.34285 3.83471 9.25703 4.66211 10.0636C5.48699 10.8678 6.31457 11.5497 6.93727 12.0313C7.19267 12.2288 7.41269 12.3919 7.58274 12.5151C7.75278 12.3919 7.97281 12.2288 8.22821 12.0313C8.85091 11.5497 9.67849 10.8678 10.5034 10.0636C11.3308 9.25703 12.1395 8.34285 12.7374 7.39843C13.3398 6.44707 13.6929 5.5205 13.6929 4.67515C13.6929 2.93609 12.6821 2.00177 11.5698 1.83301C10.4402 1.66164 9.01529 2.25621 8.19954 4.02982C8.08875 4.2707 7.84787 4.42504 7.58274 4.42504C7.31761 4.42504 7.07673 4.2707 6.96594 4.02982C6.15019 2.25621 4.72528 1.66164 3.59569 1.83301ZM7.58274 13.3459L7.96163 13.9092C7.73253 14.0633 7.43295 14.0633 7.20385 13.9092L7.58274 13.3459ZM7.58274 2.40523C6.4862 0.904226 4.88184 0.264531 3.39202 0.490558C1.57272 0.766573 0.114746 2.3096 0.114746 4.67515C0.114746 5.88212 0.610222 7.06555 1.28084 8.12476C1.95585 9.19092 2.84441 10.1879 3.71428 11.0359C4.58668 11.8864 5.45637 12.6025 6.10662 13.1054C6.43231 13.3572 6.70431 13.5566 6.89588 13.6938C6.99169 13.7623 7.06748 13.8154 7.1199 13.8517C7.14611 13.8699 7.16649 13.8838 7.18062 13.8935L7.19707 13.9047L7.20169 13.9078L7.20385 13.9092C7.20385 13.9092 7.20385 13.9092 7.58274 13.3459C7.96163 13.9092 7.96163 13.9092 7.96163 13.9092L7.96379 13.9078L7.96841 13.9047L7.98486 13.8935C7.99899 13.8838 8.01937 13.8699 8.04558 13.8517C8.098 13.8154 8.17379 13.7623 8.2696 13.6938C8.46117 13.5566 8.73317 13.3572 9.05886 13.1054C9.70911 12.6025 10.5788 11.8864 11.4512 11.0359C12.3211 10.1879 13.2096 9.19092 13.8846 8.12476C14.5553 7.06555 15.0507 5.88212 15.0507 4.67515C15.0507 2.3096 13.5928 0.766573 11.7735 0.490558C10.2836 0.264531 8.67928 0.904226 7.58274 2.40523Z"
                                                                fill="currentcolor" />
                                                        </svg>
                                                    </a></li>
                                                <li><a href="#!" class="post-icons">
                                                        <svg width="18" height="17" viewBox="0 0 18 17"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <g clip-path="url(#clip0_802_15128)">
                                                                <path fill-rule="evenodd" clip-rule="evenodd"
                                                                    d="M3.76153 3.6347C3.00663 4.49254 2.82754 5.7047 2.82754 7.21721C2.82754 8.7262 3.00242 9.99683 3.5691 10.8823C4.09303 11.7009 5.03358 12.309 6.90099 12.309C7.11469 12.309 7.31591 12.4096 7.44412 12.5806L8.93772 14.5721L10.4313 12.5806C10.5595 12.4096 10.7608 12.309 10.9744 12.309C12.8419 12.309 13.7824 11.7009 14.3063 10.8823C14.873 9.99683 15.0479 8.7262 15.0479 7.21721C15.0479 5.7047 14.8688 4.49254 14.1139 3.6347C13.3716 2.79114 11.9176 2.1254 8.93772 2.1254C5.95785 2.1254 4.50385 2.79114 3.76153 3.6347ZM2.7422 2.73768C3.86687 1.45965 5.80741 0.767578 8.93772 0.767578C12.068 0.767578 14.0086 1.45965 15.1332 2.73768C16.2453 4.00143 16.4057 5.67463 16.4057 7.21721C16.4057 8.7633 16.2411 10.378 15.45 11.6142C14.6603 12.8481 13.3309 13.5858 11.3186 13.6606L10.024 15.3867C9.48085 16.1109 8.39459 16.1109 7.85147 15.3867L6.55683 13.6606C4.54452 13.5858 3.21515 12.8481 2.42545 11.6142C1.6343 10.378 1.46973 8.7633 1.46973 7.21721C1.46973 5.67463 1.6301 4.00143 2.7422 2.73768Z"
                                                                    fill="currentcolor" />
                                                            </g>
                                                            <defs>
                                                                <clipPath id="clip0_802_15128">
                                                                    <rect width="16.2938" height="16.2938" fill="white"
                                                                        transform="translate(0.790527 0.0888672)" />
                                                                </clipPath>
                                                            </defs>
                                                        </svg>
                                                    </a></li>
                                                <li><a href="#!" class="post-icons">
                                                        <svg width="16" height="15" viewBox="0 0 16 15"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="M0.881358 0.85583C0.989046 0.607764 1.23369 0.447266 1.50412 0.447266H15.0823C15.3226 0.447266 15.545 0.574273 15.667 0.781227C15.7891 0.98818 15.7927 1.24425 15.6765 1.45455L8.54796 14.3538C8.40955 14.6043 8.12895 14.7411 7.84639 14.6958C7.56383 14.6506 7.33998 14.433 7.28671 14.1518L5.89765 6.82066L1.00815 1.58978C0.823478 1.39222 0.773671 1.1039 0.881358 0.85583ZM7.28128 6.8294L8.27027 12.0491L13.2152 3.10106L7.28128 6.8294ZM12.7256 1.80508H3.06804L6.64135 5.62788L12.7256 1.80508Z"
                                                                fill="currentcolor" />
                                                        </svg>
                                                    </a></li>
                                            </ul>
                                            <button type="button" class="save-button">
                                                <svg width="11" height="14" viewBox="0 0 11 14" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path fill-rule="evenodd" clip-rule="evenodd"
                                                        d="M0.569336 2.60009C0.569336 1.66676 1.32594 0.910156 2.25927 0.910156H9.019C9.95232 0.910156 10.7089 1.66676 10.7089 2.60009V12.7397C10.7089 12.9607 10.5797 13.1613 10.3784 13.2526C10.1771 13.344 9.94102 13.3092 9.77467 13.1636L5.63913 9.54501L1.50359 13.1636C1.33725 13.3092 1.10115 13.344 0.899877 13.2526C0.6986 13.1613 0.569336 12.9607 0.569336 12.7397V2.60009ZM2.25927 2.03678C1.94816 2.03678 1.69596 2.28898 1.69596 2.60009V11.4983L5.26819 8.37257C5.48057 8.18674 5.79769 8.18674 6.01007 8.37257L9.58231 11.4983V2.60009C9.58231 2.28898 9.3301 2.03678 9.019 2.03678H2.25927Z"
                                                        fill="currentcolor" />
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="likes-commentsBox">
                                            <a href="#!" class="post-likes number-link">25 Likes </a>
                                            <a href="#!" class="post-likes  number-link"> | 12 Comments</a>
                                        </div>
                                        <p class="post-mess">
                                            Lorem ipsum dolor sit amet consectetur. Vulputate blandit quam aenean tempus.
                                            Quis consequat habitasse malesuada neque. Et tortor ntristique aenean... <a
                                                href="#!" class="more-btn">more</a>
                                        </p>
                                        <span class="post-time number-link">17 April 2024, 9:30 pM</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-button-prev outer-swiper"></div>
                        <div class="swiper-button-next outer-swiper"></div>
                    </div>
                </div>
                <div class="view-moreBtn">
                    <a href="#!" class="themes-button number-link">View More
                        <span class="right-arrow"><svg width="23" height="16" viewBox="0 0 23 16" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M12.9536 2.00488C14.1653 3.3595 17.4722 5.9526 21.0061 5.48799C16.4878 8.26484 16.1851 12.9852 16.1851 12.9852"
                                    stroke="white" stroke-linecap="round" />
                                <path d="M20.2488 5.61496L2.4027 12.4816" stroke="white" stroke-linecap="round" />
                            </svg>
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </section>
    @if (!empty($response['home_map']))
        <section class="printingMap_block">
            <img src="{{ asset('frontend/img/triangle_shap.png') }}" alt="" class="triangle_shap">
            <img src="{{ asset('frontend/img/shef-img00.png') }}" alt="" class="flower_shap">
            <div class="container">
                <div class="print_mapBox">
                    <div class="printing_map">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d45935326.61435373!2d51.37046350082418!3d45.35547664466818!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x396c4adf4c57e281%3A0xce1c63a0cf22e09!2sJaipur%2C%20Rajasthan!5e0!3m2!1sen!2sin!4v1714557467870!5m2!1sen!2sin"
                            allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    <div class="print_contentBox">
                        <h4 class="print_boxTitle">{{ $response['home_map']->title }}.</h4>
                        <p class="print_boxDesc">{{ $response['home_map']->description }}.</p>
                    </div>
                </div>
            </div>
        </section>
    @endif
    @if (!empty($response['about_tag']))
        <section class="aboutUs_wrapper">
            <div>
                <img src="{{ asset('frontend/img/about_shap_flower.png') }}" alt="" class="about_shap_flower">
                <img src="{{ asset('frontend/img/about_fisShap.png') }}" alt="" class="about_fisShap">
                <img src="{{ asset('frontend/img/about_pankShap.png') }}" alt="" class="about_pankShap">
            </div>
            <div class="container">
                <div class="aboutUs_block">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="aboutUs_imgDiv">
                                <div>
                                    <img src="{{ asset('frontend/img/about_blueShap.png') }}" alt=""
                                        class="about_blueShap">
                                    <img src="{{ asset('frontend/img/about_cricleShap.png') }}" alt=""
                                        class="about_cricleShap">
                                </div>
                                <div class="aboutUs_imgBox">
                                    <img src="{{ $response['about_tag']->image_url }}" alt="">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="about_rightContent">
                                <div class="key-featuresBox">
                                    <span class="section-title text-start">About us</span>
                                    <h2 class="section-heading text-trans text-start">About WILDTAG</h2>
                                </div>
                                @if (isset($response['about_tag']))
                                    @php
                                        $descriptions = json_decode($response['about_tag']->description);
                                    @endphp
                                @endif
                                <span class="aboutEmpowers_text">{{ $response['about_tag']->title }}:</span>
                                <ul class="about_categoryList">
                                    @if (isset($response['about_tag']) && !empty($response['about_tag']->description))
                                        @foreach ($descriptions as $description)
                                            <li class="about_categoryItem">{{ $description }}.
                                            </li>
                                        @endforeach
                                    @endif
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    @endif
    <!-- testimonials -->
    <section
        class="testimonials-wrapper"style="background: linear-gradient(to left, rgb(0 19 42 / 60%), rgb(0 10 27 / 60%)), url({{ asset('frontend/img/section-bgImg01.png') }});">
        <div class="container">
            <div class="testimonials-block">
                <div class="section_box mb-0">
                    <span class="section-title">Testimonials</span>
                    <h2 class="section-heading text-trans text-white">Personal Experiences Using WildTag</h2>
                </div>
                <div class="testimonials-sliderBox">
                    <div class="swiper tesimonialSlider">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="testimonialsCard-box">
                                    <figure class="testiCard-img">
                                        <img src="{{ asset('frontend/img/user04.png') }}" alt="image">
                                    </figure>
                                    <div class="testiCard-info">
                                        <h4 class="card-userName">John Doe</h4>
                                        <ul class="rating-items">
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="20" height="20" viewBox="0 0 20 20"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M18.3203 8.93593L14.7969 12.0109L15.8524 16.5891C15.9082 16.8284 15.8923 17.0789 15.8065 17.3092C15.7208 17.5395 15.5691 17.7395 15.3703 17.884C15.1716 18.0286 14.9346 18.1113 14.6891 18.122C14.4436 18.1326 14.2004 18.0706 13.9899 17.9437L9.99689 15.5219L6.01252 17.9437C5.80202 18.0706 5.55881 18.1326 5.31328 18.122C5.06775 18.1113 4.83079 18.0286 4.63204 17.884C4.4333 17.7395 4.28157 17.5395 4.19584 17.3092C4.1101 17.0789 4.09416 16.8284 4.15002 16.5891L5.20392 12.0156L1.6797 8.93593C1.49331 8.77517 1.35852 8.56295 1.29225 8.32589C1.22598 8.08883 1.23117 7.83748 1.30718 7.60336C1.38319 7.36924 1.52663 7.16278 1.71952 7.00985C1.9124 6.85693 2.14614 6.76436 2.39142 6.74375L7.03674 6.3414L8.85002 2.0164C8.94471 1.78946 9.10443 1.59561 9.30907 1.45926C9.51371 1.32291 9.75411 1.25015 10 1.25015C10.2459 1.25015 10.4863 1.32291 10.691 1.45926C10.8956 1.59561 11.0553 1.78946 11.15 2.0164L12.9688 6.3414L17.6125 6.74375C17.8578 6.76436 18.0915 6.85693 18.2844 7.00985C18.4773 7.16278 18.6207 7.36924 18.6968 7.60336C18.7728 7.83748 18.778 8.08883 18.7117 8.32589C18.6454 8.56295 18.5106 8.77517 18.3242 8.93593H18.3203Z"
                                                            fill="#DEDEDE" />
                                                    </svg>
                                                </a>
                                            </li>
                                        </ul>
                                        <p class="testi-subText">Browse through a dynamic feed of user-generated content to
                                            discover new marine species, habitats, and conservation efforts happening in the
                                            Caribbean region.
                                        </p>
                                        <span class="month-text">6 month ago</span>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="testimonialsCard-box">
                                    <figure class="testiCard-img">
                                        <img src="{{ asset('frontend/img/user04.png') }}" alt="image">
                                    </figure>
                                    <div class="testiCard-info">
                                        <h4 class="card-userName">John Doe</h4>
                                        <ul class="rating-items">
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="20" height="20" viewBox="0 0 20 20"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M18.3203 8.93593L14.7969 12.0109L15.8524 16.5891C15.9082 16.8284 15.8923 17.0789 15.8065 17.3092C15.7208 17.5395 15.5691 17.7395 15.3703 17.884C15.1716 18.0286 14.9346 18.1113 14.6891 18.122C14.4436 18.1326 14.2004 18.0706 13.9899 17.9437L9.99689 15.5219L6.01252 17.9437C5.80202 18.0706 5.55881 18.1326 5.31328 18.122C5.06775 18.1113 4.83079 18.0286 4.63204 17.884C4.4333 17.7395 4.28157 17.5395 4.19584 17.3092C4.1101 17.0789 4.09416 16.8284 4.15002 16.5891L5.20392 12.0156L1.6797 8.93593C1.49331 8.77517 1.35852 8.56295 1.29225 8.32589C1.22598 8.08883 1.23117 7.83748 1.30718 7.60336C1.38319 7.36924 1.52663 7.16278 1.71952 7.00985C1.9124 6.85693 2.14614 6.76436 2.39142 6.74375L7.03674 6.3414L8.85002 2.0164C8.94471 1.78946 9.10443 1.59561 9.30907 1.45926C9.51371 1.32291 9.75411 1.25015 10 1.25015C10.2459 1.25015 10.4863 1.32291 10.691 1.45926C10.8956 1.59561 11.0553 1.78946 11.15 2.0164L12.9688 6.3414L17.6125 6.74375C17.8578 6.76436 18.0915 6.85693 18.2844 7.00985C18.4773 7.16278 18.6207 7.36924 18.6968 7.60336C18.7728 7.83748 18.778 8.08883 18.7117 8.32589C18.6454 8.56295 18.5106 8.77517 18.3242 8.93593H18.3203Z"
                                                            fill="#DEDEDE" />
                                                    </svg>
                                                </a>
                                            </li>
                                        </ul>
                                        <p class="testi-subText">Browse through a dynamic feed of user-generated content
                                            to discover new marine species, habitats, and conservation efforts happening in
                                            the Caribbean region.
                                        </p>
                                        <span class="month-text">6 month ago</span>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="testimonialsCard-box">
                                    <figure class="testiCard-img">
                                        <img src="{{ asset('frontend/img/user04.png') }}" alt="image">
                                    </figure>
                                    <div class="testiCard-info">
                                        <h4 class="card-userName">John Doe</h4>
                                        <ul class="rating-items">
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="20" height="20" viewBox="0 0 20 20"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M18.3203 8.93593L14.7969 12.0109L15.8524 16.5891C15.9082 16.8284 15.8923 17.0789 15.8065 17.3092C15.7208 17.5395 15.5691 17.7395 15.3703 17.884C15.1716 18.0286 14.9346 18.1113 14.6891 18.122C14.4436 18.1326 14.2004 18.0706 13.9899 17.9437L9.99689 15.5219L6.01252 17.9437C5.80202 18.0706 5.55881 18.1326 5.31328 18.122C5.06775 18.1113 4.83079 18.0286 4.63204 17.884C4.4333 17.7395 4.28157 17.5395 4.19584 17.3092C4.1101 17.0789 4.09416 16.8284 4.15002 16.5891L5.20392 12.0156L1.6797 8.93593C1.49331 8.77517 1.35852 8.56295 1.29225 8.32589C1.22598 8.08883 1.23117 7.83748 1.30718 7.60336C1.38319 7.36924 1.52663 7.16278 1.71952 7.00985C1.9124 6.85693 2.14614 6.76436 2.39142 6.74375L7.03674 6.3414L8.85002 2.0164C8.94471 1.78946 9.10443 1.59561 9.30907 1.45926C9.51371 1.32291 9.75411 1.25015 10 1.25015C10.2459 1.25015 10.4863 1.32291 10.691 1.45926C10.8956 1.59561 11.0553 1.78946 11.15 2.0164L12.9688 6.3414L17.6125 6.74375C17.8578 6.76436 18.0915 6.85693 18.2844 7.00985C18.4773 7.16278 18.6207 7.36924 18.6968 7.60336C18.7728 7.83748 18.778 8.08883 18.7117 8.32589C18.6454 8.56295 18.5106 8.77517 18.3242 8.93593H18.3203Z"
                                                            fill="#DEDEDE" />
                                                    </svg>
                                                </a>
                                            </li>
                                        </ul>
                                        <p class="testi-subText">Browse through a dynamic feed of user-generated content
                                            to discover new marine species, habitats, and conservation efforts happening in
                                            the Caribbean region.
                                        </p>
                                        <span class="month-text">6 month ago</span>
                                    </div>
                                </div>
                            </div>
                            <div class="swiper-slide">
                                <div class="testimonialsCard-box">
                                    <figure class="testiCard-img">
                                        <img src="{{ asset('frontend/img/user04.png') }}" alt="image">
                                    </figure>
                                    <div class="testiCard-info">
                                        <h4 class="card-userName">John Doe</h4>
                                        <ul class="rating-items">
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="18" height="18" viewBox="0 0 18 18"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M17.3203 7.93593L13.7969 11.0109L14.8524 15.5891C14.9082 15.8284 14.8923 16.0789 14.8065 16.3092C14.7208 16.5395 14.5691 16.7395 14.3703 16.884C14.1716 17.0286 13.9346 17.1113 13.6891 17.122C13.4436 17.1326 13.2004 17.0706 12.9899 16.9437L8.99689 14.5219L5.01252 16.9437C4.80202 17.0706 4.55881 17.1326 4.31328 17.122C4.06775 17.1113 3.83079 17.0286 3.63204 16.884C3.4333 16.7395 3.28157 16.5395 3.19584 16.3092C3.1101 16.0789 3.09416 15.8284 3.15002 15.5891L4.20392 11.0156L0.679705 7.93593C0.493305 7.77517 0.358519 7.56295 0.292249 7.32589C0.225978 7.08883 0.231173 6.83748 0.307183 6.60336C0.383193 6.36924 0.526633 6.16278 0.719516 6.00985C0.912399 5.85693 1.14614 5.76436 1.39142 5.74375L6.03674 5.3414L7.85002 1.0164C7.94471 0.789462 8.10443 0.595612 8.30907 0.45926C8.51371 0.322909 8.75411 0.250153 9.00002 0.250153C9.24592 0.250153 9.48633 0.322909 9.69097 0.45926C9.8956 0.595612 10.0553 0.789462 10.15 1.0164L11.9688 5.3414L16.6125 5.74375C16.8578 5.76436 17.0915 5.85693 17.2844 6.00985C17.4773 6.16278 17.6207 6.36924 17.6968 6.60336C17.7728 6.83748 17.778 7.08883 17.7117 7.32589C17.6454 7.56295 17.5106 7.77517 17.3242 7.93593H17.3203Z"
                                                            fill="#F3AF00" />
                                                    </svg>
                                                </a>
                                            </li>
                                            <li>
                                                <a href="#!" class="ratingIcons">
                                                    <svg width="20" height="20" viewBox="0 0 20 20"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M18.3203 8.93593L14.7969 12.0109L15.8524 16.5891C15.9082 16.8284 15.8923 17.0789 15.8065 17.3092C15.7208 17.5395 15.5691 17.7395 15.3703 17.884C15.1716 18.0286 14.9346 18.1113 14.6891 18.122C14.4436 18.1326 14.2004 18.0706 13.9899 17.9437L9.99689 15.5219L6.01252 17.9437C5.80202 18.0706 5.55881 18.1326 5.31328 18.122C5.06775 18.1113 4.83079 18.0286 4.63204 17.884C4.4333 17.7395 4.28157 17.5395 4.19584 17.3092C4.1101 17.0789 4.09416 16.8284 4.15002 16.5891L5.20392 12.0156L1.6797 8.93593C1.49331 8.77517 1.35852 8.56295 1.29225 8.32589C1.22598 8.08883 1.23117 7.83748 1.30718 7.60336C1.38319 7.36924 1.52663 7.16278 1.71952 7.00985C1.9124 6.85693 2.14614 6.76436 2.39142 6.74375L7.03674 6.3414L8.85002 2.0164C8.94471 1.78946 9.10443 1.59561 9.30907 1.45926C9.51371 1.32291 9.75411 1.25015 10 1.25015C10.2459 1.25015 10.4863 1.32291 10.691 1.45926C10.8956 1.59561 11.0553 1.78946 11.15 2.0164L12.9688 6.3414L17.6125 6.74375C17.8578 6.76436 18.0915 6.85693 18.2844 7.00985C18.4773 7.16278 18.6207 7.36924 18.6968 7.60336C18.7728 7.83748 18.778 8.08883 18.7117 8.32589C18.6454 8.56295 18.5106 8.77517 18.3242 8.93593H18.3203Z"
                                                            fill="#DEDEDE" />
                                                    </svg>
                                                </a>
                                            </li>
                                        </ul>
                                        <p class="testi-subText">Browse through a dynamic feed of user-generated content
                                            to discover new marine species, habitats, and conservation efforts happening in
                                            the Caribbean region.
                                        </p>
                                        <span class="month-text">6 month ago</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-buttonBox">
                        <div class="swiper-button-prev outer-swiper tesimol_prev"></div>
                        <div class="swiper-button-next outer-swiper tesimol_next"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    @if (!empty($response['download_app']))
        <section class="download-wrapper">
            <div>
                <img src="{{ asset('frontend/img/download_appRut.png') }}" alt="" class="download_appRut">
                <img src="{{ asset('frontend/img/shef-img08.png') }}" alt="image" class="download_AppFish">
            </div>
            <div class="container">
                <div class="download-app">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="download-appBox">
                                <h2 class="download-app-heading">{{ $response['download_app']->title }}</h2>
                                <p class="section-text text-white">{{ $response['download_app']->description }}.</p>
                                <div class="app-download-block">
                                    <h3 class="download-app-title">Get app from</h3>
                                    <div class="payment">
                                        <a href="#!" class="aap-linkImg">
                                            <img src="{{ asset('frontend/img/google-play.png') }}" alt="image">
                                        </a>
                                        <a href="#!" class="aap-linkImg">
                                            <img src="{{ asset('frontend/img/app-store.png') }}" alt="image">
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="download-app-img">
                                <img src="{{ $response['download_app']->image_url }}" alt="image">
                            </div>
                        </div>
                    </div>
                </div>
                <!-- app-block END -->
            </div>
        </section>
    @endif
@stop
