@extends('frontend.layouts.default')
@section('title','About Us')
@section('content')

<!-- top section -->
<section class="banner-section" style="background-image: url({{asset('frontend/img/banner-bgImg.png')}});">
    <div  class="banner-sectionImg">
        <img src="{{asset('frontend/img/banner-left.png')}}" alt="" class="left-img">
        <img src="{{asset('frontend/img/banner-right.png')}}" alt="" class="right-img">
    </div>
    <div class="container">
        <div class="breadcrumb_box">
            <nav aria-label="breadcrumb">
                <div class="page_banner_heading">
                    About Us
                </div>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">About Us</li>
                </ol>
            </nav>
        </div>
    </div>
</section>
 <!-- top section end -->

<section class="about-us-wrapper section_padding">
    <div class="container">
        <div class="aboutUs-block">
            @if(!empty($response['about_us']->image))
            <div class="aboutUs-imgBox">
            <img src="{{$response['about_us']?->image_url}}" alt="">
            </div>
            @endif

            @if(!empty($response['about_us']->description))
                {!!$response['about_us'] ?->description ?? ''!!}
            @endif
        </div>
    </div>
</section>
@stop