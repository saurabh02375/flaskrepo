<!-- footer -->
<footer class="footer_wrapper">
    <div class="container">
        <div class="row">
            <div class="col-6 col-md-3 col-lg-3 order-2 order-md-1">
                <div class="footer_inner text-end">
                    <h6>Contact Us</h6>
                    <ul class="footer-box">
                        <li>
                            <div class="footer-contactBox">
                                <h3 class="footer-contactText">Email</h3>
                                <a href="mailto:info@utip.com" class="footer-links">info@utip.com</a>
                            </div>

                        </li>
                        <li>
                            <div class="footer-contactBox">
                                <h3 class="footer-contactText">Phone</h3>
                                <a href="tel:+919554696546" class="footer-links number-link">+91 9554696546</a>
                            </div>

                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-12 col-md-6 col-lg-6 order-1 order-md-2 ">
                <div class="footer-block  text-center">
                    <figure class="footer_logo_box">
                        <a href="index.html">
                            <img src="{{ asset('frontend/img/footer-logo.png') }}" alt="image">
                        </a>
                    </figure>
                    <p class="footer_text">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur
                        adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                </div>
            </div>
            <div class="col-6 col-md-3 col-lg-3  mb-sm-0 order-3 order-md-3">
                <div class="footer_inner text-start">
                    <h6>Link</h6>
                    <ul class="footer-rightBox">
                        <li> <a href="#!" class="footer-social-links">
                                <span class="social-mediaIcons">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M0.399902 8.93324C0.399902 4.91084 0.399902 2.8991 1.65004 1.65004C2.8991 0.399902 4.91084 0.399902 8.93324 0.399902H11.0666C15.089 0.399902 17.1007 0.399902 18.3498 1.65004C19.5999 2.8991 19.5999 4.91084 19.5999 8.93324V11.0666C19.5999 15.089 19.5999 17.1007 18.3498 18.3498C17.1007 19.5999 15.089 19.5999 11.0666 19.5999H8.93324C4.91084 19.5999 2.8991 19.5999 1.65004 18.3498C0.399902 17.1007 0.399902 15.089 0.399902 11.0666V8.93324ZM16.3999 5.1999C16.3999 5.62425 16.2313 6.03122 15.9313 6.33127C15.6312 6.63133 15.2242 6.7999 14.7999 6.7999C14.3756 6.7999 13.9686 6.63133 13.6685 6.33127C13.3685 6.03122 13.1999 5.62425 13.1999 5.1999C13.1999 4.77556 13.3685 4.36859 13.6685 4.06853C13.9686 3.76847 14.3756 3.5999 14.7999 3.5999C15.2242 3.5999 15.6312 3.76847 15.9313 4.06853C16.2313 4.36859 16.3999 4.77556 16.3999 5.1999ZM12.1332 11.0666C12.1332 11.6324 11.9085 12.175 11.5084 12.5751C11.1083 12.9751 10.5657 13.1999 9.9999 13.1999C9.43411 13.1999 8.89149 12.9751 8.49141 12.5751C8.09133 12.175 7.86657 11.6324 7.86657 11.0666C7.86657 10.5008 8.09133 9.95815 8.49141 9.55808C8.89149 9.158 9.43411 8.93324 9.9999 8.93324C10.5657 8.93324 11.1083 9.158 11.5084 9.55808C11.9085 9.95815 12.1332 10.5008 12.1332 11.0666ZM14.2666 11.0666C14.2666 12.1982 13.817 13.2834 13.0169 14.0836C12.2167 14.8837 11.1315 15.3332 9.9999 15.3332C8.86831 15.3332 7.78307 14.8837 6.98291 14.0836C6.18276 13.2834 5.73324 12.1982 5.73324 11.0666C5.73324 9.93498 6.18276 8.84974 6.98291 8.04958C7.78307 7.24942 8.86831 6.7999 9.9999 6.7999C11.1315 6.7999 12.2167 7.24942 13.0169 8.04958C13.817 8.84974 14.2666 9.93498 14.2666 11.0666Z"
                                            fill="currentcolor" />
                                    </svg>
                                </span> Instagram</a>
                        </li>
                        <li> <a href="#!" class="footer-social-links">
                                <span class="social-mediaIcons">
                                    <svg width="21" height="20" viewBox="0 0 21 20" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd" clip-rule="evenodd"
                                            d="M20.1736 9.92059C20.1736 4.66296 15.7466 0.399902 10.2868 0.399902C4.82692 0.399902 0.399902 4.66296 0.399902 9.92059C0.399902 14.6724 4.01479 18.6112 8.74195 19.3261V12.6735H6.23095V9.92059H8.74195V7.82307C8.74195 5.43737 10.2184 4.1185 12.4764 4.1185C13.5583 4.1185 14.69 4.30466 14.69 4.30466V6.64786H13.4426C12.2152 6.64786 11.8312 7.38146 11.8312 8.13546V9.92059H14.573L14.1351 12.6735H11.8316V19.327C16.5588 18.6125 20.1736 14.6737 20.1736 9.92059Z"
                                            fill="currentcolor" />
                                    </svg>
                                </span>Facebook</a>
                        </li>
                        <li><a href="#!" class="footer-social-links">
                                <span class="social-mediaIcons">
                                    <svg width="20" height="20" viewBox="0 0 20 20" fill="none"
                                        xmlns="http://www.w3.org/2000/svg">
                                        <g clip-path="url(#clip0_424_1927)">
                                            <path
                                                d="M15.5207 1.32227H18.4647L12.0327 8.67427L19.5999 18.6767H13.6751L9.0351 12.6095L3.7247 18.6767H0.779102L7.6591 10.8127L0.399902 1.32307H6.4751L10.6695 6.86867L15.5207 1.32227ZM14.4879 16.9151H16.1191L5.5887 2.99187H3.8383L14.4879 16.9151Z"
                                                fill="currentcolor" />
                                        </g>
                                        <defs>
                                            <clipPath id="clip0_424_1927">
                                                <rect width="19.2" height="19.2" fill="currentcolor"
                                                    transform="translate(0.399902 0.399902)" />
                                            </clipPath>
                                        </defs>
                                    </svg>
                                </span>Twitter</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright">
        <div class="container">
            <div class="row gy-2 align-items-center">
                <div class="col-12 col-md-6">
                    <span>
                        ©
                        <script>
                            document.write(new Date().getFullYear());
                        </script> Caribbean OceanWatch.
                    </span>
                </div>
                <div class="col-12 col-md-6">
                    <div class="footer_copyLinks">
                        <a href="{{ route('web.faq') }}" class="page-links">FAQ</a>
                        <a href="privacy-policy.html" class="page-links">Privacy Policy</a>
                        <a href="terms-&-conditions.html" class="page-links">Terms & Condition</a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</footer>
<!-- footer end -->
