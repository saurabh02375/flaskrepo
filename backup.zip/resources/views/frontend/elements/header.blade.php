<!-- Header -->
<header id="header">
    <div class="header_container">
        <div class="row">
            <div class="col-12">
                <nav class="navbar navbar-expand-lg">
                    <a class="navbar-brand" href="{{route('web.index')}}">
                        <img src="{{asset('frontend/img/logo.png')}}" alt="image">
                    </a>
                    <div class="overlay" style="display:none"></div>
                    <div class="collapse navbar-collapse padd_topHeader">
                        <button class="navbar-toggler menuClose-icon" type="button">
                            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M1.4 14L0 12.6L5.6 7L0 1.4L1.4 0L7 5.6L12.6 0L14 1.4L8.4 7L14 12.6L12.6 14L7 8.4L1.4 14Z"
                                    fill="black" />
                            </svg>

                        </button>
                        <ul class="navbar-nav ms-auto">
                            <li class="nav-item {{ request()->routeIs('web.index') ? 'active' : '' }}">
                                <a class="nav-link" href="{{route('web.index')}}">Home</a>
                            </li>
                            <li class="nav-item {{ request()->routeIs('web.aboutus') ? 'active' : '' }}">
                                <a class="nav-link" href="{{route('web.aboutus')}}">About Us</a>
                            </li>
                            <li class="nav-item {{ request()->routeIs('web.contactUs') ? 'active' : '' }}">
                                <a class="nav-link" href="{{route('web.contactUs')}}">Contact Us</a>
                            </li>
                        </ul>

                        <div class="extra_nav">
                            <ul class="navbar-nav ms-auto">
                                <li class="nav-item ">
                                    <a class="nav-link header_filled_btn" href="{{route('auth.login')}}">Login</a>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <!--  ======= User DropDown =========  -->
                    <div class="nav-item dropdown user_dropdown d-none">

                        <a class="nav-link dropdown-toggle" href="javascript:void(0);" id="user-drop" role="button"
                            data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <img src="{{asset('frontend/img/user.png')}}" alt="image">
                        </a>
                        <div class="dropdown-menu" aria-labelledby="user-drop">
                            <div class="user_info">
                                <div class="user_name">
                                    <div>Alex Willson</div>
                                    <div class="user_email">
                                        <small>alexwillson@gmail.com</small>
                                    </div>
                                </div>
                                <ul>
                                    <li>
                                        <a href="#!"><i class="ion-android-person"></i> My Profile</a>
                                    </li>
                                    <li>
                                        <a href="#!"><i class="ion-log-out"></i> Logout</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <button class="navbar-toggler" type="button">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                </nav>
            </div>
        </div>
    </div>
</header>