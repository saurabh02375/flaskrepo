<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>@yield("title")</title>
    <link rel="apple-touch-icon" sizes="57x57" href="{{asset('frontend/img/favicon/apple-icon-57x57.png')}}">
    <link rel="apple-touch-icon" sizes="60x60" href="{{asset('frontend/img/favicon/apple-icon-60x60.png')}}">
    <link rel="apple-touch-icon" sizes="72x72" href="{{asset('frontend/img/favicon/apple-icon-72x72.png')}}">
    <link rel="apple-touch-icon" sizes="76x76" href="{{asset('frontend/img/favicon/apple-icon-76x76.png')}}">
    <link rel="apple-touch-icon" sizes="114x114" href="{{asset('frontend/img/favicon/apple-icon-114x114.png')}}">
    <link rel="apple-touch-icon" sizes="120x120" href="{{asset('frontend/img/favicon/apple-icon-120x120.png')}}">
    <link rel="apple-touch-icon" sizes="144x144" href="{{asset('frontend/img/favicon/apple-icon-144x144.png')}}">
    <link rel="apple-touch-icon" sizes="152x152" href="{{asset('frontend/img/favicon/apple-icon-152x152.png')}}">
    <link rel="apple-touch-icon" sizes="180x180" href="{{asset('frontend/img/favicon/apple-icon-180x180.png')}}">
    <link rel="icon" type="image/png" sizes="192x192" href="{{asset('frontend/img/favicon/android-icon-192x192.png')}}">
    <link rel="icon" type="image/png" sizes="32x32" href="{{asset('frontend/img/favicon/favicon-32x32.png')}}">
    <link rel="icon" type="image/png" sizes="96x96" href="{{asset('frontend/img/favicon/favicon-96x96.png')}}">
    <link rel="icon" type="image/png" sizes="16x16" href="{{asset('frontend/img/favicon/favicon-16x16.png')}}">
    <link rel="manifest" href="{{asset('frontend/img/favicon/manifest.json')}}">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="{{asset('frontend/img/favicon/ms-icon-144x144.png')}}">
    <meta name="theme-color" content="#ffffff">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100..900;1,100..900&display=swap"
        rel="stylesheet">

    <!-- Bootstrap  v5.3.0  CSS -->
    <link rel="stylesheet" href="{{asset('frontend/css/bootstrap.min.css')}}">
    <!--  Font-Awesome-5 CSS -->
    <link rel="stylesheet" href="{{asset('frontend/css/font-awesome.css')}}">
    <!-- Swiper 8.1.5 -->
    <link rel="stylesheet" href="{{asset('frontend/css/swiper-bundle.min.css')}}">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="{{asset('frontend/css/style.css')}}">
    <!-- Custom Responsive CSS -->
    <link rel="stylesheet" href="{{asset('frontend/css/responsive.css')}}">

</head>
    @php  $urlParameters = ['login','forgot-password','otp-verify','reset-password']; @endphp
<body>
    <!-- loader  -->
    <div class="loader-wrapper" style="display: none;">
        <div class="loader">
            <img src="{{asset('frontend/img/logo.png')}}" alt="">
        </div>
    </div>
    @if(!in_array(Request::segment(1),$urlParameters))
    @include('frontend.elements.header')
    @endif

    @yield("content")

    @if(!in_array(Request::segment(1),$urlParameters))
    @include('frontend.elements.footer')
    @endif
    
    <a href="javascript:void(0)" id="top-button" class="back_top">
        <span>
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 25 25" fill="none">
                <mask id="mask0_511_55" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="25"
                    height="25">
                    <rect x="0.5" y="0.25" width="24" height="24" fill="currentColor" />
                </mask>
                <g mask="url(#mask0_511_55)">
                    <path
                        d="M11.5 22.25V6.075L6.9 10.65L5.5 9.25L12.5 2.25L19.5 9.25L18.1 10.675L13.5 6.075V22.25H11.5Z"
                        fill="currentColor" />
                </g>
            </svg>
        </span>
    </a>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
    <!-- Bootstrap v5.3.0  -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Swiper 10.0.3 -->
    <script src="{{asset('frontend/js/jquery.matchHeight-min.js')}}"></script>
    <script src="{{asset('frontend/js/swiper-bundle.min.js')}}"></script>
    <script src="{{asset('frontend/js/theia-sticky-sidebar.js')}}"></script>
    <script src="{{asset('frontend/js/script.js')}}"></script>
    <script>
         // Match Height
         $(function () {
            $(".testi-subText").matchHeight();
            $(".card-userName").matchHeight();
        });


        $(document).ready(function () {
            // postSlide
            var mySwiper = new Swiper(".postSlide", {
            slidesPerView: 3,
            spaceBetween: 0,
            initialSlide: 1,
            watchOverflow: true,
            centeredSlides: true,
            loop: true,
            navigation: {
            nextEl: ".swiper-button-next.outer-swiper",
            prevEl: ".swiper-button-prev.outer-swiper"
            },
            breakpoints: {
                320: {
                slidesPerView: 1,
                spaceBetweenSlides:5,
                },
                576: {
                slidesPerView: 2,
                spaceBetweenSlides: 10,
                },
                992: {
                slidesPerView: 3,
                spaceBetweenSlides: 10,
                },
            }
        });
        

           // postSwiper
           var swiper = new Swiper(".postSwiper", {
            slidesPerView: 1,
            spaceBetween: 30,
            loop: true,
            pagination: {
            el: ".swiper-pagination.inner-swiperSlide",
            clickable: true,
            },
            navigation: {
            nextEl: ".swiper-button-next.inner-swiper",
            prevEl: ".swiper-button-prev.inner-swiper",
            },  
         }); 
           
        //  Testimonials
        var swiper = new Swiper(".tesimonialSlider", {
            slidesPerView: 3,
            spaceBetween: 30,
            loop: true,
           
            navigation: {
            nextEl: ".swiper-button-next.tesimol_next",
            prevEl: ".swiper-button-prev.tesimol_prev",
            }, 
            // autoplay: {
            //     delay: 1000,
            // },
            breakpoints: {
                320: {
                    slidesPerView: 1,
                },
             
                768: {
                    slidesPerView: 2,
                    spaceBetween: 20
                },
                992: {
                    slidesPerView: 3,
                    spaceBetween: 20
                },
               
            }
        });
    });
    </script>
    @yield("js")
</body>

</html>