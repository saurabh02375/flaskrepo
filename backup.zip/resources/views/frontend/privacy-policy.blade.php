@extends('frontend.layouts.default')
@section('title','Privacy policy')
@section('content')
<section class="banner-section" style="background-image: url({{asset('frontend/img/banner-bgImg01.png')}});">
    <div class="container">
        <div class="page_banner_block">
            <h2 class="banner-head">Privacy policy</h2>
        </div>
    </div>
</section>

<section class="terms-conditionsWrapper">
    <div class="container">
        <div class="terms-conditionsBlock">
            <h2 class="section_subHead mb-23">General Site Usage</h2>
            <div class="desc-text">
                <p>Welcome to www.lorem-ipsum.com. this site is provided as a service to our visitors and may be
                    used for informational purposes only. because the terms and conditions contain legal
                    obligations, please read them carefully.</p>
            </div>
            <ul class="terms-conditions-items">
                <li>
                    <h3 class="terms_head"><span>1. </span> Your agreement</h3>
                    <div class="desc-text">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                            has been the industry's standard dummy text ever since the 1500s, when an unknown
                            printer took a galley of type and scrambled it to make a type specimen book. It has
                            survived not only five centuries, but also the leap into electronic typesetting,
                            remaining essentially unchanged. It was popularised in the 1960s with the release of
                            Letraset sheets containing Lorem Ipsum passages, and more recently with desktop
                            publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                    </div>
                </li>
                <li>
                    <h3 class="terms_head"><span>2. </span> Privacy</h3>
                    <div class="desc-text">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                            has been the industry's standard dummy text ever since the 1500s, when an unknown
                            printer took a galley of type and scrambled it to make a type specimen book.</p>
                    </div>
                </li>
                <li>
                    <h3 class="terms_head"><span>3. </span> Linked sites</h3>
                    <div class="desc-text">
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                            has been the industry's standard dummy text ever since the 1500s, when an unknown
                            printer took a galley of type and scrambled it to make a type specimen book. It has
                            survived not only five centuries, but also the leap into electronic typesetting,
                            remaining essentially unchanged. It was popularised in the 1960s with the release of
                            Letraset sheets containing Lorem Ipsum passages, and more recently with desktop
                            publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                    </div>
                </li>
                <li>
                    <h3 class="terms_head"><span>4. </span> Forward looking statements</h3>
                    <div class="desc-text">
                        <p>All materials reproduced on this site speak as of the original date of publication or
                            filing. the fact that a document is available on this site does not mean that the
                            information contained in such document has not been modified or superseded by events or
                            by a subsequent document or filing. we have no duty or policy to update any information
                            or statements contained on this site and, therefore, such information or statements
                            should not be relied upon as being current as of the date you access this site.</p>
                    </div>
                </li>
                <li>
                    <h3 class="terms_head"><span>5. </span> Disclaimer of warranties and limitation of liability
                    </h3>
                    <div class="desc-text">
                        <p class="text-mb">A. this site may contain inaccuracies and typographical errors. we does
                            not warrant the accuracy or completeness of the materials or the reliability of any
                            advice, opinion, statement or other information displayed or distributed through the
                            site. you expressly understand and agree that: (i) your use of the site, including any
                            reliance on any such opinion, advice, statement, memorandum, or information contained
                            herein, shall be at your sole risk; (ii) the site is provided on an "as is" and "as
                            available" basis; (iii) except as expressly provided herein we disclaim all warranties
                            of any kind, whether express or implied, including, but not limited to implied
                            warranties of merchantability, fitness for a particular purpose, workmanlike effort,
                            title and non-infringement; (iv) we make no warranty with respect to the results that
                            may be obtained from this site, the products or services advertised or offered or
                            merchants involved; (v) any material downloaded or otherwise obtained through the use of
                            the site is done at your own discretion and risk; and (vi) you will be solely
                            responsible for any damage to your computer system or for any loss of data that results
                            from the download of any such material.</p>
                        <p>B. you understand and agree that under no circumstances, including, but not limited to,
                            negligence, shall we be liable for any direct, indirect, incidental, special, punitive
                            or consequential damages that result from the use of, or the inability to use, any of
                            our sites or materials or functions on any such site, even if we have been advised of
                            the possibility of such damages. the foregoing limitations shall apply notwithstanding
                            any failure of essential purpose of any limited remedy.</p>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</section>
@stop