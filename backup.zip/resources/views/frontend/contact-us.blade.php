@extends('frontend.layouts.default')
@section('title','Contact Us')
@section('content')
<!-- top section -->
<section class="banner-section" style="background-image: url({{asset('frontend/img/banner-bgImg.png')}});">
    <div  class="banner-sectionImg">
        <img src="{{asset('frontend/img/banner-left.png')}}" alt="" class="left-img">
        <img src="{{asset('frontend/img/banner-right.png')}}" alt="" class="right-img">
    </div>
    <div class="container">
        <div class="breadcrumb_box">
            <nav aria-label="breadcrumb">
                <div class="page_banner_heading">
                    Contact Us
                </div>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Contact Us</li>
                </ol>
            </nav>
        </div>
    </div>
</section>
 <!-- top section end -->

 <section class="contact_wrapper section_padding">
    <div class="container">
        <div class="contact_inputBox">
            <div class="row">
                <div class="col-md-6">
                    <div class="contact_leftBox">
                        <figure class="contact_leftImg">
                            <img src="{{asset('frontend/img/contact-img.png')}}" alt="">
                        </figure>
                        <span class="send-mess">Send us your query</span>
                        <ul class="contact_infoBox">
                            <li class="contact_mailBox">
                                 <span class="contact_infoIcon">
                                    <svg width="26" height="20" viewBox="0 0 26 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M0.967742 0.967742V0C0.711081 0 0.464932 0.101958 0.283445 0.283445C0.101958 0.464932 0 0.711081 0 0.967742H0.967742ZM24.1935 0.967742H25.1613C25.1613 0.711081 25.0593 0.464932 24.8778 0.283445C24.6964 0.101958 24.4502 0 24.1935 0V0.967742ZM0.967742 1.93548H24.1935V0H0.967742V1.93548ZM23.2258 0.967742V16.4516H25.1613V0.967742H23.2258ZM21.6129 18.0645H3.54839V20H21.6129V18.0645ZM1.93548 16.4516V0.967742H0V16.4516H1.93548ZM3.54839 18.0645C2.65806 18.0645 1.93548 17.3419 1.93548 16.4516H0C0 17.3927 0.373847 18.2952 1.0393 18.9607C1.70475 19.6262 2.6073 20 3.54839 20V18.0645ZM23.2258 16.4516C23.2258 17.3419 22.5032 18.0645 21.6129 18.0645V20C22.554 20 23.4565 19.6262 24.122 18.9607C24.7874 18.2952 25.1613 17.3927 25.1613 16.4516H23.2258Z" fill="#1B3C64"/>
                                        <path d="M0.967529 0.969727L12.5804 12.5826L24.1933 0.969727" stroke="#1B3C64" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                        </svg>                                            
                                </span>
                                <div class="contact_nameBox">
                                    <span class="contact_nameTitle">Email</span>
                                    <a href="#!" class="contact_nameMail">wildtag.help@gmail.com</a>
                                </div>
                            </li>
                            <li class="contact_mailBox">
                                <span class="contact_infoIcon">
                                    <svg width="26" height="26" viewBox="0 0 26 26" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M2.26541 3.31909L2.26407 3.32043L2.26407 3.32042C1.70707 3.87483 1.29469 4.5575 1.06313 5.3085C0.832005 6.05809 0.788079 6.85287 0.935164 7.62333C1.80449 11.9006 3.94268 15.8165 7.07082 18.8604C11.7143 23.2779 15.5853 24.6847 19.2784 25.1047C19.8949 25.0981 20.5046 24.9731 21.0741 24.7363C21.6579 24.4936 22.1882 24.1382 22.6345 23.6904L22.6355 23.6894L24.5455 21.7794C24.5458 21.7791 24.5461 21.7788 24.5463 21.7785C24.8885 21.4332 25.0804 20.9667 25.0804 20.4806C25.0804 19.9945 24.8885 19.5281 24.5465 19.1828C24.5462 19.1824 24.5458 19.1821 24.5455 19.1817L21.6877 16.3231C21.687 16.3224 21.6862 16.3217 21.6855 16.321C21.4973 16.1361 21.2716 15.9936 21.0237 15.9031C20.7749 15.8122 20.5095 15.7758 20.2454 15.7963C19.9813 15.8168 19.7247 15.8938 19.4929 16.022C19.2619 16.1497 19.061 16.3253 18.9035 16.537C18.9029 16.5378 18.9023 16.5386 18.9017 16.5394L18.1317 17.5942C18.131 17.5952 18.1303 17.5961 18.1296 17.597C17.8638 17.9651 17.4668 18.217 17.0205 18.3007C16.5747 18.3843 16.1138 18.2936 15.733 18.0474C14.1629 17.0479 12.7069 15.8795 11.3911 14.5631C11.3911 14.5631 11.391 14.563 11.391 14.563C11.391 14.563 11.3909 14.5629 11.3909 14.5629C10.0739 13.2463 8.90489 11.7895 7.90484 10.2186L7.90329 10.2162C7.66276 9.83545 7.57511 9.37787 7.65795 8.93523C7.7408 8.49259 7.98799 8.09767 8.34993 7.82973L8.35472 7.82618L8.35473 7.8262L9.41755 7.05087M2.26541 3.31909L9.41755 7.05087M2.26541 3.31909L4.17082 1.41412M2.26541 3.31909L4.17082 1.41412M9.41755 7.05087C9.41681 7.05142 9.41607 7.05197 9.41533 7.05251L9.92126 7.73555L9.42031 7.04886L9.41755 7.05087ZM4.17082 1.41412C4.52303 1.08079 4.98962 0.894922 5.47477 0.894922C5.95991 0.894922 6.42649 1.08078 6.77869 1.41409L9.63365 4.26905C9.81866 4.45728 9.96125 4.68294 10.0518 4.93086C10.1428 5.17964 10.1792 5.44505 10.1587 5.70913L4.17082 1.41412Z" stroke="#1B3C64" stroke-width="1.7"/>
                                        </svg>                                                                                       
                                </span>
                                <div class="contact_nameBox">
                                    <span class="contact_nameTitle">Phone Number</span>
                                    <a href="#!" class="contact_nameMail number-link">+1 9876543210</a>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-6">
                    <form action="#" class="form_input_box">
                        <div class="row">
                            <div class="col-12">
                                <div class="form-group mb-20">
                                    <label class="form-label">Name</label>
                                    <input type="text" class="form-control" placeholder="Enter User Name">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group mb-20">
                                    <label class="form-label">Email</label>
                                    <input type="email" class="form-control" placeholder="Enter Email">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group mb-20">
                                    <label class="form-label">Subject</label>
                                    <input type="text" class="form-control" placeholder="Enter Subject">
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-group mb-20">
                                    <label class="form-label">Message</label>
                                    <textarea class="form-control input-textarea" cols="5" rows="5" placeholder="Write your message here..."></textarea>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="contact_continueBtn">
                                    <button class=" btn-primary" type="button">Submit</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
@stop

@section("js")
<script src="https://www.google.com/recaptcha/api.js" async defer></script>

<script>
    $(function () {
        $("").matchHeight();
    })
</script>

@stop
